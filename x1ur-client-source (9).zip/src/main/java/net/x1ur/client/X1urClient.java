package net.x1ur.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientBlockEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.x1ur.client.aim.AimAssist;
import net.x1ur.client.amethyst.AmethystEsp;
import net.x1ur.client.amethyst.AmethystEspRenderer;
import net.x1ur.client.base.BaseEsp;
import net.x1ur.client.base.BaseEspRenderer;
import net.x1ur.client.combat.AutoMace;
import net.x1ur.client.combat.TriggerBot;
import net.x1ur.client.combat.VanillaAttack;
import net.x1ur.client.config.X1urConfig;
import net.x1ur.client.diagnostics.DisconnectLogger;
import net.x1ur.client.fly.Fly;
import net.x1ur.client.playeresp.PlayerEspRenderer;
import net.x1ur.client.gui.ClickGuiScreen;
import net.x1ur.client.netherite.NetheriteFinder;
import net.x1ur.client.netherite.NetheriteFinderRenderer;
import net.x1ur.client.storage.StorageEspRenderer;
import net.x1ur.client.storage.StorageTracker;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class X1urClient implements ClientModInitializer {
	public static final String MOD_ID = "x1ur_client";
	public static final String NAME = "X1UR CLIENT";
	public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

	private static AimAssist aimAssist;

	public static AimAssist aimAssist() {
		return aimAssist;
	}

	@Override
	public void onInitializeClient() {
		X1urConfig config = X1urConfig.get();
		aimAssist = new AimAssist(config);

		KeyMapping openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key." + MOD_ID + ".open_gui",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_RIGHT_SHIFT,
			KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"))
		));

		KeyMapping toggleAim = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key." + MOD_ID + ".toggle_aim_assist",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_G,
			openGui.getCategory()
		));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (openGui.consumeClick()) {
				if (mc.screen == null && mc.player != null) {
					mc.setScreen(new ClickGuiScreen(openGui));
				}
			}
			while (toggleAim.consumeClick()) {
				if (mc.screen == null && mc.player != null) {
					aimAssist.setEnabled(!aimAssist.isEnabled());
					config.save();
					mc.player.displayClientMessage(
						Component.literal("Aim Assist: " + (aimAssist.isEnabled() ? "ON" : "OFF")), true);
				}
			}
			aimAssist.tick(mc);
		});

		// ---- Storage ESP: detection (events) -> tracker; rendering (END_MAIN) reads the tracker's draw list ----
		StorageTracker storageTracker = new StorageTracker();
		StorageEspRenderer storageRenderer = new StorageEspRenderer(storageTracker, config);
		ClientBlockEntityEvents.BLOCK_ENTITY_LOAD.register(storageTracker::onBlockEntityLoad);
		ClientBlockEntityEvents.BLOCK_ENTITY_UNLOAD.register(storageTracker::onBlockEntityUnload);
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> storageTracker.clear());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> storageTracker.clear());
		ClientTickEvents.END_CLIENT_TICK.register(mc -> storageTracker.tick(mc, config.storageEspEnabled));
		WorldRenderEvents.END_MAIN.register(storageRenderer::render);

		// ---- Netherite Finder: client-side scan of already-received chunks; renders at END_MAIN ----
		NetheriteFinder netheriteFinder = new NetheriteFinder(config);
		NetheriteFinderRenderer netheriteRenderer = new NetheriteFinderRenderer(netheriteFinder, config);
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> netheriteFinder.clear());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> netheriteFinder.clear());
		ClientTickEvents.END_CLIENT_TICK.register(netheriteFinder::tick);
		WorldRenderEvents.END_MAIN.register(netheriteRenderer::render);

		// ---- Auto Mace + Trigger Bot: both attack only through one shared vanilla-path attack (max 1 hit per tick) ----
		VanillaAttack vanillaAttack = new VanillaAttack();
		AutoMace autoMace = new AutoMace(config, vanillaAttack);
		TriggerBot triggerBot = new TriggerBot(config, vanillaAttack);
		Runnable resetCombat = () -> {
			vanillaAttack.reset();
			autoMace.reset();
			triggerBot.reset();
		};
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> resetCombat.run());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> resetCombat.run());
		ClientTickEvents.END_CLIENT_TICK.register(autoMace::tick);
		ClientTickEvents.END_CLIENT_TICK.register(triggerBot::tick);
		DisconnectLogger.register();

		// ---- Player ESP: reads vanilla's extracted entity render states at END_MAIN; keeps no state ----
		PlayerEspRenderer playerEspRenderer = new PlayerEspRenderer(config);
		WorldRenderEvents.END_MAIN.register(playerEspRenderer::render);

		// ---- Base ESP: incremental chunk scan (tick + chunk events) -> cached results -> render at END_MAIN ----
		BaseEsp baseEsp = new BaseEsp(config);
		BaseEspRenderer baseEspRenderer = new BaseEspRenderer(baseEsp, config);
		baseEsp.register();
		KeyMapping toggleBaseEsp = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key." + MOD_ID + ".toggle_base_esp",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_UNKNOWN, // unbound by default; set it in Options > Controls (or a Pojav on-screen button)
			openGui.getCategory()
		));
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> baseEsp.clear());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> baseEsp.clear());
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (toggleBaseEsp.consumeClick()) {
				if (mc.screen == null && mc.player != null) {
					config.baseEspEnabled = !config.baseEspEnabled;
					config.save();
					mc.player.displayClientMessage(
						Component.literal("Base ESP: " + (config.baseEspEnabled ? "ON" : "OFF")), true);
				}
			}
			baseEsp.tick(mc);
		});
		WorldRenderEvents.END_MAIN.register(baseEspRenderer::render);

		// ---- Amethyst ESP: incremental chunk scan (tick + chunk events) -> cached results -> render at END_MAIN ----
		AmethystEsp amethystEsp = new AmethystEsp(config);
		AmethystEspRenderer amethystRenderer = new AmethystEspRenderer(amethystEsp, config);
		amethystEsp.register();
		KeyMapping toggleAmethystEsp = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key." + MOD_ID + ".toggle_amethyst_esp",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_UNKNOWN, // unbound by default; set it in Options > Controls (or a Pojav on-screen button)
			openGui.getCategory()
		));
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> amethystEsp.clear());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> amethystEsp.clear());
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (toggleAmethystEsp.consumeClick()) {
				if (mc.screen == null && mc.player != null) {
					config.amethystEspEnabled = !config.amethystEspEnabled;
					config.save();
					mc.player.displayClientMessage(
						Component.literal("Amethyst ESP: " + (config.amethystEspEnabled ? "ON" : "OFF")), true);
				}
			}
			amethystEsp.tick(mc);
		});
		WorldRenderEvents.END_MAIN.register(amethystRenderer::render);

		// ---- Fly: vanilla flight mechanics, only where the server granted flight; state dropped on join/disconnect ----
		Fly fly = new Fly(config);
		KeyMapping toggleFly = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key." + MOD_ID + ".toggle_fly",
			InputConstants.Type.KEYSYM,
			GLFW.GLFW_KEY_UNKNOWN, // unbound by default; set it in Options > Controls (or a Pojav on-screen button)
			openGui.getCategory()
		));
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> fly.reset());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> fly.reset());
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (toggleFly.consumeClick()) {
				if (mc.screen == null && mc.player != null) {
					config.flyEnabled = !config.flyEnabled;
					config.save();
					mc.player.displayClientMessage(Component.literal("Fly: " + (config.flyEnabled ? "ON" : "OFF")), true);
				}
			}
			fly.tick(mc);
		});

		LOGGER.info("{} initialised (Minecraft 1.21.11)", NAME);
	}
}
