package net.x1ur.client.gui;

import net.minecraft.client.gui.GuiGraphics;

/** Tiny immediate-mode drawing helpers: rounded rectangles via scanline fills (cheap, no textures/shaders). */
final class Draw {
	private Draw() {
	}

	static void roundRect(GuiGraphics g, int x, int y, int w, int h, int radius, int color) {
		int r = Math.min(radius, Math.min(w, h) / 2);
		if (r <= 0) {
			g.fill(x, y, x + w, y + h, color);
			return;
		}
		g.fill(x, y + r, x + w, y + h - r, color);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
			g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
			g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
		}
	}

	/** Opaque rounded rectangle with a 1 px border. */
	static void roundRectBordered(GuiGraphics g, int x, int y, int w, int h, int radius, int border, int fill) {
		roundRect(g, x, y, w, h, radius, border);
		roundRect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, radius - 1), fill);
	}

	static int lerpColor(int a, int b, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int aa = a >>> 24, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int ba = b >>> 24, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		return ((int) (aa + (ba - aa) * t) << 24)
			| ((int) (ar + (br - ar) * t) << 16)
			| ((int) (ag + (bg - ag) * t) << 8)
			| (int) (ab + (bb - ab) * t);
	}

	static int withAlpha(int color, float alpha) {
		int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, alpha)));
		return (a << 24) | (color & 0xFFFFFF);
	}

	/** Exponential approach, frame-rate independent. */
	static float approach(float current, float target, float dt, float speed) {
		float next = current + (target - current) * (1f - (float) Math.exp(-dt * speed));
		return Math.abs(target - next) < 0.002f ? target : next;
	}
}
