package net.x1ur.client.gui;

import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.x1ur.client.X1urClient;
import net.x1ur.client.aim.AimAssist;
import net.x1ur.client.config.X1urConfig;
import net.x1ur.client.storage.StorageType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The X1UR CLIENT ClickGUI: one panel with a card per module (Aim Assist, Storage ESP, Netherite Finder,
 * Auto Mace, Trigger Bot, Player ESP).
 *
 * <p>Each card has an on/off switch (right side) and expandable settings. Cards behave as an accordion
 * (one open at a time). When the cards do not fit on screen the list scrolls: mouse wheel, the scroll bar on the
 * panel's right edge (drag it, also works by touch), and automatically to keep the keyboard focus visible.
 *
 * <p>Input: mouse / touch (tap, drag; Android PojavLauncher maps touches to left clicks) and keyboard
 * (Up/Down/Tab move focus, Left/Right adjust or open/close, Enter/Space toggle, Esc or the open key closes).
 * Layout is authored in a fixed "panel space" and uniformly scaled down on small screens.
 * Animations are simple exponential tweens and only run while this screen is open.
 */
public final class ClickGuiScreen extends Screen {
	// ---- palette ----
	private static final int BG = 0xFF0D0E11;
	private static final int CARD = 0xFF14161A;
	private static final int CARD_HOVER = 0xFF1A1D22;
	private static final int BORDER = 0xFF262A31;
	private static final int TRACK = 0xFF23272E;
	private static final int ACCENT = 0xFF22D3EE;
	private static final int ACCENT_BORDER = 0xFF157C8C;
	private static final int OFF = 0xFF4A505A;
	private static final int TEXT = 0xFFE8EBF0;
	private static final int SUBTEXT = 0xFF8B929D;
	private static final int KNOB = 0xFFF2F5F8;
	private static final int DIM = 0x99000000;

	/** Selectable outline colors (0xRRGGBB). Other values can be set by editing the JSON config. */
	private static final int[] PALETTE = {
		0x22D3EE, 0xF2F5F8, 0x4ADE80, 0xFACC15, 0xFB923C, 0xF87171, 0xF472B6, 0xA78BFA
	};

	// ---- layout (panel space, pixels before scaling) ----
	private static final int PW = 264;
	private static final int PAD = 12;
	private static final int HEADER_H = 40;
	private static final int CARD_X = PAD;
	private static final int CARD_Y = HEADER_H + 10;
	private static final int CARD_W = PW - PAD * 2;
	private static final int CARD_H = 40;
	private static final int CARD_GAP = 8;
	private static final int BOTTOM_PAD = 12;
	private static final int SWITCH_W = 34;
	private static final int SWITCH_H = 18;
	private static final int SWITCH_X = CARD_X + CARD_W - 12 - SWITCH_W;
	private static final int CLOSE_SIZE = 24;
	private static final int CLOSE_X = PW - PAD - CLOSE_SIZE;
	private static final int CLOSE_Y = (HEADER_H - CLOSE_SIZE) / 2;
	private static final int KNOB_SIZE = 10;
	private static final int ROW_SLIDER_H = 36;
	private static final int ROW_SWITCH_H = 34;
	private static final int ROW_SWATCH_H = 24;
	private static final int ROW_LABEL_H = 20;
	private static final int SWATCH_SIZE = 12;
	private static final int SWATCH_CELL = 15;
	/** The panel is scaled so that at least this much panel height fits on screen; taller content scrolls. */
	private static final int COMFORT_H = 320;
	private static final int LIST_TOP = HEADER_H + 1;
	private static final int SCROLLBAR_X = PW - 6;
	private static final int SCROLLBAR_GRAB_X = PW - 14;

	private final KeyMapping openKey;
	private final X1urConfig config = X1urConfig.get();
	private final AimAssist aim = X1urClient.aimAssist();
	private final List<Module> modules = new ArrayList<>();
	private final int fullHeight;

	// animation state
	private long lastNanos = System.nanoTime();
	private float intro = 0f;
	private float alpha = 0f;
	private float hoverClose;

	// interaction state
	private Row dragging;
	private boolean scrollbarDrag;
	private int focusModule = 0;
	private int focusRow = -1; // -1 = the module's header switch
	private boolean keyboardNav = false;

	// layout result, refreshed every frame
	private float scale = 1f;
	private float originX;
	private float originY;
	private int layoutH;      // panel height reserved on screen (constant while the window size is constant)
	private int contentH;     // height of all cards at their current animation state
	private int panelH;       // drawn panel height = min(contentH, layoutH)
	private float scroll;
	private float scrollTarget;
	private float maxScroll;

	public ClickGuiScreen(KeyMapping openKey) {
		super(Component.literal(X1urClient.NAME));
		this.openKey = openKey;

		modules.add(buildAimAssist());
		modules.add(buildStorageEsp());
		modules.add(buildNetheriteFinder());
		modules.add(buildAutoMace());
		modules.add(buildTriggerBot());
		modules.add(buildPlayerEsp());
		modules.add(buildBaseEsp());
		modules.add(buildAmethystEsp());
		modules.add(buildFly());
		setOpen(modules.get(0), true);
		for (Module m : modules) {
			m.expand = m.open ? 1f : 0f;
		}

		// reserve the height of the tallest accordion state so the panel never rescales while animating
		int tallest = 0;
		for (Module m : modules) {
			tallest = Math.max(tallest, m.settingsHeight());
		}
		this.fullHeight = CARD_Y + modules.size() * CARD_H + (modules.size() - 1) * CARD_GAP + tallest + BOTTOM_PAD;
	}

	// ------------------------------------------------------------------ module definitions

	private Module buildAimAssist() {
		Module m = new Module("Aim Assist", "Smooth aim assistance", aim::isEnabled, () -> {
			aim.setEnabled(!aim.isEnabled());
			config.save();
		});
		m.rows.add(new SliderRow("Aim Smoothing", X1urConfig.SMOOTHING_MIN, X1urConfig.SMOOTHING_MAX, 1, 5,
			() -> config.smoothing,
			v -> config.smoothing = (int) Math.round(v),
			v -> Math.round(v) + "%"));
		m.rows.add(new SliderRow("Rotation Speed", X1urConfig.SPEED_MIN, X1urConfig.SPEED_MAX, 0.5, 0.5,
			() -> config.rotationSpeed,
			v -> config.rotationSpeed = (float) v,
			v -> String.format(Locale.ROOT, "%.1f\u00b0/tick", v)));
		m.rows.add(new SwitchRow("Only While Attacking",
			() -> config.onlyWhileAttacking ? "Active while holding attack" : "Always active near targets",
			() -> config.onlyWhileAttacking,
			() -> {
				config.onlyWhileAttacking = !config.onlyWhileAttacking;
				config.save();
			}));
		return m;
	}

	private Module buildStorageEsp() {
		Module m = new Module("Storage ESP", "Outlines storage blocks", () -> config.storageEspEnabled, () -> {
			config.storageEspEnabled = !config.storageEspEnabled;
			config.save();
		});
		m.rows.add(new SliderRow("Outline Visibility",
			X1urConfig.STORAGE_VISIBILITY_MIN, X1urConfig.STORAGE_VISIBILITY_MAX, 5, 5,
			() -> config.storageOutlineVisibility,
			v -> config.storageOutlineVisibility = (int) Math.round(v),
			v -> Math.round(v) + "%"));
		m.rows.add(new SliderRow("Max Render Distance",
			X1urConfig.STORAGE_DISTANCE_MIN, X1urConfig.STORAGE_DISTANCE_MAX, 8, 8,
			() -> config.storageMaxDistance,
			v -> config.storageMaxDistance = (int) Math.round(v),
			v -> Math.round(v) + " blocks"));
		m.rows.add(new LabelRow("Outline Colors"));
		for (StorageType type : StorageType.VALUES) {
			m.rows.add(new SwatchRow(type.label, () -> type.color(config), rgb -> type.setColor(config, rgb)));
		}
		m.rows.add(new SwitchRow("Tracers",
			() -> config.storageTracers ? "Line from crosshair to each block" : "Off",
			() -> config.storageTracers,
			() -> {
				config.storageTracers = !config.storageTracers;
				config.save();
			}));
		m.rows.add(new LabelRow("Tracer Colors"));
		for (StorageType type : StorageType.VALUES) {
			m.rows.add(new SwatchRow(type.label, () -> type.tracerColor(config), rgb -> type.setTracerColor(config, rgb)));
		}
		m.rows.add(new SwitchRow("Labels",
			() -> config.storageLabels ? "Type name on the nearest blocks" : "Off",
			() -> config.storageLabels,
			() -> {
				config.storageLabels = !config.storageLabels;
				config.save();
			}));
		m.rows.add(new SwitchRow("Distance",
			() -> config.storageDistance ? "Shown on labels" : "Off",
			() -> config.storageDistance,
			() -> {
				config.storageDistance = !config.storageDistance;
				config.save();
			}));
		m.rows.add(new LabelRow("Show Types"));
		for (StorageType type : StorageType.VALUES) {
			m.rows.add(new SwitchRow(type.label,
				() -> type.enabled(config) ? "Shown" : "Hidden",
				() -> type.enabled(config),
				() -> {
					type.setEnabled(config, !type.enabled(config));
					config.save();
				}));
		}
		return m;
	}

	private Module buildNetheriteFinder() {
		Module m = new Module("Netherite Finder", "Highlights ancient debris",
			() -> config.netheriteFinderEnabled, () -> {
				config.netheriteFinderEnabled = !config.netheriteFinderEnabled;
				config.save();
			});
		m.rows.add(new SliderRow("Max Shown",
			X1urConfig.NETHERITE_SHOWN_MIN, X1urConfig.NETHERITE_SHOWN_MAX, 1, 10,
			() -> config.netheriteMaxShown,
			v -> config.netheriteMaxShown = (int) Math.round(v),
			v -> Integer.toString((int) Math.round(v))));
		m.rows.add(new SwitchRow("Tracers",
			() -> config.netheriteTracers ? "Lines from crosshair to targets" : "Outlines only",
			() -> config.netheriteTracers,
			() -> {
				config.netheriteTracers = !config.netheriteTracers;
				config.save();
			}));
		m.rows.add(new SwitchRow("Ancient Debris Mode",
			() -> config.netheriteDebrisMode ? "Only exact debris blocks" : "Blocks and whole-section boxes",
			() -> config.netheriteDebrisMode,
			() -> {
				config.netheriteDebrisMode = !config.netheriteDebrisMode;
				config.save();
			}));
		return m;
	}

	private Module buildAutoMace() {
		Module m = new Module("Auto Mace", "Mace smash timing", () -> config.autoMaceEnabled, () -> {
			config.autoMaceEnabled = !config.autoMaceEnabled;
			config.save();
		});
		m.rows.add(new ChoiceRow("Activation Mode", new String[] {"Hold Attack", "Always"},
			() -> config.autoMaceMode,
			v -> config.autoMaceMode = v,
			() -> config.autoMaceMode == X1urConfig.ACTIVATION_HOLD_ATTACK ? "While attack is held" : "Whenever target is aimed"));
		m.rows.add(new SliderRow("Reaction Delay",
			X1urConfig.REACTION_DELAY_MIN, X1urConfig.REACTION_DELAY_MAX, 10, 10,
			() -> config.autoMaceDelayMs,
			v -> config.autoMaceDelayMs = (int) Math.round(v),
			v -> Math.round(v) + " ms"));
		return m;
	}

	private Module buildTriggerBot() {
		Module m = new Module("Trigger Bot", "Hits aimed targets", () -> config.triggerBotEnabled, () -> {
			config.triggerBotEnabled = !config.triggerBotEnabled;
			config.save();
		});
		m.rows.add(new SliderRow("Reaction Delay",
			X1urConfig.REACTION_DELAY_MIN, X1urConfig.REACTION_DELAY_MAX, 10, 10,
			() -> config.triggerBotDelayMs,
			v -> config.triggerBotDelayMs = (int) Math.round(v),
			v -> Math.round(v) + " ms"));
		return m;
	}

	private Module buildPlayerEsp() {
		Module m = new Module("Player ESP", "Outlines players", () -> config.playerEspEnabled, () -> {
			config.playerEspEnabled = !config.playerEspEnabled;
			config.save();
		});
		m.rows.add(new SliderRow("Max Render Distance",
			X1urConfig.PLAYER_ESP_DISTANCE_MIN, X1urConfig.PLAYER_ESP_DISTANCE_MAX, 8, 8,
			() -> config.playerEspMaxDistance,
			v -> config.playerEspMaxDistance = (int) Math.round(v),
			v -> Math.round(v) + " blocks"));
		m.rows.add(new SwatchRow("Outline Color", () -> config.playerEspColor, rgb -> config.playerEspColor = rgb));
		m.rows.add(new SwitchRow("Include Self",
			() -> config.playerEspIncludeSelf ? "Also outlines you (3rd person)" : "Other players only",
			() -> config.playerEspIncludeSelf,
			() -> {
				config.playerEspIncludeSelf = !config.playerEspIncludeSelf;
				config.save();
			}));
		return m;
	}

	private Module buildBaseEsp() {
		Module m = new Module("Base ESP", "Base candidates & shulkers", () -> config.baseEspEnabled, () -> {
			config.baseEspEnabled = !config.baseEspEnabled;
			config.save();
		});
		m.rows.add(new SwitchRow("Shulker ESP",
			() -> !config.baseEspEnabled && config.baseShulkerEspEnabled ? "Saved ON - inactive while Base ESP is off"
				: config.baseShulkerEspEnabled ? "Outlines shulker boxes" : "Off",
			() -> config.baseShulkerEspEnabled,
			() -> {
				config.baseShulkerEspEnabled = !config.baseShulkerEspEnabled;
				config.save();
			}));
		m.rows.add(new SwitchRow("Structure Outline",
			() -> config.baseStructureOutline ? "Draw boxes around candidates" : "Off",
			() -> config.baseStructureOutline,
			() -> {
				config.baseStructureOutline = !config.baseStructureOutline;
				config.save();
			}));
		m.rows.add(new SwitchRow("Labels",
			() -> config.baseLabels ? "\"Base Candidate\" / \"Shulker\"" : "Off",
			() -> config.baseLabels,
			() -> {
				config.baseLabels = !config.baseLabels;
				config.save();
			}));
		m.rows.add(new SwitchRow("Distance",
			() -> config.baseDistance ? "Shown on labels" : "Off",
			() -> config.baseDistance,
			() -> {
				config.baseDistance = !config.baseDistance;
				config.save();
			}));
		m.rows.add(new SliderRow("Min Width",
			X1urConfig.BASE_SIZE_MIN, X1urConfig.BASE_SIZE_MAX, 1, 1,
			() -> config.baseMinWidth,
			v -> config.baseMinWidth = (int) Math.round(v),
			v -> Math.round(v) + " blocks"));
		m.rows.add(new SliderRow("Min Length",
			X1urConfig.BASE_SIZE_MIN, X1urConfig.BASE_SIZE_MAX, 1, 1,
			() -> config.baseMinLength,
			v -> config.baseMinLength = (int) Math.round(v),
			v -> Math.round(v) + " blocks"));
		m.rows.add(new SliderRow("Scan Radius",
			X1urConfig.BASE_RADIUS_MIN, X1urConfig.BASE_RADIUS_MAX, 1, 1,
			() -> config.baseScanRadius,
			v -> config.baseScanRadius = (int) Math.round(v),
			v -> Math.round(v) + " chunks"));
		m.rows.add(new SliderRow("Opacity",
			X1urConfig.BASE_OPACITY_MIN, X1urConfig.BASE_OPACITY_MAX, 5, 5,
			() -> config.baseOpacity,
			v -> config.baseOpacity = (int) Math.round(v),
			v -> Math.round(v) + "%"));
		m.rows.add(new ButtonRow("Reset to Defaults", "Base ESP settings only", () -> config.resetBaseEsp()));
		return m;
	}

	private Module buildAmethystEsp() {
		Module m = new Module("Amethyst ESP", "Highlights amethyst crystals", () -> config.amethystEspEnabled, () -> {
			config.amethystEspEnabled = !config.amethystEspEnabled;
			config.save();
		});
		m.rows.add(new SwitchRow("Amethyst Cluster",
			() -> config.amethystClusters ? "Fully grown crystals" : "Off",
			() -> config.amethystClusters,
			() -> {
				config.amethystClusters = !config.amethystClusters;
				config.save();
			}));
		m.rows.add(new SwitchRow("Large Amethyst Bud",
			() -> config.amethystLargeBuds ? "Included" : "Off",
			() -> config.amethystLargeBuds,
			() -> {
				config.amethystLargeBuds = !config.amethystLargeBuds;
				config.save();
			}));
		m.rows.add(new SwitchRow("Medium Amethyst Bud",
			() -> config.amethystMediumBuds ? "Included" : "Off",
			() -> config.amethystMediumBuds,
			() -> {
				config.amethystMediumBuds = !config.amethystMediumBuds;
				config.save();
			}));
		m.rows.add(new SwitchRow("Small Amethyst Bud",
			() -> config.amethystSmallBuds ? "Included" : "Off",
			() -> config.amethystSmallBuds,
			() -> {
				config.amethystSmallBuds = !config.amethystSmallBuds;
				config.save();
			}));
		m.rows.add(new SwitchRow("Outline",
			() -> config.amethystOutline ? "Draw boxes around crystals" : "Off",
			() -> config.amethystOutline,
			() -> {
				config.amethystOutline = !config.amethystOutline;
				config.save();
			}));
		m.rows.add(new SwitchRow("Labels",
			() -> config.amethystLabels ? "Names on the nearest crystals" : "Off",
			() -> config.amethystLabels,
			() -> {
				config.amethystLabels = !config.amethystLabels;
				config.save();
			}));
		m.rows.add(new SwitchRow("Distance",
			() -> config.amethystDistance ? "Shown on labels" : "Off",
			() -> config.amethystDistance,
			() -> {
				config.amethystDistance = !config.amethystDistance;
				config.save();
			}));
		m.rows.add(new SliderRow("Scan Radius",
			X1urConfig.AMETHYST_RADIUS_MIN, X1urConfig.AMETHYST_RADIUS_MAX, 1, 1,
			() -> config.amethystScanRadius,
			v -> config.amethystScanRadius = (int) Math.round(v),
			v -> Math.round(v) + " chunks"));
		m.rows.add(new SliderRow("Opacity",
			X1urConfig.AMETHYST_OPACITY_MIN, X1urConfig.AMETHYST_OPACITY_MAX, 5, 5,
			() -> config.amethystOpacity,
			v -> config.amethystOpacity = (int) Math.round(v),
			v -> Math.round(v) + "%"));
		return m;
	}

	private Module buildFly() {
		Module m = new Module("Fly", "Server-permitted flight", () -> config.flyEnabled, () -> {
			config.flyEnabled = !config.flyEnabled;
			config.save();
		});
		m.rows.add(new SliderRow("Horizontal Speed",
			X1urConfig.FLY_SPEED_MIN, X1urConfig.FLY_SPEED_MAX, 0.1, 0.1,
			() -> config.flyHorizontalSpeed,
			v -> config.flyHorizontalSpeed = (float) (Math.round(v * 10.0) / 10.0),
			v -> String.format(Locale.ROOT, "%.1fx", v)));
		m.rows.add(new SliderRow("Vertical Speed",
			X1urConfig.FLY_SPEED_MIN, X1urConfig.FLY_SPEED_MAX, 0.1, 0.1,
			() -> config.flyVerticalSpeed,
			v -> config.flyVerticalSpeed = (float) (Math.round(v * 10.0) / 10.0),
			v -> String.format(Locale.ROOT, "%.1fx", v)));
		return m;
	}

	// ------------------------------------------------------------------ model

	private final class Module {
		final String title;
		final String subtitle;
		final BooleanSupplier on;
		final Runnable toggle;
		final List<Row> rows = new ArrayList<>();
		boolean open;
		float expand;
		float switchAnim;
		float hover;
		int y;
		int cardHeight;

		Module(String title, String subtitle, BooleanSupplier on, Runnable toggle) {
			this.title = title;
			this.subtitle = subtitle;
			this.on = on;
			this.toggle = toggle;
			this.switchAnim = on.getAsBoolean() ? 1f : 0f;
		}

		int settingsHeight() {
			int h = 8;
			for (Row r : rows) {
				h += r.height;
			}
			return h;
		}
	}

	private abstract class Row {
		final int height;
		int y;

		Row(int height) {
			this.height = height;
		}

		boolean focusable() {
			return true;
		}

		void update(float dt) {
		}

		abstract void render(GuiGraphics g, Font font, Module m, boolean focused);

		/** Pointer pressed inside this row. Return true if handled. */
		boolean press(float px, float py) {
			return false;
		}

		void drag(float px) {
		}

		void release() {
		}

		/** Keyboard Left (-1) / Right (+1). */
		void adjust(int dir) {
		}

		/** Keyboard Enter / Space. */
		void activate() {
		}

		final void focusRing(GuiGraphics g) {
			g.renderOutline(CARD_X + 4, y + 1, CARD_W - 8, height - 2, c(ACCENT));
		}
	}

	private static float labelMix(Module m) {
		return m.switchAnim;
	}

	private final class SliderRow extends Row {
		final String label;
		final double min;
		final double max;
		final double step;
		final double keyStep;
		final DoubleSupplier get;
		final DoubleConsumer set;
		final DoubleFunction<String> format;
		float shown;

		SliderRow(String label, double min, double max, double step, double keyStep,
				  DoubleSupplier get, DoubleConsumer set, DoubleFunction<String> format) {
			super(ROW_SLIDER_H);
			this.label = label;
			this.min = min;
			this.max = max;
			this.step = step;
			this.keyStep = keyStep;
			this.get = get;
			this.set = set;
			this.format = format;
			this.shown = normalized();
		}

		float normalized() {
			return (float) Mth.clamp((get.getAsDouble() - min) / (max - min), 0.0, 1.0);
		}

		void setNormalized(float t) {
			double v = min + Mth.clamp(t, 0f, 1f) * (max - min);
			v = Math.round(v / step) * step;
			set.accept(Mth.clamp(v, min, max));
		}

		private void setFromPointer(float px) {
			setNormalized((px - trackX() - KNOB_SIZE / 2f) / (trackW() - KNOB_SIZE));
		}

		@Override
		void update(float dt) {
			shown = Draw.approach(shown, normalized(), dt, dragging == this ? 40f : 22f);
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			int x0 = trackX();
			int tw = trackW();
			g.drawString(font, label, x0, y + 6, c(Draw.lerpColor(SUBTEXT, TEXT, labelMix(m))), false);
			String value = format.apply(get.getAsDouble());
			g.drawString(font, value, x0 + tw - font.width(value), y + 6,
				c(Draw.lerpColor(SUBTEXT, ACCENT, m.switchAnim)), false);

			int ty = y + 21;
			Draw.roundRect(g, x0, ty, tw, 4, 2, c(TRACK));
			int knobX = x0 + Math.round((tw - KNOB_SIZE) * shown);
			Draw.roundRect(g, x0, ty, knobX - x0 + KNOB_SIZE / 2, 4, 2, c(Draw.lerpColor(OFF, ACCENT, m.switchAnim)));
			if (dragging == this) {
				Draw.roundRect(g, knobX - 2, ty + 2 - KNOB_SIZE / 2 - 2, KNOB_SIZE + 4, KNOB_SIZE + 4, (KNOB_SIZE + 4) / 2,
					c(Draw.withAlpha(ACCENT, 0.25f)));
			}
			Draw.roundRect(g, knobX, ty + 2 - KNOB_SIZE / 2, KNOB_SIZE, KNOB_SIZE, KNOB_SIZE / 2, c(KNOB));
			if (focused) {
				focusRing(g);
			}
		}

		@Override
		boolean press(float px, float py) {
			dragging = this;
			setFromPointer(px);
			return true;
		}

		@Override
		void drag(float px) {
			setFromPointer(px);
		}

		@Override
		void release() {
			config.save();
		}

		@Override
		void adjust(int dir) {
			set.accept(Mth.clamp(get.getAsDouble() + dir * keyStep, min, max));
			config.save();
		}
	}

	private final class SwitchRow extends Row {
		final String label;
		final Supplier<String> description;
		final BooleanSupplier get;
		final Runnable toggle;
		float anim;

		SwitchRow(String label, Supplier<String> description, BooleanSupplier get, Runnable toggle) {
			super(ROW_SWITCH_H);
			this.label = label;
			this.description = description;
			this.get = get;
			this.toggle = toggle;
			this.anim = get.getAsBoolean() ? 1f : 0f;
		}

		@Override
		void update(float dt) {
			anim = Draw.approach(anim, get.getAsBoolean() ? 1f : 0f, dt, 16f);
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			int x0 = trackX();
			g.drawString(font, label, x0, y + 7, c(Draw.lerpColor(SUBTEXT, TEXT, labelMix(m))), false);
			g.drawString(font, description.get(), x0, y + 19, c(SUBTEXT), false);
			drawSwitchAt(g, SWITCH_X, y + (height - SWITCH_H) / 2, anim);
			if (focused) {
				focusRing(g);
			}
		}

		@Override
		boolean press(float px, float py) {
			toggle.run();
			return true;
		}

		@Override
		void adjust(int dir) {
			if (get.getAsBoolean() != (dir > 0)) {
				toggle.run();
			}
		}

		@Override
		void activate() {
			toggle.run();
		}
	}

	/** A setting with a few named options; click / Enter / Left / Right cycles through them. */
	private final class ChoiceRow extends Row {
		final String label;
		final String[] options;
		final IntSupplier get;
		final IntConsumer set;
		final Supplier<String> description;

		ChoiceRow(String label, String[] options, IntSupplier get, IntConsumer set, Supplier<String> description) {
			super(ROW_SWITCH_H);
			this.label = label;
			this.options = options;
			this.get = get;
			this.set = set;
			this.description = description;
		}

		private void cycle(int dir) {
			set.accept(Math.floorMod(get.getAsInt() + dir, options.length));
			config.save();
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			int x0 = trackX();
			g.drawString(font, label, x0, y + 7, c(Draw.lerpColor(SUBTEXT, TEXT, labelMix(m))), false);
			g.drawString(font, description.get(), x0, y + 19, c(SUBTEXT), false);

			int widest = 0;
			for (String option : options) {
				widest = Math.max(widest, font.width(option));
			}
			int chipW = widest + 14;
			int chipH = 16;
			int cx = x0 + trackW() - chipW;
			int cy = y + (height - chipH) / 2;
			Draw.roundRectBordered(g, cx, cy, chipW, chipH, 5, c(Draw.lerpColor(BORDER, ACCENT_BORDER, m.switchAnim)), c(TRACK));
			String text = options[Mth.clamp(get.getAsInt(), 0, options.length - 1)];
			g.drawString(font, text, cx + (chipW - font.width(text)) / 2, cy + (chipH - font.lineHeight) / 2 + 1,
				c(Draw.lerpColor(SUBTEXT, ACCENT, m.switchAnim)), false);
			if (focused) {
				focusRing(g);
			}
		}

		@Override
		boolean press(float px, float py) {
			cycle(1);
			return true;
		}

		@Override
		void adjust(int dir) {
			cycle(dir);
		}

		@Override
		void activate() {
			cycle(1);
		}
	}

	/** A one-shot action button (click / Enter). */
	private final class ButtonRow extends Row {
		final String label;
		final String description;
		final Runnable action;

		ButtonRow(String label, String description, Runnable action) {
			super(ROW_SWITCH_H);
			this.label = label;
			this.description = description;
			this.action = action;
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			int x0 = trackX();
			g.drawString(font, label, x0, y + 7, c(Draw.lerpColor(SUBTEXT, TEXT, labelMix(m))), false);
			g.drawString(font, description, x0, y + 19, c(SUBTEXT), false);
			String text = "Reset";
			int chipW = font.width(text) + 14;
			int chipH = 16;
			int cx = x0 + trackW() - chipW;
			int cy = y + (height - chipH) / 2;
			Draw.roundRectBordered(g, cx, cy, chipW, chipH, 5, c(ACCENT_BORDER), c(TRACK));
			g.drawString(font, text, cx + (chipW - font.width(text)) / 2, cy + (chipH - font.lineHeight) / 2 + 1,
				c(ACCENT), false);
			if (focused) {
				focusRing(g);
			}
		}

		@Override
		boolean press(float px, float py) {
			action.run();
			return true;
		}

		@Override
		void activate() {
			action.run();
		}
	}

	private final class LabelRow extends Row {
		final String text;

		LabelRow(String text) {
			super(ROW_LABEL_H);
			this.text = text;
		}

		@Override
		boolean focusable() {
			return false;
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			int x0 = trackX();
			int ty = y + 8;
			g.drawString(font, text, x0, ty, c(SUBTEXT), false);
			int lineX = x0 + font.width(text) + 6;
			g.fill(lineX, ty + font.lineHeight / 2, x0 + trackW(), ty + font.lineHeight / 2 + 1, c(BORDER));
		}
	}

	/** A label plus a row of palette swatches editing one 0xRRGGBB color. */
	private final class SwatchRow extends Row {
		final String label;
		final IntSupplier get;
		final IntConsumer set;

		SwatchRow(String label, IntSupplier get, IntConsumer set) {
			super(ROW_SWATCH_H);
			this.label = label;
			this.get = get;
			this.set = set;
		}

		private int swatchStartX() {
			return trackX() + trackW() - PALETTE.length * SWATCH_CELL + (SWATCH_CELL - SWATCH_SIZE);
		}

		private int selectedIndex() {
			int current = get.getAsInt() & 0xFFFFFF;
			for (int i = 0; i < PALETTE.length; i++) {
				if (PALETTE[i] == current) {
					return i;
				}
			}
			return -1;
		}

		private void select(int index) {
			set.accept(PALETTE[Math.floorMod(index, PALETTE.length)]);
			config.save();
		}

		@Override
		void render(GuiGraphics g, Font font, Module m, boolean focused) {
			g.drawString(font, label, trackX(), y + (height - font.lineHeight) / 2 + 1,
				c(Draw.lerpColor(SUBTEXT, TEXT, labelMix(m))), false);
			int selected = selectedIndex();
			int sx = swatchStartX();
			int sy = y + (height - SWATCH_SIZE) / 2;
			for (int i = 0; i < PALETTE.length; i++) {
				int x = sx + i * SWATCH_CELL;
				if (i == selected) {
					Draw.roundRect(g, x - 2, sy - 2, SWATCH_SIZE + 4, SWATCH_SIZE + 4, 5, c(KNOB));
					Draw.roundRect(g, x - 1, sy - 1, SWATCH_SIZE + 2, SWATCH_SIZE + 2, 4, c(CARD));
				}
				Draw.roundRect(g, x, sy, SWATCH_SIZE, SWATCH_SIZE, 3, c(0xFF000000 | PALETTE[i]));
			}
			if (focused) {
				focusRing(g);
			}
		}

		@Override
		boolean press(float px, float py) {
			int cell = (int) Math.floor((px - swatchStartX() + (SWATCH_CELL - SWATCH_SIZE) / 2f) / SWATCH_CELL);
			if (cell >= 0 && cell < PALETTE.length) {
				select(cell);
				return true;
			}
			return false;
		}

		@Override
		void adjust(int dir) {
			int selected = selectedIndex();
			select(selected < 0 ? (dir > 0 ? 0 : PALETTE.length - 1) : selected + dir);
		}

		@Override
		void activate() {
			select(selectedIndex() + 1);
		}
	}

	// ------------------------------------------------------------------ layout helpers

	private static int trackX() {
		return CARD_X + 12;
	}

	private static int trackW() {
		return CARD_W - 24;
	}

	private void setOpen(Module target, boolean open) {
		for (Module m : modules) {
			m.open = (m == target) ? open : (open ? false : m.open);
		}
		if (dragging != null && !target.open) {
			dragging = null;
		}
		if (layoutH > 0) { // not during construction
			maxScroll = Math.max(0, finalContentHeight() - layoutH);
			if (open) { // bring the opened card to the top of the list
				scrollTarget = Mth.clamp(finalCardY(modules.indexOf(target)) - CARD_Y, 0, maxScroll);
			} else {
				scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
			}
		}
	}

	/** Content height once all accordion animations have finished. */
	private int finalContentHeight() {
		int h = CARD_Y;
		for (Module m : modules) {
			h += CARD_H + (m.open ? m.settingsHeight() : 0) + CARD_GAP;
		}
		return h - CARD_GAP + BOTTOM_PAD;
	}

	/** Unscrolled y of a card once all accordion animations have finished. */
	private int finalCardY(int moduleIndex) {
		int y = CARD_Y;
		for (int i = 0; i < moduleIndex; i++) {
			Module m = modules.get(i);
			y += CARD_H + (m.open ? m.settingsHeight() : 0) + CARD_GAP;
		}
		return y;
	}

	/** Scroll just enough that the given header (row = -1) or row is inside the visible list. */
	private void reveal(int moduleIndex, int rowIndex) {
		if (layoutH <= 0) {
			return;
		}
		int top = finalCardY(moduleIndex);
		int bottom = top + CARD_H;
		if (rowIndex >= 0) {
			Module m = modules.get(moduleIndex);
			int ry = top + CARD_H + 4;
			for (int i = 0; i < rowIndex; i++) {
				ry += m.rows.get(i).height;
			}
			top = ry;
			bottom = ry + m.rows.get(rowIndex).height;
		}
		float viewTop = scrollTarget + LIST_TOP + 3;
		float viewBottom = scrollTarget + layoutH - 8;
		if (top < viewTop) {
			scrollTarget = top - LIST_TOP - 3;
		} else if (bottom > viewBottom) {
			scrollTarget = bottom - layoutH + 8;
		}
		scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
	}

	private void layoutModules() {
		int y = CARD_Y - Math.round(scroll);
		for (Module m : modules) {
			m.y = y;
			m.cardHeight = CARD_H + Math.round(m.settingsHeight() * m.expand);
			int ry = y + CARD_H + 4;
			for (Row r : m.rows) {
				r.y = ry;
				ry += r.height;
			}
			y += m.cardHeight + CARD_GAP;
		}
		contentH = y - CARD_GAP + BOTTOM_PAD + Math.round(scroll);
		panelH = Math.min(contentH, layoutH);
	}

	private void updateLayout() {
		float maxW = Math.max(1f, width - 16f);
		float maxH = Math.max(1f, height - 16f);
		scale = Math.min(1f, Math.min(maxW / PW, maxH / Math.min(fullHeight, COMFORT_H)));
		layoutH = (int) Math.min(fullHeight, Math.floor(maxH / scale));
		originX = (width - PW * scale) / 2f;
		originY = (height - layoutH * scale) / 2f;
		maxScroll = Math.max(0, finalContentHeight() - layoutH);
		scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
		scroll = Mth.clamp(scroll, 0, maxScroll);
		layoutModules();
	}

	private float panelX(double screenX) {
		return (float) ((screenX - originX) / scale);
	}

	private float panelY(double screenY) {
		return (float) ((screenY - originY) / scale);
	}

	private static boolean inRect(float px, float py, int x, int y, int w, int h) {
		return px >= x && px < x + w && py >= y && py < y + h;
	}

	private int c(int argb) {
		return Draw.withAlpha(argb, alpha);
	}

	private int listBottom() {
		return panelH - 4;
	}

	private int scrollTrackTop() {
		return HEADER_H + 6;
	}

	private int scrollTrackHeight() {
		return (panelH - 8) - scrollTrackTop();
	}

	private int scrollThumbHeight() {
		float visible = panelH - HEADER_H;
		float total = Math.max(1f, finalContentHeight() - HEADER_H);
		return Math.max(14, Math.round(scrollTrackHeight() * Mth.clamp(visible / total, 0.1f, 1f)));
	}

	private void dragScrollbar(float py) {
		int travel = scrollTrackHeight() - scrollThumbHeight();
		if (travel <= 0) {
			return;
		}
		float t = (py - scrollTrackTop() - scrollThumbHeight() / 2f) / travel;
		scrollTarget = Mth.clamp(t, 0f, 1f) * maxScroll;
		scroll = scrollTarget;
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
		lastNanos = now;

		updateLayout();
		float px = panelX(mouseX);
		float py = panelY(mouseY);
		boolean pointerInList = py >= LIST_TOP && py < listBottom();

		intro = Draw.approach(intro, 1f, dt, 14f);
		hoverClose = Draw.approach(hoverClose, inRect(px, py, CLOSE_X, CLOSE_Y, CLOSE_SIZE, CLOSE_SIZE) ? 1f : 0f, dt, 18f);
		scroll = scrollbarDrag ? scrollTarget : Draw.approach(scroll, scrollTarget, dt, 18f);
		for (Module m : modules) {
			m.expand = Draw.approach(m.expand, m.open ? 1f : 0f, dt, 14f);
			m.switchAnim = Draw.approach(m.switchAnim, m.on.getAsBoolean() ? 1f : 0f, dt, 16f);
			m.hover = Draw.approach(m.hover,
				pointerInList && inRect(px, py, CARD_X, m.y, CARD_W, CARD_H) ? 1f : 0f, dt, 18f);
			if (m.expand > 0f) {
				for (Row r : m.rows) {
					r.update(dt);
				}
			}
		}
		layoutModules(); // reflect this frame's animation values
		alpha = intro;

		g.fill(0, 0, width, height, c(DIM));

		float k = scale * (0.96f + 0.04f * intro);
		g.pose().pushMatrix();
		g.pose().translate(originX + PW * scale / 2f, originY + layoutH * scale / 2f);
		g.pose().scale(k, k);
		g.pose().translate(-PW / 2f, -layoutH / 2f);

		Font font = this.font;
		Draw.roundRectBordered(g, 0, 0, PW, panelH, 8, c(BORDER), c(BG));
		drawHeader(g, font);

		g.enableScissor(1, LIST_TOP, PW - 1, listBottom());
		for (int i = 0; i < modules.size(); i++) {
			drawModule(g, font, modules.get(i), i);
		}
		g.disableScissor();
		drawScrollbar(g);

		g.pose().popMatrix();
	}

	private void drawHeader(GuiGraphics g, Font font) {
		Draw.roundRect(g, PAD, 12, 3, 16, 1, c(ACCENT));
		int titleY = (HEADER_H - font.lineHeight) / 2;
		g.drawString(font, Component.literal("X1UR").withStyle(ChatFormatting.BOLD), PAD + 11, titleY, c(TEXT), false);
		g.drawString(font, Component.literal("CLIENT").withStyle(ChatFormatting.BOLD),
			PAD + 11 + font.width(Component.literal("X1UR ").withStyle(ChatFormatting.BOLD)), titleY, c(ACCENT), false);

		Draw.roundRect(g, CLOSE_X, CLOSE_Y, CLOSE_SIZE, CLOSE_SIZE, 6, c(Draw.lerpColor(BG, CARD_HOVER, hoverClose)));
		String x = "\u00d7";
		g.drawString(font, x, CLOSE_X + (CLOSE_SIZE - font.width(x)) / 2, CLOSE_Y + (CLOSE_SIZE - font.lineHeight) / 2 + 1,
			c(Draw.lerpColor(SUBTEXT, TEXT, hoverClose)), false);

		g.fill(1, HEADER_H, PW - 1, HEADER_H + 1, c(BORDER));
	}

	private void drawScrollbar(GuiGraphics g) {
		if (maxScroll <= 0.5f || scrollTrackHeight() < 20) {
			return;
		}
		int thumbH = scrollThumbHeight();
		int travel = scrollTrackHeight() - thumbH;
		int thumbY = scrollTrackTop() + Math.round(travel * Mth.clamp(scroll / maxScroll, 0f, 1f));
		Draw.roundRect(g, SCROLLBAR_X, scrollTrackTop(), 3, scrollTrackHeight(), 1, c(TRACK));
		Draw.roundRect(g, SCROLLBAR_X, thumbY, 3, thumbH, 1, c(scrollbarDrag ? ACCENT : ACCENT_BORDER));
	}

	private void drawModule(GuiGraphics g, Font font, Module m, int index) {
		if (m.y > listBottom() || m.y + m.cardHeight < LIST_TOP) {
			return; // fully scrolled out of view
		}
		int border = Draw.lerpColor(BORDER, ACCENT_BORDER, m.switchAnim);
		Draw.roundRectBordered(g, CARD_X, m.y, CARD_W, m.cardHeight, 7, c(border),
			c(Draw.lerpColor(CARD, CARD_HOVER, m.hover * 0.8f)));

		g.drawString(font, m.title, CARD_X + 12, m.y + 9, c(TEXT), false);
		g.drawString(font, m.subtitle, CARD_X + 12, m.y + 22, c(SUBTEXT), false);

		int switchY = m.y + (CARD_H - SWITCH_H) / 2;
		drawChevron(g, SWITCH_X - 16, m.y + CARD_H / 2, m.expand);
		drawSwitchAt(g, SWITCH_X, switchY, m.switchAnim);
		if (keyboardNav && focusModule == index && focusRow == -1) {
			g.renderOutline(SWITCH_X - 2, switchY - 2, SWITCH_W + 4, SWITCH_H + 4, c(ACCENT));
		}

		int visible = Math.round(m.settingsHeight() * m.expand);
		if (visible > 0) {
			float saved = alpha;
			alpha = saved * m.expand;
			g.enableScissor(CARD_X + 1, m.y + CARD_H, CARD_X + CARD_W - 1, m.y + CARD_H + visible);
			g.fill(CARD_X + 12, m.y + CARD_H, CARD_X + CARD_W - 12, m.y + CARD_H + 1, c(BORDER));
			for (int r = 0; r < m.rows.size(); r++) {
				boolean focused = keyboardNav && focusModule == index && focusRow == r;
				m.rows.get(r).render(g, font, m, focused);
			}
			g.disableScissor();
			alpha = saved;
		}
	}

	private void drawSwitchAt(GuiGraphics g, int x, int y, float anim) {
		int track = Draw.lerpColor(OFF, ACCENT, anim);
		Draw.roundRect(g, x, y, SWITCH_W, SWITCH_H, 9, c(track));
		int knobX = x + 3 + Math.round((SWITCH_W - 6 - 12) * anim);
		Draw.roundRect(g, knobX, y + 3, 12, 12, 6, c(KNOB));
	}

	/** V-shaped chevron drawn from pixels: points down when collapsed, up when expanded. */
	private void drawChevron(GuiGraphics g, int cx, int cy, float open) {
		boolean up = open > 0.5f;
		int color = c(SUBTEXT);
		for (int i = 0; i < 4; i++) {
			int row = up ? cy + 1 - i : cy - 2 + i;
			g.fill(cx - 3 + i, row, cx - 2 + i, row + 1, color);
			g.fill(cx + 3 - i, row, cx + 4 - i, row + 1, color);
		}
		g.fill(cx, up ? cy - 2 : cy + 1, cx + 1, up ? cy - 1 : cy + 2, color);
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() != 0) {
			return super.mouseClicked(event, doubleClick);
		}
		keyboardNav = false;
		updateLayout();
		float px = panelX(event.x());
		float py = panelY(event.y());

		if (!inRect(px, py, 0, 0, PW, panelH)) {
			onClose(); // tapping outside the panel closes it (handy on touch screens)
			return true;
		}
		if (inRect(px, py, CLOSE_X - 4, CLOSE_Y - 4, CLOSE_SIZE + 8, CLOSE_SIZE + 8)) {
			onClose();
			return true;
		}
		if (py < LIST_TOP || py >= listBottom()) {
			return true; // header / panel padding
		}
		if (maxScroll > 0.5f && px >= SCROLLBAR_GRAB_X) {
			scrollbarDrag = true;
			dragScrollbar(py);
			return true;
		}
		for (int i = 0; i < modules.size(); i++) {
			Module m = modules.get(i);
			if (inRect(px, py, CARD_X, m.y, CARD_W, CARD_H)) {
				focusModule = i;
				focusRow = -1;
				if (px >= SWITCH_X - 6) {
					m.toggle.run();
				} else {
					setOpen(m, !m.open);
				}
				return true;
			}
			if (m.open && m.expand > 0.5f) {
				for (int r = 0; r < m.rows.size(); r++) {
					Row row = m.rows.get(r);
					if (row.focusable() && inRect(px, py, CARD_X, row.y, CARD_W, row.height)) {
						focusModule = i;
						focusRow = r;
						row.press(px, py);
						return true;
					}
				}
			}
		}
		return true;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (event.button() == 0) {
			if (scrollbarDrag) {
				dragScrollbar(panelY(event.y()));
				return true;
			}
			if (dragging != null) {
				dragging.drag(panelX(event.x()));
				return true;
			}
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (scrollbarDrag) {
			scrollbarDrag = false;
			return true;
		}
		if (dragging != null) {
			Row row = dragging;
			dragging = null;
			row.release();
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (maxScroll > 0.5f) {
			scrollTarget = Mth.clamp(scrollTarget - (float) scrollY * 28f, 0f, maxScroll);
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	/** (module index, row index or -1) pairs in navigation order. */
	private List<int[]> focusTargets() {
		List<int[]> list = new ArrayList<>();
		for (int i = 0; i < modules.size(); i++) {
			Module m = modules.get(i);
			list.add(new int[] {i, -1});
			if (m.open) {
				for (int r = 0; r < m.rows.size(); r++) {
					if (m.rows.get(r).focusable()) {
						list.add(new int[] {i, r});
					}
				}
			}
		}
		return list;
	}

	private int indexOfFocus(List<int[]> targets) {
		for (int i = 0; i < targets.size(); i++) {
			if (targets.get(i)[0] == focusModule && targets.get(i)[1] == focusRow) {
				return i;
			}
		}
		for (int i = 0; i < targets.size(); i++) { // focused row got collapsed: fall back to its module header
			if (targets.get(i)[0] == focusModule && targets.get(i)[1] == -1) {
				return i;
			}
		}
		return 0;
	}

	private void applyFocus(int[] target) {
		focusModule = target[0];
		focusRow = target[1];
		reveal(focusModule, focusRow);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (openKey.matches(event)) {
			onClose();
			return true;
		}
		if (event.isEscape()) {
			return super.keyPressed(event);
		}

		List<int[]> targets = focusTargets();
		int idx = indexOfFocus(targets);
		int size = targets.size();

		if (event.isDown() || (event.isCycleFocus() && !event.hasShiftDown())) {
			keyboardNav = true;
			idx = event.isCycleFocus() ? (idx + 1) % size : Math.min(size - 1, idx + 1);
			applyFocus(targets.get(idx));
			return true;
		}
		if (event.isUp() || event.isCycleFocus()) {
			keyboardNav = true;
			idx = event.isCycleFocus() ? (idx - 1 + size) % size : Math.max(0, idx - 1);
			applyFocus(targets.get(idx));
			return true;
		}

		int[] current = targets.get(idx);
		Module m = modules.get(current[0]);
		if (event.isLeft() || event.isRight()) {
			keyboardNav = true;
			int dir = event.isRight() ? 1 : -1;
			applyFocus(current);
			if (current[1] == -1) {
				setOpen(m, dir > 0);
			} else {
				m.rows.get(current[1]).adjust(dir);
			}
			return true;
		}
		if (event.isConfirmation() || event.isSelection()) {
			keyboardNav = true;
			applyFocus(current);
			if (current[1] == -1) {
				m.toggle.run();
			} else {
				m.rows.get(current[1]).activate();
			}
			return true;
		}
		return super.keyPressed(event);
	}

	// ------------------------------------------------------------------ screen behaviour

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		config.save();
		Minecraft.getInstance().setScreen(null);
	}

	@Override
	public void removed() {
		config.save();
		super.removed();
	}
}
