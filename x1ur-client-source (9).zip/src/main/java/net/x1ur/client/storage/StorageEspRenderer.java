package net.x1ur.client.storage;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Rendering layer of Storage ESP.
 *
 * <p>Draws one 3D wireframe box per entry of {@link StorageTracker}'s draw list, through walls, in a single
 * draw call at Fabric's {@code WorldRenderEvents.END_MAIN}. It uses vanilla's screen-space line pipeline
 * ({@code RenderPipelines.LINES_SNIPPET}) with depth testing disabled, and vanilla's
 * {@code RenderType.draw} path for upload/draw, so it follows the engine's own conventions for 1.21.11.
 *
 * <p>Optional extras (all off by default except the type filters): one tracer line per entry from the crosshair to the
 * box centre in the type's tracer color, and a billboarded name/distance label on the nearest entries.
 *
 * <p>Per frame it only walks the already-cached draw list (distance + behind-camera culling, at most
 * {@link #MAX_BOXES} boxes). No world access, no scanning. The vertex buffer allocator is reused.
 * Pure client-side drawing: nothing here touches blocks, inventories or the network.
 */
public final class StorageEspRenderer {
	private static final float LINE_WIDTH = 2.0f;
	/** Safety valve for extreme storage farms on low-end devices (24 vertices per box). */
	private static final int MAX_BOXES = 1024;
	/** Half-diagonal of the largest outlined box (double chest) is ~1.3; cull only when clearly behind. */
	private static final double BEHIND_CAMERA_MARGIN = -2.0;
	/** Tracers start this far in front of the camera, i.e. at the crosshair (same convention as Netherite Finder). */
	private static final float TRACER_START_DISTANCE = 0.4f;
	/** Labels: only the nearest few, within this distance, so a storage room does not become a wall of text. */
	private static final int MAX_LABELS = 24;
	private static final double LABEL_MAX_DISTANCE = 64.0;
	private static final float LABEL_SCALE_PER_BLOCK = 0.004f;
	private static final float LABEL_MIN_SCALE = 0.03f;
	private static final float LABEL_MAX_SCALE = 0.25f;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/storage_esp_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withDepthWrite(false)
			.build()
	);
	private static final RenderType RENDER_TYPE = RenderType.create(
		"x1ur_storage_esp",
		RenderSetup.builder(PIPELINE).createRenderSetup()
	);

	// scratch objects reused every frame (no per-frame allocations in the draw loop)
	private static final Vector3f FORWARD = new Vector3f();
	private final int[] argbByType = new int[StorageType.VALUES.length];
	private final int[] tracerArgbByType = new int[StorageType.VALUES.length];
	private final boolean[] enabledByType = new boolean[StorageType.VALUES.length];
	private final Matrix4f labelMatrix = new Matrix4f();
	private Quaternionf orientation;
	private ByteBufferBuilder textAllocator;
	private MultiBufferSource.BufferSource textSource;

	private final StorageTracker tracker;
	private final X1urConfig config;
	private ByteBufferBuilder allocator;
	private MultiBufferSource.BufferSource bufferSource;
	private boolean failed;

	public StorageEspRenderer(StorageTracker tracker, X1urConfig config) {
		this.tracker = tracker;
		this.config = config;
	}

	/** Registered for {@code WorldRenderEvents.END_MAIN}. */
	public void render(WorldRenderContext context) {
		if (!config.storageEspEnabled || failed || tracker.drawCount == 0) {
			return;
		}
		try {
			draw(context);
		} catch (RuntimeException e) {
			// Never take the game down because of an overlay; disable rendering for this session and say why.
			failed = true;
			X1urClient.LOGGER.error("Storage ESP rendering failed and was disabled for this session", e);
		}
	}

	private void draw(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		CameraRenderState camera = context.worldState().cameraRenderState;
		Vec3 cam = camera.pos;
		camera.orientation.transform(0f, 0f, -1f, FORWARD);
		orientation = camera.orientation;
		double fx = FORWARD.x, fy = FORWARD.y, fz = FORWARD.z;
		float sx = (float) fx * TRACER_START_DISTANCE;
		float sy = (float) fy * TRACER_START_DISTANCE;
		float sz = (float) fz * TRACER_START_DISTANCE;

		double maxDistance = config.storageMaxDistance;
		double maxDistanceSq = maxDistance * maxDistance;
		int alpha = Math.round(255f * config.storageOutlineVisibility / 100f);
		for (StorageType type : StorageType.VALUES) {
			argbByType[type.ordinal()] = (alpha << 24) | type.color(config);
			tracerArgbByType[type.ordinal()] = (alpha << 24) | type.tracerColor(config);
			enabledByType[type.ordinal()] = type.enabled(config);
		}
		boolean tracers = config.storageTracers;
		boolean labels = config.storageLabels;
		boolean distanceText = config.storageDistance;
		Font font = mc.font;

		StorageTracker.Entry[] list = tracker.drawList;
		int count = tracker.drawCount;
		VertexConsumer consumer = null;
		boolean wroteText = false;
		int labelsDrawn = 0;
		int drawn = 0;

		for (int i = 0; i < count && drawn < MAX_BOXES; i++) {
			StorageTracker.Entry e = list[i];
			int t = e.type.ordinal();
			if (!enabledByType[t]) {
				continue; // filtered out: no outline, tracer or label
			}
			double dx = (e.minX + e.maxX) * 0.5 - cam.x;
			double dy = (e.minY + e.maxY) * 0.5 - cam.y;
			double dz = (e.minZ + e.maxZ) * 0.5 - cam.z;
			double distSq = dx * dx + dy * dy + dz * dz;
			if (distSq > maxDistanceSq) {
				continue;
			}
			double ahead = fx * dx + fy * dy + fz * dz;
			if (ahead < BEHIND_CAMERA_MARGIN) {
				continue;
			}
			if (consumer == null) {
				consumer = beginBatch();
			}
			box(consumer,
				(float) (e.minX - cam.x), (float) (e.minY - cam.y), (float) (e.minZ - cam.z),
				(float) (e.maxX - cam.x), (float) (e.maxY - cam.y), (float) (e.maxZ - cam.z),
				argbByType[t]);
			drawn++;

			// one tracer per draw-list entry; a double chest is a single entry, so it gets a single tracer.
			// A target behind the camera would need near-plane clipping of the line, so those are skipped.
			if (tracers && ahead > 0.0) {
				float tx = (float) dx - sx;
				float ty = (float) dy - sy;
				float tz = (float) dz - sz;
				float len = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
				if (len > 1.0e-4f) {
					line(consumer, sx, sy, sz, (float) dx, (float) dy, (float) dz, tx / len, ty / len, tz / len,
						tracerArgbByType[t]);
				}
			}

			if (labels && labelsDrawn < MAX_LABELS && ahead > 0.0 && distSq <= LABEL_MAX_DISTANCE * LABEL_MAX_DISTANCE) {
				String text = e.type.label;
				if (distanceText) {
					double px = (e.minX + e.maxX) * 0.5 - mc.player.getX();
					double py = (e.minY + e.maxY) * 0.5 - mc.player.getY();
					double pz = (e.minZ + e.maxZ) * 0.5 - mc.player.getZ();
					text += " " + Math.round(Math.sqrt(px * px + py * py + pz * pz)) + "m";
				}
				drawLabel(font, text, (float) dx, (float) (e.maxY - cam.y + 0.35), (float) dz, argbByType[t] | 0xFF000000);
				labelsDrawn++;
				wroteText = true;
			}
		}

		if (consumer != null) {
			bufferSource.endBatch();
		}
		if (wroteText) {
			textSource.endBatch();
		}
	}

	/** Camera-relative, camera-facing text at (x, y, z); size grows with distance so it stays readable. */
	private void drawLabel(Font font, String text, float x, float y, float z, int argb) {
		if (textAllocator == null) {
			textAllocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			textSource = MultiBufferSource.immediate(textAllocator);
		}
		float distance = (float) Math.sqrt(x * x + y * y + z * z);
		float scale = Math.min(LABEL_MAX_SCALE, Math.max(LABEL_MIN_SCALE, distance * LABEL_SCALE_PER_BLOCK));
		labelMatrix.identity().translate(x, y, z).rotate(orientation).scale(scale, -scale, scale);
		font.drawInBatch(text, -font.width(text) / 2f, 0f, argb, false, labelMatrix, textSource,
			Font.DisplayMode.SEE_THROUGH, 0x66000000, LightTexture.FULL_BRIGHT);
	}

	private VertexConsumer beginBatch() {
		if (allocator == null) {
			allocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			bufferSource = MultiBufferSource.immediate(allocator);
		}
		return bufferSource.getBuffer(RENDER_TYPE);
	}

	/** 12 edges of a camera-relative box. Normals carry the (world-space) line direction, as vanilla does. */
	private static void box(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
		// edges along X
		line(c, x0, y0, z0, x1, y0, z0, 1, 0, 0, argb);
		line(c, x0, y1, z0, x1, y1, z0, 1, 0, 0, argb);
		line(c, x0, y0, z1, x1, y0, z1, 1, 0, 0, argb);
		line(c, x0, y1, z1, x1, y1, z1, 1, 0, 0, argb);
		// edges along Y
		line(c, x0, y0, z0, x0, y1, z0, 0, 1, 0, argb);
		line(c, x1, y0, z0, x1, y1, z0, 0, 1, 0, argb);
		line(c, x0, y0, z1, x0, y1, z1, 0, 1, 0, argb);
		line(c, x1, y0, z1, x1, y1, z1, 0, 1, 0, argb);
		// edges along Z
		line(c, x0, y0, z0, x0, y0, z1, 0, 0, 1, argb);
		line(c, x1, y0, z0, x1, y0, z1, 0, 0, 1, argb);
		line(c, x0, y1, z0, x0, y1, z1, 0, 0, 1, argb);
		line(c, x1, y1, z0, x1, y1, z1, 0, 0, 1, argb);
	}

	private static void line(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
							 float nx, float ny, float nz, int argb) {
		c.addVertex(x0, y0, z0).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
		c.addVertex(x1, y1, z1).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
	}
}
