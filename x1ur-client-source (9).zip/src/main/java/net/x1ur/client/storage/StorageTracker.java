package net.x1ur.client.storage;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Detection layer of Storage ESP. It never scans chunks.
 *
 * <p>Storage block entities are collected incrementally from Fabric's client block-entity load/unload events
 * (fired when chunks load/unload and when blocks with block entities are placed/removed). A small, bounded
 * revalidation over the <i>cached entries only</i> runs a few times per second (and shortly after changes) to
 * drop stale entries, refresh hit-box bounds and merge the two halves of double chests into one box.
 * The renderer only reads the resulting draw list; it performs no lookups.
 *
 * <p>All methods must be called on the client thread (Fabric fires every hook used here on that thread).
 * This class is read-only with respect to the world: it never modifies blocks, inventories or sends packets.
 */
public final class StorageTracker {
	private static final int REBUILD_INTERVAL_TICKS = 20;
	private static final int DIRTY_REBUILD_MIN_TICKS = 5;
	private static final AABB FULL_BLOCK = new AABB(0, 0, 0, 1, 1, 1);
	private static final Comparator<Entry> BY_DISTANCE = Comparator.comparingDouble(e -> e.distanceSq);

	/** One tracked storage block. Bounds are absolute world coordinates. */
	static final class Entry {
		final BlockEntity blockEntity;
		final BlockPos pos;
		final StorageType type;
		double minX, minY, minZ, maxX, maxY, maxZ;
		boolean draw;
		double distanceSq;

		Entry(BlockEntity blockEntity, StorageType type) {
			this.blockEntity = blockEntity;
			this.pos = blockEntity.getBlockPos().immutable();
			this.type = type;
		}

		void setBounds(AABB local) {
			minX = pos.getX() + local.minX;
			minY = pos.getY() + local.minY;
			minZ = pos.getZ() + local.minZ;
			maxX = pos.getX() + local.maxX;
			maxY = pos.getY() + local.maxY;
			maxZ = pos.getZ() + local.maxZ;
		}

		void union(Entry other) {
			minX = Math.min(minX, other.minX);
			minY = Math.min(minY, other.minY);
			minZ = Math.min(minZ, other.minZ);
			maxX = Math.max(maxX, other.maxX);
			maxY = Math.max(maxY, other.maxY);
			maxZ = Math.max(maxZ, other.maxZ);
		}
	}

	private final Map<Long, Entry> entries = new HashMap<>();
	private ClientLevel level;
	private boolean dirty;
	private int ticks;
	private int lastRebuildTick;

	/** Boxes to draw, nearest first at the time of the last rebuild. Only the first {@code drawCount} are valid. */
	Entry[] drawList = new Entry[64];
	int drawCount;

	// ------------------------------------------------------------------ events

	public void onBlockEntityLoad(BlockEntity blockEntity, ClientLevel world) {
		StorageType type = classify(blockEntity);
		if (type == null) {
			return;
		}
		switchLevel(world);
		Entry entry = new Entry(blockEntity, type);
		entries.put(entry.pos.asLong(), entry);
		dirty = true;
	}

	public void onBlockEntityUnload(BlockEntity blockEntity, ClientLevel world) {
		if (world != level) {
			return;
		}
		long key = blockEntity.getBlockPos().asLong();
		Entry existing = entries.get(key);
		if (existing != null && existing.blockEntity == blockEntity) {
			entries.remove(key);
			dirty = true;
		}
	}

	/** Forget everything (joining/leaving a server or world). */
	public void clear() {
		entries.clear();
		Arrays.fill(drawList, null);
		drawCount = 0;
		level = null;
		dirty = false;
	}

	// ------------------------------------------------------------------ per tick

	/**
	 * Called once per client tick. While the module is disabled nothing is revalidated (cached entries are
	 * kept up to date by the events only), so a disabled Storage ESP costs essentially nothing.
	 */
	public void tick(Minecraft mc, boolean enabled) {
		ClientLevel current = mc.level;
		if (current != level) { // dimension change / new world: drop entries of the previous level
			clear();
			level = current;
		}
		if (!enabled || current == null || mc.player == null) {
			drawCount = 0;
			return;
		}
		ticks++;
		int since = ticks - lastRebuildTick;
		if (since >= REBUILD_INTERVAL_TICKS || (dirty && since >= DIRTY_REBUILD_MIN_TICKS)) {
			rebuild(current, mc.player.position());
			lastRebuildTick = ticks;
			dirty = false;
		}
	}

	// ------------------------------------------------------------------ internals

	private void switchLevel(ClientLevel world) {
		if (world != level) {
			clear();
			level = world;
		}
	}

	private static StorageType classify(BlockEntity be) {
		if (be instanceof TrappedChestBlockEntity) {
			return StorageType.TRAPPED_CHEST; // must be tested before ChestBlockEntity (its superclass)
		}
		if (be instanceof ChestBlockEntity) {
			return StorageType.CHEST;
		}
		if (be instanceof EnderChestBlockEntity) {
			return StorageType.ENDER_CHEST;
		}
		if (be instanceof BarrelBlockEntity) {
			return StorageType.BARREL;
		}
		if (be instanceof ShulkerBoxBlockEntity) {
			return StorageType.SHULKER_BOX;
		}
		return null;
	}

	private void rebuild(ClientLevel world, Vec3 playerPos) {
		// 1) drop stale entries, refresh bounds from the current block state
		Iterator<Entry> it = entries.values().iterator();
		while (it.hasNext()) {
			Entry e = it.next();
			if (e.blockEntity.isRemoved() || world.getBlockEntity(e.pos) != e.blockEntity) {
				it.remove();
				continue;
			}
			e.setBounds(localBounds(e, world));
			e.draw = true;
		}

		// 2) double chests: exactly one of the two halves draws the union box
		for (Entry e : entries.values()) {
			if (!e.type.canBeDouble()) {
				continue;
			}
			BlockState state = world.getBlockState(e.pos);
			Direction toPartner = connectedDirection(state);
			if (toPartner == null) {
				continue;
			}
			Entry partner = entries.get(e.pos.relative(toPartner).asLong());
			if (partner == null || partner.type != e.type) {
				continue; // partner chunk/BE not loaded: outline just this half
			}
			BlockState partnerState = world.getBlockState(partner.pos);
			if (partnerState.getBlock() != state.getBlock() || connectedDirection(partnerState) != toPartner.getOpposite()) {
				continue;
			}
			if (e.pos.asLong() < partner.pos.asLong()) {
				e.union(partner);
			} else {
				e.draw = false;
			}
		}

		// 3) publish the draw list, nearest first (so the renderer's box cap keeps the closest ones)
		if (drawList.length < entries.size()) {
			drawList = new Entry[Math.max(entries.size(), drawList.length * 2)];
		}
		int count = 0;
		for (Entry e : entries.values()) {
			if (!e.draw) {
				continue;
			}
			double dx = (e.minX + e.maxX) * 0.5 - playerPos.x;
			double dy = (e.minY + e.maxY) * 0.5 - playerPos.y;
			double dz = (e.minZ + e.maxZ) * 0.5 - playerPos.z;
			e.distanceSq = dx * dx + dy * dy + dz * dz;
			drawList[count++] = e;
		}
		Arrays.sort(drawList, 0, count, BY_DISTANCE);
		Arrays.fill(drawList, count, drawList.length, null);
		drawCount = count;
	}

	private static AABB localBounds(Entry e, ClientLevel world) {
		if (e.type == StorageType.SHULKER_BOX) {
			return FULL_BLOCK; // shulker hit-box animates while opening; keep the outline stable
		}
		VoxelShape shape = world.getBlockState(e.pos).getShape(world, e.pos);
		return shape.isEmpty() ? FULL_BLOCK : shape.bounds();
	}

	/** Direction towards the other half if {@code state} is one half of a double chest, else null. */
	private static Direction connectedDirection(BlockState state) {
		if (!state.hasProperty(ChestBlock.TYPE) || state.getValue(ChestBlock.TYPE) == ChestType.SINGLE) {
			return null;
		}
		return ChestBlock.getConnectedDirection(state);
	}
}
