package net.x1ur.client.storage;

import net.x1ur.client.config.X1urConfig;

/** Storage block kinds highlighted by Storage ESP. Each has its own outline color, tracer color and filter. */
public enum StorageType {
	CHEST("Chest"),
	TRAPPED_CHEST("Trapped Chest"),
	ENDER_CHEST("Ender Chest"),
	BARREL("Barrel"),
	SHULKER_BOX("Shulker Box");

	/** Cached to avoid the defensive array copy of {@link #values()} in hot paths. */
	public static final StorageType[] VALUES = values();

	public final String label;

	StorageType(String label) {
		this.label = label;
	}

	/** True for kinds that can form double chests. */
	public boolean canBeDouble() {
		return this == CHEST || this == TRAPPED_CHEST;
	}

	/** Outline color as 0xRRGGBB. */
	public int color(X1urConfig config) {
		return switch (this) {
			case CHEST -> config.chestColor;
			case TRAPPED_CHEST -> config.trappedChestColor;
			case ENDER_CHEST -> config.enderChestColor;
			case BARREL -> config.barrelColor;
			case SHULKER_BOX -> config.shulkerBoxColor;
		};
	}

	public void setColor(X1urConfig config, int rgb) {
		rgb &= 0xFFFFFF;
		switch (this) {
			case CHEST -> config.chestColor = rgb;
			case TRAPPED_CHEST -> config.trappedChestColor = rgb;
			case ENDER_CHEST -> config.enderChestColor = rgb;
			case BARREL -> config.barrelColor = rgb;
			case SHULKER_BOX -> config.shulkerBoxColor = rgb;
		}
	}

	/** Tracer line color as 0xRRGGBB. */
	public int tracerColor(X1urConfig config) {
		return switch (this) {
			case CHEST -> config.chestTracerColor;
			case TRAPPED_CHEST -> config.trappedChestTracerColor;
			case ENDER_CHEST -> config.enderChestTracerColor;
			case BARREL -> config.barrelTracerColor;
			case SHULKER_BOX -> config.shulkerBoxTracerColor;
		};
	}

	public void setTracerColor(X1urConfig config, int rgb) {
		rgb &= 0xFFFFFF;
		switch (this) {
			case CHEST -> config.chestTracerColor = rgb;
			case TRAPPED_CHEST -> config.trappedChestTracerColor = rgb;
			case ENDER_CHEST -> config.enderChestTracerColor = rgb;
			case BARREL -> config.barrelTracerColor = rgb;
			case SHULKER_BOX -> config.shulkerBoxTracerColor = rgb;
		}
	}

	/** Type filter: false hides this type entirely (outline, tracer and label). */
	public boolean enabled(X1urConfig config) {
		return switch (this) {
			case CHEST -> config.showChests;
			case TRAPPED_CHEST -> config.showTrappedChests;
			case ENDER_CHEST -> config.showEnderChests;
			case BARREL -> config.showBarrels;
			case SHULKER_BOX -> config.showShulkerBoxes;
		};
	}

	public void setEnabled(X1urConfig config, boolean value) {
		switch (this) {
			case CHEST -> config.showChests = value;
			case TRAPPED_CHEST -> config.showTrappedChests = value;
			case ENDER_CHEST -> config.showEnderChests = value;
			case BARREL -> config.showBarrels = value;
			case SHULKER_BOX -> config.showShulkerBoxes = value;
		}
	}
}
