package net.x1ur.client.amethyst;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.x1ur.client.X1urClient;
import net.x1ur.client.base.BaseResults;
import net.x1ur.client.config.X1urConfig;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Amethyst ESP: scanning half. Finds amethyst crystals in chunks the client already has and publishes them, nearest
 * first, in a {@link BaseResults} list (Base ESP's flat result list is reused; the "kind" byte is one of the
 * {@code CLUSTER}/{@code LARGE}/{@code MEDIUM}/{@code SMALL} constants below).
 *
 * <h2>What counts as a target</h2>
 * Blocks are compared by identity ({@code state.is(Blocks.X)}). <b>An {@code instanceof} check would be wrong:</b> in
 * 1.21.11 the cluster and all three buds are the same class ({@code AmethystClusterBlock}). Budding amethyst
 * ({@code Blocks.BUDDING_AMETHYST}, a different class, and the plain amethyst block) are never targets.
 * <ul>
 *   <li>CLUSTER = {@code Blocks.AMETHYST_CLUSTER} - the fully grown crystal and the primary target;</li>
 *   <li>LARGE / MEDIUM / SMALL = the corresponding {@code *_AMETHYST_BUD} blocks, each with its own switch.</li>
 * </ul>
 *
 * <h2>Algorithm</h2>
 * <ol>
 *   <li><b>Per-chunk cache</b> ({@link ChunkData}): every crystal of the chunk with its real hit-box (from the block
 *       state's own shape) and kind. A chunk section is read block by block only if its palette reports a crystal
 *       ({@code maybeHas}); everything else is skipped without touching blocks. All four kinds are always cached while
 *       the module is on, so switching a category only rebuilds the published list - it never rescans chunks.</li>
 *   <li><b>Budget</b>: chunks inside the scan radius (never beyond the render distance) are scanned nearest-first, at
 *       most {@link #MAX_SECTIONS_PER_TICK} sections and {@link #TICK_BUDGET_NANOS} per tick. A cached chunk is rescanned
 *       after {@link #RESCAN_TICKS} (the client has no block-change event) or when it is reloaded; unchanged rescans do
 *       not trigger a republish.</li>
 *   <li><b>Publish</b>: the enabled kinds of all cached chunks are sorted by distance and copied into the result list
 *       (capped at {@link #MAX_RESULTS}) every {@link #PUBLISH_TICKS} ticks and whenever data or settings changed.</li>
 *   <li><b>Staleness</b>: unloaded chunks, chunks outside the radius, a new level, a dimension change and disconnects drop
 *       their cache entries immediately; the renderer only ever sees published, current results.</li>
 * </ol>
 *
 * <p>Everything runs on the client thread. The scan never loads chunks ({@code getChunk(..., false)} returns null for
 * chunks the client does not have), reads only data the server already sent and cannot see crystals the server hides
 * (Anti-Xray) or in chunks that are not loaded. Master off: no scanning, no event work, caches released, settings kept.
 */
public final class AmethystEsp {
	public static final byte CLUSTER = 0;
	public static final byte LARGE = 1;
	public static final byte MEDIUM = 2;
	public static final byte SMALL = 3;

	private static final AABB FULL_BLOCK = new AABB(0, 0, 0, 1, 1, 1);
	static final int RESCAN_TICKS = 300;
	static final int PUBLISH_TICKS = 20;
	private static final long TICK_BUDGET_NANOS = 1_500_000L;
	private static final int MAX_SECTIONS_PER_TICK = 24;
	private static final int MAX_RESULTS = 1024;

	/** Cached scan result of one chunk: parallel arrays, boxes are absolute world coordinates (6 doubles each). */
	private static final class ChunkData {
		double[] boxes = new double[0];
		byte[] kinds = new byte[0];
		long scannedAtTick;
		boolean dirty = true;

		int count() {
			return kinds.length;
		}
	}

	private final X1urConfig config;
	private final BaseResults results = new BaseResults();
	private final Map<Long, ChunkData> chunks = new HashMap<>();
	private final ArrayList<ChunkPos> queue = new ArrayList<>();

	// scratch arrays reused by publish() (grow only)
	private double[] scratchBoxes = new double[6 * 64];
	private byte[] scratchKinds = new byte[64];
	private long[] scratchKeys = new long[64];

	private ClientLevel level;
	private ResourceKey<Level> dimension;
	private boolean active;
	private boolean publishDirty;
	private boolean scanChanged;
	private int lastSettingsKey;
	private long tickCounter;
	private long lastPublishTick;
	private int lastPublishedCount = -1;

	public AmethystEsp(X1urConfig config) {
		this.config = config;
	}

	/** Results for the renderer: empty whenever the module is off or the world changed. Nearest first. */
	public BaseResults results() {
		return results;
	}

	/** Registers the Fabric chunk events. Called exactly once from the client initialiser. */
	public void register() {
		ClientChunkEvents.CHUNK_LOAD.register(this::onChunkLoad);
		ClientChunkEvents.CHUNK_UNLOAD.register(this::onChunkUnload);
	}

	/** Forget everything (join / disconnect). Settings are not touched. */
	public void clear() {
		if (results.count() > 0) {
			X1urClient.LOGGER.debug("Amethyst ESP: cleared {} targets and {} cached chunks", results.count(), chunks.size());
		}
		chunks.clear();
		queue.clear();
		results.clear();
		level = null;
		dimension = null;
		publishDirty = false;
		lastPublishedCount = -1;
	}

	private void onChunkLoad(ClientLevel world, LevelChunk chunk) {
		if (!config.amethystEspEnabled || world != level) {
			return;
		}
		ChunkData data = chunks.get(chunk.getPos().toLong());
		if (data != null) {
			data.dirty = true; // reloaded with possibly different data
		}
	}

	private void onChunkUnload(ClientLevel world, LevelChunk chunk) {
		if (chunks.remove(chunk.getPos().toLong()) != null) {
			publishDirty = true; // its crystals must disappear immediately
		}
	}

	/** True if something would be drawn for these settings (otherwise scanning is pointless). */
	private boolean hasWork() {
		boolean anyKind = config.amethystClusters || config.amethystLargeBuds
			|| config.amethystMediumBuds || config.amethystSmallBuds;
		return anyKind && (config.amethystOutline || config.amethystLabels);
	}

	private int settingsKey() {
		int key = config.amethystScanRadius;
		key = key * 2 + (config.amethystClusters ? 1 : 0);
		key = key * 2 + (config.amethystLargeBuds ? 1 : 0);
		key = key * 2 + (config.amethystMediumBuds ? 1 : 0);
		key = key * 2 + (config.amethystSmallBuds ? 1 : 0);
		return key;
	}

	/** Called at the end of every client tick. */
	public void tick(Minecraft mc) {
		tickCounter++;
		ClientLevel current = mc.level;
		boolean usable = config.amethystEspEnabled && current != null && mc.player != null && hasWork();

		if (!usable) {
			if (active || !chunks.isEmpty() || results.count() > 0) {
				clear(); // master off / nothing to show / no world: stop all work and release memory
			}
			active = false;
			return;
		}
		active = true;

		ResourceKey<Level> dim = current.dimension();
		if (current != level || dim != dimension) { // new world or dimension change: nothing may carry over
			clear();
			level = current;
			dimension = dim;
		}

		int radius = Math.min(config.amethystScanRadius, mc.options.getEffectiveRenderDistance());
		BlockPos playerPos = mc.player.blockPosition();
		int centerX = playerPos.getX() >> 4;
		int centerZ = playerPos.getZ() >> 4;

		dropFarChunks(centerX, centerZ, radius);
		scanWithinBudget(current, centerX, centerZ, radius);

		int key = settingsKey();
		if (key != lastSettingsKey) {
			lastSettingsKey = key;
			publishDirty = true;
		}
		if (publishDirty || tickCounter - lastPublishTick >= PUBLISH_TICKS) {
			publish(mc.player.getX(), mc.player.getY(), mc.player.getZ());
			lastPublishTick = tickCounter;
			publishDirty = false;
		}
	}

	/** Chunks that left the radius are forgotten, so memory stays proportional to the radius. */
	private void dropFarChunks(int centerX, int centerZ, int radius) {
		for (Iterator<Long> it = chunks.keySet().iterator(); it.hasNext(); ) {
			long key = it.next();
			if (Math.abs(ChunkPos.getX(key) - centerX) > radius || Math.abs(ChunkPos.getZ(key) - centerZ) > radius) {
				it.remove();
				publishDirty = true;
			}
		}
	}

	private void scanWithinBudget(ClientLevel world, int centerX, int centerZ, int radius) {
		queue.clear();
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				ChunkPos pos = new ChunkPos(centerX + dx, centerZ + dz);
				ChunkData data = chunks.get(pos.toLong());
				if (data == null || data.dirty || tickCounter - data.scannedAtTick >= RESCAN_TICKS) {
					queue.add(pos);
				}
			}
		}
		if (queue.isEmpty()) {
			return;
		}
		queue.sort((a, b) -> Integer.compare(dist2(a, centerX, centerZ), dist2(b, centerX, centerZ)));

		long deadline = System.nanoTime() + TICK_BUDGET_NANOS;
		int sectionsLeft = MAX_SECTIONS_PER_TICK;
		for (ChunkPos pos : queue) {
			if (sectionsLeft <= 0 || System.nanoTime() > deadline) {
				break;
			}
			ChunkAccess chunk = world.getChunk(pos.x, pos.z, ChunkStatus.FULL, false); // never force-loads
			if (chunk == null) {
				continue;
			}
			ChunkData data = chunks.computeIfAbsent(pos.toLong(), k -> new ChunkData());
			sectionsLeft -= scanChunk(chunk, data);
			data.scannedAtTick = tickCounter;
			data.dirty = false;
			publishDirty |= scanChanged;
		}
	}

	private static int dist2(ChunkPos p, int cx, int cz) {
		int dx = p.x - cx;
		int dz = p.z - cz;
		return dx * dx + dz * dz;
	}

	/** Kind of a block state, or -1 if it is not an amethyst crystal. Identity compare, see class comment. */
	private static int kindOf(BlockState state) {
		if (state.is(Blocks.AMETHYST_CLUSTER)) {
			return CLUSTER;
		}
		if (state.is(Blocks.LARGE_AMETHYST_BUD)) {
			return LARGE;
		}
		if (state.is(Blocks.MEDIUM_AMETHYST_BUD)) {
			return MEDIUM;
		}
		if (state.is(Blocks.SMALL_AMETHYST_BUD)) {
			return SMALL;
		}
		return -1;
	}

	private static boolean isCrystal(BlockState state) {
		return kindOf(state) >= 0;
	}

	/** Scans one chunk into its cache entry. Returns the number of sections that had to be read block by block. */
	private int scanChunk(ChunkAccess chunk, ChunkData data) {
		LevelChunkSection[] sections = chunk.getSections();
		int minSection = chunk.getMinSectionY();
		int minX = chunk.getPos().getMinBlockX();
		int minZ = chunk.getPos().getMinBlockZ();
		int read = 0;
		double[] boxes = new double[0];
		byte[] kinds = new byte[0];
		int found = 0;

		for (int s = 0; s < sections.length; s++) {
			LevelChunkSection section = sections[s];
			if (section == null || section.hasOnlyAir() || !section.maybeHas(AmethystEsp::isCrystal)) {
				continue; // nothing of interest in this palette: skip without touching blocks
			}
			read++;
			int baseY = (minSection + s) << 4;
			for (int y = 0; y < 16; y++) {
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						BlockState state = section.getBlockState(x, y, z);
						int kind = kindOf(state);
						if (kind < 0) {
							continue;
						}
						if (found == kinds.length) {
							int cap = Math.max(8, found * 2);
							kinds = Arrays.copyOf(kinds, cap);
							boxes = Arrays.copyOf(boxes, cap * 6);
						}
						// the crystal's own hit-box (depends only on its facing, so no world access is needed)
						VoxelShape shape = state.getShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
						AABB local = shape.isEmpty() ? FULL_BLOCK : shape.bounds();
						int wx = minX + x;
						int wy = baseY + y;
						int wz = minZ + z;
						int o = found * 6;
						boxes[o] = wx + local.minX;
						boxes[o + 1] = wy + local.minY;
						boxes[o + 2] = wz + local.minZ;
						boxes[o + 3] = wx + local.maxX;
						boxes[o + 4] = wy + local.maxY;
						boxes[o + 5] = wz + local.maxZ;
						kinds[found++] = (byte) kind;
					}
				}
			}
		}

		boxes = Arrays.copyOf(boxes, found * 6);
		kinds = Arrays.copyOf(kinds, found);
		scanChanged = !Arrays.equals(data.kinds, kinds) || !Arrays.equals(data.boxes, boxes);
		data.boxes = boxes;
		data.kinds = kinds;
		return Math.max(1, read);
	}

	// ------------------------------------------------------------------ publish

	private boolean enabled(byte kind) {
		return switch (kind) {
			case CLUSTER -> config.amethystClusters;
			case LARGE -> config.amethystLargeBuds;
			case MEDIUM -> config.amethystMediumBuds;
			default -> config.amethystSmallBuds;
		};
	}

	/** Copies the enabled crystals of all cached chunks into the result list, nearest first. */
	private void publish(double px, double py, double pz) {
		int total = 0;
		for (ChunkData data : chunks.values()) {
			total += data.count();
		}
		if (scratchKinds.length < total) {
			int cap = Math.max(total, scratchKinds.length * 2);
			scratchKinds = Arrays.copyOf(scratchKinds, cap);
			scratchBoxes = new double[cap * 6];
			scratchKeys = new long[cap];
		}

		int n = 0;
		for (ChunkData data : chunks.values()) {
			for (int i = 0; i < data.count(); i++) {
				byte kind = data.kinds[i];
				if (!enabled(kind)) {
					continue;
				}
				System.arraycopy(data.boxes, i * 6, scratchBoxes, n * 6, 6);
				scratchKinds[n] = kind;
				double dx = (scratchBoxes[n * 6] + scratchBoxes[n * 6 + 3]) * 0.5 - px;
				double dy = (scratchBoxes[n * 6 + 1] + scratchBoxes[n * 6 + 4]) * 0.5 - py;
				double dz = (scratchBoxes[n * 6 + 2] + scratchBoxes[n * 6 + 5]) * 0.5 - pz;
				// non-negative float bit patterns sort like the values, so (distance bits, index) sorts by distance
				scratchKeys[n] = ((long) Float.floatToIntBits((float) (dx * dx + dy * dy + dz * dz)) << 32) | n;
				n++;
			}
		}
		Arrays.sort(scratchKeys, 0, n);

		results.clear();
		int limit = Math.min(n, MAX_RESULTS);
		for (int i = 0; i < limit; i++) {
			int idx = (int) (scratchKeys[i] & 0xFFFFFFFFL);
			int o = idx * 6;
			results.add(scratchKinds[idx], scratchBoxes[o], scratchBoxes[o + 1], scratchBoxes[o + 2],
				scratchBoxes[o + 3], scratchBoxes[o + 4], scratchBoxes[o + 5]);
		}
		if (limit != lastPublishedCount) { // log only when the number changes, at debug level
			lastPublishedCount = limit;
			X1urClient.LOGGER.debug("Amethyst ESP: {} targets published from {} cached chunks", limit, chunks.size());
		}
	}
}
