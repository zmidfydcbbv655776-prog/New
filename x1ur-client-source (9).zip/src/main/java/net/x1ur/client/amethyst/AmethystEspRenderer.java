package net.x1ur.client.amethyst;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.base.BaseResults;
import net.x1ur.client.config.X1urConfig;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Amethyst ESP: rendering half. Draws the already-published, nearest-first {@link BaseResults} of {@link AmethystEsp}
 * as magenta box outlines (through walls) plus optional billboarded labels ("Amethyst Cluster", "Large Amethyst Bud",
 * ...) with the distance. No world queries and no scanning happen here: per frame it only walks the cached list with
 * distance and behind-camera culling. Labels are limited to the {@link #MAX_LABELS} nearest visible targets because a
 * geode holds dozens of crystals and more text than that is unreadable.
 *
 * <p>Same recipe as the other X1UR overlays: vanilla's line shader with the depth test disabled, written into private
 * reused buffers and flushed at the end of the pass, so no matrix, depth or pipeline state is left behind. Exceptions
 * are caught and disable the overlay for the session instead of crashing the game.
 */
public final class AmethystEspRenderer {
	private static final float LINE_WIDTH = 2.0f;
	private static final double BEHIND_CAMERA_MARGIN = -2.0;
	private static final int MAX_LABELS = 24;
	private static final double LABEL_MAX_DISTANCE = 64.0;
	private static final float LABEL_SCALE_PER_BLOCK = 0.004f;
	private static final float LABEL_MIN_SCALE = 0.03f;
	private static final float LABEL_MAX_SCALE = 0.25f;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/amethyst_esp_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withDepthWrite(false)
			.build()
	);
	private static final RenderType RENDER_TYPE = RenderType.create(
		"x1ur_amethyst_esp", RenderSetup.builder(PIPELINE).createRenderSetup());

	private static final Vector3f FORWARD = new Vector3f();
	private final Matrix4f labelMatrix = new Matrix4f();
	private Quaternionf orientation;

	private final AmethystEsp esp;
	private final X1urConfig config;
	private ByteBufferBuilder lineAllocator;
	private MultiBufferSource.BufferSource lineSource;
	private ByteBufferBuilder textAllocator;
	private MultiBufferSource.BufferSource textSource;
	private boolean failed;

	public AmethystEspRenderer(AmethystEsp esp, X1urConfig config) {
		this.esp = esp;
		this.config = config;
	}

	/** Registered for {@code WorldRenderEvents.END_MAIN}. */
	public void render(WorldRenderContext context) {
		if (!config.amethystEspEnabled || failed || esp.results().count() == 0) {
			return;
		}
		try {
			draw(context);
		} catch (RuntimeException e) {
			failed = true; // never take the game down because of an overlay
			X1urClient.LOGGER.error("Amethyst ESP rendering failed and was disabled for this session", e);
		}
	}

	private void draw(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		BaseResults results = esp.results();
		CameraRenderState camera = context.worldState().cameraRenderState;
		Vec3 cam = camera.pos;
		camera.orientation.transform(0f, 0f, -1f, FORWARD);
		orientation = camera.orientation;
		double fx = FORWARD.x, fy = FORWARD.y, fz = FORWARD.z;

		double maxDistance = (double) Math.min(config.amethystScanRadius, mc.options.getEffectiveRenderDistance()) * 16.0 + 16.0;
		double maxDistanceSq = maxDistance * maxDistance;
		int argb = (Math.round(255f * config.amethystOpacity / 100f) << 24) | config.amethystEspColor;
		boolean outline = config.amethystOutline;
		boolean labels = config.amethystLabels;
		boolean distance = config.amethystDistance;
		Font font = mc.font;

		VertexConsumer lines = null;
		boolean wroteText = false;
		int labelsDrawn = 0;
		for (int i = 0, n = results.count(); i < n; i++) {
			double minX = results.bound(i, 0) - cam.x, minY = results.bound(i, 1) - cam.y, minZ = results.bound(i, 2) - cam.z;
			double maxX = results.bound(i, 3) - cam.x, maxY = results.bound(i, 4) - cam.y, maxZ = results.bound(i, 5) - cam.z;
			double cx = (minX + maxX) * 0.5, cy = (minY + maxY) * 0.5, cz = (minZ + maxZ) * 0.5;
			double distSq = cx * cx + cy * cy + cz * cz;
			if (distSq > maxDistanceSq) {
				continue;
			}
			if (fx * cx + fy * cy + fz * cz < BEHIND_CAMERA_MARGIN) {
				continue; // behind the camera (crystals are small, so the centre test is enough)
			}

			if (outline) {
				if (lines == null) {
					lines = beginLines();
				}
				box(lines, (float) minX, (float) minY, (float) minZ, (float) maxX, (float) maxY, (float) maxZ, argb);
			}
			if (labels && labelsDrawn < MAX_LABELS && distSq <= LABEL_MAX_DISTANCE * LABEL_MAX_DISTANCE
				&& fx * cx + fy * cy + fz * cz > 0.0) {
				String text = nameOf(results.kind(i));
				if (distance) {
					double dx = (results.bound(i, 0) + results.bound(i, 3)) * 0.5 - mc.player.getX();
					double dy = (results.bound(i, 1) + results.bound(i, 4)) * 0.5 - mc.player.getY();
					double dz = (results.bound(i, 2) + results.bound(i, 5)) * 0.5 - mc.player.getZ();
					text += " " + Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz)) + "m";
				}
				drawLabel(font, text, (float) cx, (float) (maxY + 0.35), (float) cz, argb | 0xFF000000);
				labelsDrawn++;
				wroteText = true;
			}
		}

		if (lines != null) {
			lineSource.endBatch(RENDER_TYPE);
		}
		if (wroteText) {
			textSource.endBatch();
		}
	}

	private static String nameOf(byte kind) {
		return switch (kind) {
			case AmethystEsp.CLUSTER -> "Amethyst Cluster";
			case AmethystEsp.LARGE -> "Large Amethyst Bud";
			case AmethystEsp.MEDIUM -> "Medium Amethyst Bud";
			default -> "Small Amethyst Bud";
		};
	}

	/** Camera-relative, camera-facing text at (x, y, z); size grows with distance so it stays readable. */
	private void drawLabel(Font font, String text, float x, float y, float z, int argb) {
		if (textAllocator == null) {
			textAllocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			textSource = MultiBufferSource.immediate(textAllocator);
		}
		float distance = (float) Math.sqrt(x * x + y * y + z * z);
		float scale = Math.min(LABEL_MAX_SCALE, Math.max(LABEL_MIN_SCALE, distance * LABEL_SCALE_PER_BLOCK));
		labelMatrix.identity().translate(x, y, z).rotate(orientation).scale(scale, -scale, scale);
		font.drawInBatch(text, -font.width(text) / 2f, 0f, argb, false, labelMatrix, textSource,
			Font.DisplayMode.SEE_THROUGH, 0x66000000, LightTexture.FULL_BRIGHT);
	}

	private VertexConsumer beginLines() {
		if (lineAllocator == null) {
			lineAllocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			lineSource = MultiBufferSource.immediate(lineAllocator);
		}
		return lineSource.getBuffer(RENDER_TYPE);
	}

	/** 12 edges of a camera-relative box. Normals carry the line direction, as vanilla's shape renderer does. */
	private static void box(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
		line(c, x0, y0, z0, x1, y0, z0, 1, 0, 0, argb);
		line(c, x0, y1, z0, x1, y1, z0, 1, 0, 0, argb);
		line(c, x0, y0, z1, x1, y0, z1, 1, 0, 0, argb);
		line(c, x0, y1, z1, x1, y1, z1, 1, 0, 0, argb);
		line(c, x0, y0, z0, x0, y1, z0, 0, 1, 0, argb);
		line(c, x1, y0, z0, x1, y1, z0, 0, 1, 0, argb);
		line(c, x0, y0, z1, x0, y1, z1, 0, 1, 0, argb);
		line(c, x1, y0, z1, x1, y1, z1, 0, 1, 0, argb);
		line(c, x0, y0, z0, x0, y0, z1, 0, 0, 1, argb);
		line(c, x1, y0, z0, x1, y0, z1, 0, 0, 1, argb);
		line(c, x0, y1, z0, x0, y1, z1, 0, 0, 1, argb);
		line(c, x1, y1, z0, x1, y1, z1, 0, 0, 1, argb);
	}

	private static void line(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
							 float nx, float ny, float nz, int argb) {
		c.addVertex(x0, y0, z0).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
		c.addVertex(x1, y1, z1).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
	}
}
