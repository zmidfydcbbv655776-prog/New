package net.x1ur.client.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

/**
 * Trigger Bot: attacks the valid entity under the crosshair after a configurable reaction delay.
 *
 * <p>Rules: the target comes from vanilla's crosshair pick via {@link CombatTargets} (so never through walls and
 * never beyond normal reach); it must stay under the crosshair continuously for the whole delay (losing it, or
 * switching to another entity, restarts the delay); the attack goes through {@link VanillaAttack}, which requires a
 * fully recharged cooldown and a vanilla-valid attack. While the target is invalid or absent nothing happens, and
 * after a hit the delay has to elapse again. It never moves the camera or the player and does nothing while a screen
 * is open or the player is using an item (eating, blocking, drawing a bow).
 *
 * <p>Latency: it only reacts to what the client currently shows. The server still validates the attack as usual.
 */
public final class TriggerBot {
	private final X1urConfig config;
	private final VanillaAttack attacks;

	private LocalPlayer lastPlayer;
	private ClientLevel lastLevel;
	private int lockedTargetId = -1;
	private long lockedSinceNanos;

	public TriggerBot(X1urConfig config, VanillaAttack attacks) {
		this.config = config;
		this.attacks = attacks;
	}

	public void reset() {
		lockedTargetId = -1;
	}

	/** Called at the end of every client tick. */
	public void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		ClientLevel level = mc.level;
		if (player != lastPlayer || level != lastLevel) { // join, respawn, dimension change, disconnect
			reset();
			lastPlayer = player;
			lastLevel = level;
		}
		if (!config.triggerBotEnabled || player == null || level == null || mc.gameMode == null
			|| mc.screen != null || !player.isAlive() || player.isSpectator() || player.isUsingItem()) {
			lockedTargetId = -1;
			return;
		}

		Entity target = CombatTargets.crosshairTarget(mc, player);
		if (target == null) {
			lockedTargetId = -1; // target lost or invalid: forget it
			return;
		}
		long now = System.nanoTime();
		if (target.getId() != lockedTargetId) {
			lockedTargetId = target.getId();
			lockedSinceNanos = now;
		}
		if (now - lockedSinceNanos < config.triggerBotDelayMs * 1_000_000L) {
			return; // reaction delay not elapsed yet (resolution: one client tick, 50 ms)
		}

		if (attacks.attack(mc, player, target)) {
			lockedSinceNanos = now; // the next hit needs a fresh reaction delay
			X1urClient.LOGGER.debug("Trigger Bot attacked {}", target.getName().getString());
		}
	}
}
