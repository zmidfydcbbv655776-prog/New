package net.x1ur.client.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.AttackRange;

/**
 * Performs a single melee attack exactly the way vanilla does when the attack key is pressed
 * ({@code Minecraft.startAttack}, 1.21.11): same guards, then {@code MultiPlayerGameMode.attack} followed by the
 * main-hand swing. Vanilla itself builds and sends the interaction packet from there; this class never creates or
 * sends any packet of its own and never changes server-side state.
 *
 * <p>On top of vanilla's guards it requires a fully recharged attack cooldown and allows at most one attack per
 * game tick, so Auto Mace and Trigger Bot can never double-hit and neither can fire continuously.
 */
public final class VanillaAttack {
	private long lastAttackGameTime = Long.MIN_VALUE;

	/** Forget the per-tick limiter (world change / disconnect). */
	public void reset() {
		lastAttackGameTime = Long.MIN_VALUE;
	}

	/**
	 * Attacks {@code target} if vanilla would allow it right now and the cooldown is fully charged.
	 *
	 * @return true if an attack was performed
	 */
	public boolean attack(Minecraft mc, LocalPlayer player, Entity target) {
		if (mc.gameMode == null || mc.level == null || mc.hitResult == null) {
			return false;
		}
		long gameTime = mc.level.getGameTime();
		if (gameTime == lastAttackGameTime) {
			return false; // already attacked this tick
		}
		if (player.isSpectator() || player.isHandsBusy()) {
			return false;
		}
		ItemStack held = player.getItemInHand(InteractionHand.MAIN_HAND);
		if (!held.isItemEnabled(mc.level.enabledFeatures()) || player.cannotAttackWithItem(held, 0)) {
			return false;
		}
		if (held.get(DataComponents.PIERCING_WEAPON) != null) {
			return false; // spears use a different vanilla attack path; not handled here
		}
		AttackRange range = held.get(DataComponents.ATTACK_RANGE);
		if (range != null && !range.isInRange(player, mc.hitResult.getLocation())) {
			return false;
		}
		if (player.getAttackStrengthScale(0.5f) < 1.0f) {
			return false; // respect the attack cooldown: no weak, uncharged hits
		}

		mc.gameMode.attack(player, target);
		player.swing(InteractionHand.MAIN_HAND);
		lastAttackGameTime = gameTime;
		return true;
	}
}
