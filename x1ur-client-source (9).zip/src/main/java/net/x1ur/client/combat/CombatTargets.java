package net.x1ur.client.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Target rules shared by Auto Mace and Trigger Bot.
 *
 * <p>The target is taken from vanilla's own crosshair pick ({@code Minecraft.hitResult}). Vanilla only produces an
 * {@link EntityHitResult} for an entity that is within the player's entity interaction range <i>and</i> not hidden
 * behind a closer block, so "no attacks through walls / outside normal reach" is inherited from the game itself
 * and nothing here re-implements or loosens it.
 */
public final class CombatTargets {
	private CombatTargets() {
	}

	/** The entity under the crosshair if it is a valid attack target, else {@code null}. */
	public static Entity crosshairTarget(Minecraft mc, LocalPlayer self) {
		if (mc.hitResult instanceof EntityHitResult hit) {
			Entity entity = hit.getEntity();
			if (isValid(self, entity)) {
				return entity;
			}
		}
		return null;
	}

	/**
	 * Valid targets are other players and hostile mobs ({@link Enemy}). Passive animals, villagers, pets, armor stands,
	 * dead/invisible/spectating entities, teammates, creative/invulnerable players and the player's own mount are not.
	 */
	public static boolean isValid(LocalPlayer self, Entity entity) {
		if (entity == null || entity == self || entity == self.getVehicle()) {
			return false;
		}
		if (!(entity instanceof LivingEntity living)) {
			return false;
		}
		if (!(entity instanceof Player) && !(entity instanceof Enemy)) {
			return false;
		}
		if (!living.isAlive() || living.isDeadOrDying() || living.isSpectator() || !living.isAttackable()) {
			return false;
		}
		if (living.isInvisibleTo(self) || self.isAlliedTo(living)) {
			return false;
		}
		if (!self.canAttack(living)) { // false for invulnerable (e.g. creative) targets and peaceful-mode players
			return false;
		}
		return !(living instanceof Player other) || self.canHarmPlayer(other);
	}
}
