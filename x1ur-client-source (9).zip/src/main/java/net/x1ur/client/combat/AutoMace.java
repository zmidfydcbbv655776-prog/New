package net.x1ur.client.combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MaceItem;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

/**
 * Auto Mace: lands a mace smash attack at the right moment.
 *
 * <p>It is "armed" only when all of this is true: the module is on, the main hand holds a mace, vanilla's own
 * {@link MaceItem#canSmashAttack} says the player is in a smash-capable fall (fall distance above 1.5 blocks, not
 * gliding), no screen is open and the player is alive. When armed and a valid target is under the crosshair
 * (see {@link CombatTargets}) for the configured reaction delay, it performs one vanilla attack through
 * {@link VanillaAttack}. It then stays disarmed until the fall ends, so it fires at most once per fall.
 *
 * <p>Activation modes: <b>Hold Attack</b> only acts while the player holds the attack key (the player signals
 * intent, the module picks the moment); <b>Always</b> acts whenever armed. It never touches movement or camera.
 */
public final class AutoMace {
	private final X1urConfig config;
	private final VanillaAttack attacks;

	private LocalPlayer lastPlayer;
	private ClientLevel lastLevel;
	private int lockedTargetId = -1;
	private long lockedSinceNanos;
	private boolean firedThisFall;

	public AutoMace(X1urConfig config, VanillaAttack attacks) {
		this.config = config;
		this.attacks = attacks;
	}

	public void reset() {
		lockedTargetId = -1;
		firedThisFall = false;
	}

	/** Called at the end of every client tick. */
	public void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		ClientLevel level = mc.level;
		if (player != lastPlayer || level != lastLevel) { // join, respawn, dimension change, disconnect
			reset();
			lastPlayer = player;
			lastLevel = level;
		}
		if (!config.autoMaceEnabled || player == null || level == null || mc.gameMode == null
			|| mc.screen != null || !player.isAlive() || player.isSpectator()) {
			lockedTargetId = -1;
			return;
		}
		if (!player.getMainHandItem().is(Items.MACE)) {
			lockedTargetId = -1;
			return;
		}
		if (!MaceItem.canSmashAttack(player)) { // not falling far enough: re-arm for the next fall
			firedThisFall = false;
			lockedTargetId = -1;
			return;
		}
		if (firedThisFall) {
			return;
		}
		if (config.autoMaceMode == X1urConfig.ACTIVATION_HOLD_ATTACK && !mc.options.keyAttack.isDown()) {
			lockedTargetId = -1;
			return;
		}

		Entity target = CombatTargets.crosshairTarget(mc, player);
		if (target == null) {
			lockedTargetId = -1;
			return;
		}
		long now = System.nanoTime();
		if (target.getId() != lockedTargetId) {
			lockedTargetId = target.getId();
			lockedSinceNanos = now;
		}
		if (now - lockedSinceNanos < config.autoMaceDelayMs * 1_000_000L) {
			return; // reaction delay not elapsed yet (resolution: one client tick, 50 ms)
		}

		if (attacks.attack(mc, player, target)) {
			firedThisFall = true;
			lockedTargetId = -1;
			X1urClient.LOGGER.debug("Auto Mace attacked {} (fall distance {})", target.getName().getString(), player.fallDistance);
		}
	}
}
