package net.x1ur.client.diagnostics;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.x1ur.client.X1urClient;

/**
 * Writes the reason shown on vanilla's "Disconnected" screen (kick message, timeout, connection failure, ...) to the
 * game log, so a kick can be diagnosed after the fact. Read-only: it only reads the text vanilla already displays.
 */
public final class DisconnectLogger {
	private static Screen lastLogged;

	private DisconnectLogger() {
	}

	public static void register() {
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			if (screen instanceof DisconnectedScreen && screen != lastLogged) { // init also runs again on window resize
				lastLogged = screen;
				X1urClient.LOGGER.warn("Disconnected from server - {}",
					screen.getNarrationMessage().getString().replace('\n', ' '));
			}
		});
	}
}
