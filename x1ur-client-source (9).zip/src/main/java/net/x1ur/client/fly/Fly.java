package net.x1ur.client.fly;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

/**
 * Fly: uses vanilla's own flight mechanics, nothing else.
 *
 * <h2>Permission model</h2>
 * Flight is only possible when the <b>server</b> has granted it: {@code Abilities.mayfly} is true (creative mode, or a
 * server/plugin permission). This module never sets {@code mayfly}; it cannot grant itself anything. If flight is not
 * granted, nothing is changed and a short message explains why. If the server later grants it (or revokes it), the module
 * follows, with no restart needed.
 *
 * <h2>What it does while engaged</h2>
 * <ul>
 *   <li><b>Take-off.</b> While airborne (never while standing on the ground, where vanilla would immediately cancel
 *       flying again and we would spam packets) it switches {@code abilities.flying} on, exactly like double-tapping
 *       jump, and notifies the server through vanilla's own {@code onUpdateAbilities()} (the same packet vanilla sends for
 *       the double-tap). No packet is built here.</li>
 *   <li><b>Horizontal speed.</b> {@code abilities.setFlyingSpeed(base x multiplier)}, re-applied every tick. {@code base} is
 *       the speed in effect when the module engaged (and is re-read if the server changes it meanwhile), so 1.0x equals
 *       normal flight on that server.</li>
 *   <li><b>Vertical speed.</b> Vanilla adds {@code flyingSpeed x 3} to the Y velocity while exactly one of jump/sneak is
 *       held. To make it independent of the horizontal multiplier, the difference
 *       {@code base x 3 x (vertical - horizontal)} is added at the end of the tick, so 1.0 / 1.0 is exactly vanilla.
 *       Ascend = jump key, descend = sneak key (the normal Minecraft keys).</li>
 * </ul>
 *
 * <h2>Disabling and cleanup</h2>
 * Turning the module off, losing the server's permission, dying, riding something or gliding with an elytra restores the
 * flying speed it changed and, if it started the flight, ends it (vanilla then lets the player fall). A new player object
 * (respawn, dimension change, rejoin) or a disconnect simply drops the module's state: the new player already has fresh
 * abilities, so there is nothing to restore.
 *
 * <p>Server compatibility: a vanilla server accepts this when it granted flight. Anti-cheat plugins may still object to
 * high speeds; the default (1.0x) is ordinary flight speed. No bypass of any kind is attempted.
 */
public final class Fly {
	private static final float VERTICAL_BOOST_FACTOR = 3.0f; // vanilla: flyingSpeed * 3 per tick while jump/sneak is held

	private final X1urConfig config;

	private LocalPlayer lastPlayer;
	private ClientLevel lastLevel;
	private boolean engaged;
	private boolean wasFlyingBefore;
	private float baseSpeed;
	private float appliedSpeed;
	private boolean notifiedBlocked;

	public Fly(X1urConfig config) {
		this.config = config;
	}

	/** Forget everything without touching any player (join / disconnect). */
	public void reset() {
		engaged = false;
		notifiedBlocked = false;
		lastPlayer = null;
		lastLevel = null;
	}

	/** Called at the end of every client tick. */
	public void tick(Minecraft mc) {
		LocalPlayer player = mc.player;
		ClientLevel level = mc.level;
		if (player != lastPlayer || level != lastLevel) { // join, respawn, dimension change, disconnect
			if (engaged) {
				X1urClient.LOGGER.debug("Fly: player/world changed, state dropped");
			}
			engaged = false;
			notifiedBlocked = false;
			lastPlayer = player;
			lastLevel = level;
		}
		if (player == null || level == null || mc.gameMode == null) {
			engaged = false;
			return;
		}

		Abilities abilities = player.getAbilities();
		boolean alive = player.isAlive();
		boolean blockedByState = !alive || player.isSpectator() || player.isPassenger() || player.isFallFlying();
		boolean wanted = config.flyEnabled && !blockedByState;

		if (!wanted) {
			if (engaged) {
				disengage(player, abilities, alive);
			}
			notifiedBlocked = false;
			return;
		}
		if (!abilities.mayfly) { // the server has not granted flight: change nothing, say so once
			if (engaged) {
				disengage(player, abilities, true);
			}
			if (!notifiedBlocked) {
				notifiedBlocked = true;
				player.displayClientMessage(Component.literal("Fly: the server has not granted flight"), true);
			}
			return;
		}
		notifiedBlocked = false;

		if (!engaged) {
			engaged = true;
			wasFlyingBefore = abilities.flying;
			baseSpeed = abilities.getFlyingSpeed();
			appliedSpeed = baseSpeed;
			X1urClient.LOGGER.debug("Fly: engaged (base speed {}, was flying {}, horizontal {}x, vertical {}x)",
				baseSpeed, wasFlyingBefore, config.flyHorizontalSpeed, config.flyVerticalSpeed);
		} else if (Math.abs(abilities.getFlyingSpeed() - appliedSpeed) > 1.0e-6f) {
			baseSpeed = abilities.getFlyingSpeed(); // the server changed the speed meanwhile: re-base on it
		}

		float horizontal = config.flyHorizontalSpeed;
		float vertical = config.flyVerticalSpeed;
		appliedSpeed = baseSpeed * horizontal;
		abilities.setFlyingSpeed(appliedSpeed);

		if (!abilities.flying && !player.onGround()) { // take-off, like a double-tap on jump
			abilities.flying = true;
			player.onUpdateAbilities();
			X1urClient.LOGGER.debug("Fly: flight started");
		}

		if (abilities.flying) {
			boolean up = player.input.keyPresses.jump();
			boolean down = player.input.keyPresses.shift();
			if (up != down) { // same condition vanilla uses for its own vertical boost
				float extra = baseSpeed * VERTICAL_BOOST_FACTOR * (vertical - horizontal);
				if (Math.abs(extra) > 1.0e-6f) {
					Vec3 motion = player.getDeltaMovement();
					player.setDeltaMovement(motion.x, motion.y + (up ? extra : -extra), motion.z);
				}
			}
		}
	}

	/** Restores what this module changed. {@code touchPlayer} is false for a dead player (nothing to send). */
	private void disengage(LocalPlayer player, Abilities abilities, boolean touchPlayer) {
		engaged = false;
		if (!touchPlayer) {
			X1urClient.LOGGER.debug("Fly: dropped (player dead)");
			return;
		}
		abilities.setFlyingSpeed(baseSpeed);
		if (abilities.flying && !wasFlyingBefore) {
			abilities.flying = false; // end the flight we started; vanilla lets the player fall
			player.onUpdateAbilities();
		}
		X1urClient.LOGGER.debug("Fly: disengaged (speed restored to {}, flying {})", baseSpeed, abilities.flying);
	}
}
