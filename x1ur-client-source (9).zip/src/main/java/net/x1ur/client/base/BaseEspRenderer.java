package net.x1ur.client.base;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Base ESP: rendering half. Draws {@link BaseResults} (already computed by {@link BaseEsp}) as red box outlines and
 * optional billboarded labels ("Base Candidate" / "Shulker" plus the distance). It performs no world queries and no
 * scanning: per frame it only walks the cached result list with distance and behind-camera culling.
 *
 * <p>Uses the same recipe as Player ESP / Storage ESP: vanilla's line shader with the depth test disabled, written into
 * a private reused buffer and flushed at the end of the pass, so no matrix, depth or pipeline state is left behind.
 * Label text goes through {@code Font.drawInBatch} with {@code DisplayMode.SEE_THROUGH} into a second private buffer.
 */
public final class BaseEspRenderer {
	private static final float LINE_WIDTH = 2.0f;
	private static final double BEHIND_CAMERA_MARGIN = -2.0;
	/** Labels are hidden beyond this distance in blocks so far-away text does not clutter the screen. */
	private static final double LABEL_MAX_DISTANCE = 96.0;
	/** Label size grows with distance so text stays readable; clamped so near labels are not huge. */
	private static final float LABEL_SCALE_PER_BLOCK = 0.004f;
	private static final float LABEL_MIN_SCALE = 0.03f;
	private static final float LABEL_MAX_SCALE = 0.25f;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/base_esp_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withDepthWrite(false)
			.build()
	);
	private static final RenderType RENDER_TYPE = RenderType.create(
		"x1ur_base_esp", RenderSetup.builder(PIPELINE).createRenderSetup());

	private static final Vector3f FORWARD = new Vector3f();
	private final Matrix4f labelMatrix = new Matrix4f();
	/** The current frame's camera orientation (set in {@link #draw}, used to billboard labels). */
	private org.joml.Quaternionf orientation;

	private final BaseEsp esp;
	private final X1urConfig config;
	private ByteBufferBuilder lineAllocator;
	private MultiBufferSource.BufferSource lineSource;
	private ByteBufferBuilder textAllocator;
	private MultiBufferSource.BufferSource textSource;
	private boolean failed;

	public BaseEspRenderer(BaseEsp esp, X1urConfig config) {
		this.esp = esp;
		this.config = config;
	}

	/** Registered for {@code WorldRenderEvents.END_MAIN}. */
	public void render(WorldRenderContext context) {
		if (!config.baseEspEnabled || failed || esp.results().count() == 0) {
			return;
		}
		try {
			draw(context);
		} catch (RuntimeException e) {
			failed = true; // never take the game down because of an overlay
			X1urClient.LOGGER.error("Base ESP rendering failed and was disabled for this session", e);
		}
	}

	private void draw(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		BaseResults results = esp.results();
		CameraRenderState camera = context.worldState().cameraRenderState;
		Vec3 cam = camera.pos;
		camera.orientation.transform(0f, 0f, -1f, FORWARD);
		orientation = camera.orientation;
		double fx = FORWARD.x, fy = FORWARD.y, fz = FORWARD.z;

		double maxDistance = (double) Math.min(config.baseScanRadius, mc.options.getEffectiveRenderDistance()) * 16.0 + 16.0;
		double maxDistanceSq = maxDistance * maxDistance;
		int argb = (Math.round(255f * config.baseOpacity / 100f) << 24) | config.baseEspColor;
		boolean outline = config.baseStructureOutline;
		boolean labels = config.baseLabels;
		boolean distance = config.baseDistance;
		boolean shulkers = esp.shulkerActive();
		Font font = mc.font;

		VertexConsumer lines = null;
		boolean wroteText = false;
		for (int i = 0, n = results.count(); i < n; i++) {
			boolean isShulker = results.kind(i) == BaseResults.SHULKER;
			if (isShulker && !shulkers) {
				continue;
			}
			if (!isShulker && !outline && !labels) {
				continue;
			}
			double minX = results.bound(i, 0) - cam.x, minY = results.bound(i, 1) - cam.y, minZ = results.bound(i, 2) - cam.z;
			double maxX = results.bound(i, 3) - cam.x, maxY = results.bound(i, 4) - cam.y, maxZ = results.bound(i, 5) - cam.z;
			double cx = (minX + maxX) * 0.5, cy = (minY + maxY) * 0.5, cz = (minZ + maxZ) * 0.5;
			// closest point of the box to the camera decides visibility, so a huge base is not culled by its centre
			double nx = minX > 0 ? minX : (maxX < 0 ? maxX : 0.0);
			double ny = minY > 0 ? minY : (maxY < 0 ? maxY : 0.0);
			double nz = minZ > 0 ? minZ : (maxZ < 0 ? maxZ : 0.0);
			double distSq = nx * nx + ny * ny + nz * nz;
			if (distSq > maxDistanceSq) {
				continue;
			}
			double halfX = (maxX - minX) * 0.5, halfY = (maxY - minY) * 0.5, halfZ = (maxZ - minZ) * 0.5;
			double radius = Math.sqrt(halfX * halfX + halfY * halfY + halfZ * halfZ);
			if (fx * cx + fy * cy + fz * cz < BEHIND_CAMERA_MARGIN - radius) {
				continue; // entirely behind the camera
			}

			if (isShulker || outline) {
				if (lines == null) {
					lines = beginLines();
				}
				box(lines, (float) minX, (float) minY, (float) minZ, (float) maxX, (float) maxY, (float) maxZ, argb);
			}
			if (labels && distSq <= LABEL_MAX_DISTANCE * LABEL_MAX_DISTANCE
				&& fx * cx + fy * cy + fz * cz > 0.0) {
				String text = isShulker ? "Shulker" : "Base Candidate";
				if (distance) {
					text += " " + Math.round(Math.sqrt(distSqToPlayer(mc, results, i))) + "m";
				}
				double ty = isShulker ? maxY + 0.4 : maxY + 0.6;
				drawLabel(font, text, (float) cx, (float) ty, (float) cz, argb | 0xFF000000);
				wroteText = true;
			}
		}

		if (lines != null) {
			lineSource.endBatch(RENDER_TYPE);
		}
		if (wroteText) {
			textSource.endBatch();
		}
	}

	/** Distance from the local player's feet to the box centre (what the player expects to read). */
	private static double distSqToPlayer(Minecraft mc, BaseResults r, int i) {
		double dx = (r.bound(i, 0) + r.bound(i, 3)) * 0.5 - mc.player.getX();
		double dy = (r.bound(i, 1) + r.bound(i, 4)) * 0.5 - mc.player.getY();
		double dz = (r.bound(i, 2) + r.bound(i, 5)) * 0.5 - mc.player.getZ();
		return dx * dx + dy * dy + dz * dz;
	}

	/** Camera-relative, camera-facing text at (x, y, z). The model-view is the identity here, as for the lines. */
	private void drawLabel(Font font, String text, float x, float y, float z, int argb) {
		if (textAllocator == null) {
			textAllocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			textSource = MultiBufferSource.immediate(textAllocator);
		}
		// billboard: rotate by the camera orientation so the text always faces the screen
		float distance = (float) Math.sqrt(x * x + y * y + z * z); // coordinates are camera-relative
		float scale = Math.min(LABEL_MAX_SCALE, Math.max(LABEL_MIN_SCALE, distance * LABEL_SCALE_PER_BLOCK));
		labelMatrix.identity().translate(x, y, z).rotate(orientation).scale(scale, -scale, scale);
		font.drawInBatch(text, -font.width(text) / 2f, 0f, argb, false, labelMatrix, textSource,
			Font.DisplayMode.SEE_THROUGH, 0x66000000, LightTexture.FULL_BRIGHT);
	}

	private VertexConsumer beginLines() {
		if (lineAllocator == null) {
			lineAllocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			lineSource = MultiBufferSource.immediate(lineAllocator);
		}
		return lineSource.getBuffer(RENDER_TYPE);
	}

	/** 12 edges of a camera-relative box. Normals carry the line direction, as vanilla's shape renderer does. */
	private static void box(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
		line(c, x0, y0, z0, x1, y0, z0, 1, 0, 0, argb);
		line(c, x0, y1, z0, x1, y1, z0, 1, 0, 0, argb);
		line(c, x0, y0, z1, x1, y0, z1, 1, 0, 0, argb);
		line(c, x0, y1, z1, x1, y1, z1, 1, 0, 0, argb);
		line(c, x0, y0, z0, x0, y1, z0, 0, 1, 0, argb);
		line(c, x1, y0, z0, x1, y1, z0, 0, 1, 0, argb);
		line(c, x0, y0, z1, x0, y1, z1, 0, 1, 0, argb);
		line(c, x1, y0, z1, x1, y1, z1, 0, 1, 0, argb);
		line(c, x0, y0, z0, x0, y0, z1, 0, 0, 1, argb);
		line(c, x1, y0, z0, x1, y0, z1, 0, 0, 1, argb);
		line(c, x0, y1, z0, x0, y1, z1, 0, 0, 1, argb);
		line(c, x1, y1, z0, x1, y1, z1, 0, 0, 1, argb);
	}

	private static void line(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
							 float nx, float ny, float nz, int argb) {
		c.addVertex(x0, y0, z0).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
		c.addVertex(x1, y1, z1).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
	}
}
