package net.x1ur.client.base;

/**
 * Pure geometry of the Base ESP detector (no Minecraft classes, so it can be unit-tested with plain Java).
 *
 * <p>Input is a rectangular grid of "built columns" (true = this x,z column contains at least one player-style block
 * in the examined height band). The analyzer finds every cell that lies inside a solid axis-aligned rectangle of built
 * columns that is at least {@code minWidth x minLength} (either orientation), groups those cells into connected
 * components (8-neighbourhood) and reports one bounding box per component.
 *
 * <p>There is no maximum size: a 2x2 patch and a 200x200 platform are accepted by the same rule. Shapes may be
 * rectangular or irregular - any cell covered by at least one qualifying rectangle counts - so an L-shaped base is a
 * single component, while lone wall lines (width 1) never qualify.
 *
 * <p>The exact rule, written as a formula: cell (x, z) qualifies iff there exist w >= minA, h >= minB or w >= minB,
 * h >= minA and an axis-aligned w x h rectangle containing (x, z) whose every column is built. Because any rectangle
 * of at least the minimum size contains a minimum-size window, this is equivalent to: (x, z) lies inside some window
 * of size minWidth x minLength or minLength x minWidth whose columns are all built. That equivalent form is what is
 * computed, using row bitmasks.
 */
public final class FootprintAnalyzer {
	/** Grid cell flags. */
	private static final int BUILT = 1;
	private static final int QUALIFIES = 2;

	private FootprintAnalyzer() {
	}

	/** One detected area, in grid coordinates (inclusive min, exclusive max). */
	public record Area(int minX, int minZ, int maxX, int maxZ, int cells) {
		public int width() {
			return maxX - minX;
		}

		public int length() {
			return maxZ - minZ;
		}
	}

	/**
	 * @param built row-major grid, {@code built[z * width + x]}
	 * @param width grid width in columns (x)
	 * @param depth grid depth in columns (z)
	 * @param minWidth minimum extent along x for a window (>= 1)
	 * @param minLength minimum extent along z for a window (>= 1)
	 * @return qualifying areas, ordered by discovery (row-major by their first cell)
	 */
	public static java.util.List<Area> analyze(boolean[] built, int width, int depth, int minWidth, int minLength) {
		if (width <= 0 || depth <= 0 || built.length < width * depth) {
			return java.util.List.of();
		}
		minWidth = Math.max(1, minWidth);
		minLength = Math.max(1, minLength);
		byte[] cell = new byte[width * depth];
		for (int i = 0; i < width * depth; i++) {
			if (built[i]) {
				cell[i] = BUILT;
			}
		}

		markWindows(cell, width, depth, minWidth, minLength);
		if (minWidth != minLength) {
			markWindows(cell, width, depth, minLength, minWidth);
		}
		return components(cell, width, depth);
	}

	/**
	 * Marks every cell covered by an all-built window of {@code w x h} (w along x, h along z).
	 * Uses 2-D prefix sums so the cost is O(width * depth) regardless of the window or structure size.
	 */
	private static void markWindows(byte[] cell, int width, int depth, int w, int h) {
		if (w > width || h > depth) {
			return;
		}
		int stride = width + 1;
		int[] prefix = new int[stride * (depth + 1)];
		for (int z = 0; z < depth; z++) {
			int rowSum = 0;
			for (int x = 0; x < width; x++) {
				rowSum += (cell[z * width + x] & BUILT) != 0 ? 1 : 0;
				prefix[(z + 1) * stride + (x + 1)] = prefix[z * stride + (x + 1)] + rowSum;
			}
		}
		int full = w * h;
		// difference array so marking all windows is O(cells) too
		int[] diff = new int[(width + 1) * (depth + 1)];
		for (int z = 0; z + h <= depth; z++) {
			for (int x = 0; x + w <= width; x++) {
				int sum = prefix[(z + h) * stride + (x + w)] - prefix[z * stride + (x + w)]
					- prefix[(z + h) * stride + x] + prefix[z * stride + x];
				if (sum == full) {
					diff[z * stride + x]++;
					diff[z * stride + (x + w)]--;
					diff[(z + h) * stride + x]--;
					diff[(z + h) * stride + (x + w)]++;
				}
			}
		}
		int[] running = new int[stride];
		for (int z = 0; z < depth; z++) {
			int acc = 0;
			for (int x = 0; x < width; x++) {
				running[x] += diff[z * stride + x];
				acc += running[x];
				if (acc > 0) {
					cell[z * width + x] |= QUALIFIES;
				}
			}
			running[width] += diff[z * stride + width];
		}
	}

	private static java.util.List<Area> components(byte[] cell, int width, int depth) {
		java.util.ArrayList<Area> areas = new java.util.ArrayList<>();
		boolean[] seen = new boolean[width * depth];
		int[] stack = new int[width * depth];
		for (int start = 0; start < width * depth; start++) {
			if ((cell[start] & QUALIFIES) == 0 || seen[start]) {
				continue;
			}
			int sp = 0;
			stack[sp++] = start;
			seen[start] = true;
			int minX = width, minZ = depth, maxX = -1, maxZ = -1, count = 0;
			while (sp > 0) {
				int idx = stack[--sp];
				int x = idx % width;
				int z = idx / width;
				count++;
				minX = Math.min(minX, x);
				maxX = Math.max(maxX, x);
				minZ = Math.min(minZ, z);
				maxZ = Math.max(maxZ, z);
				for (int dz = -1; dz <= 1; dz++) {
					for (int dx = -1; dx <= 1; dx++) {
						int nx = x + dx;
						int nz = z + dz;
						if (nx < 0 || nz < 0 || nx >= width || nz >= depth) {
							continue;
						}
						int n = nz * width + nx;
						if (!seen[n] && (cell[n] & QUALIFIES) != 0) {
							seen[n] = true;
							stack[sp++] = n;
						}
					}
				}
			}
			areas.add(new Area(minX, minZ, maxX + 1, maxZ + 1, count));
		}
		return merge(areas);
	}

	/**
	 * Components can have overlapping bounding boxes (e.g. an L wrapped around another structure). Overlapping boxes
	 * are merged until none overlap, so one candidate never gets two boxes.
	 *
	 * <p>Cost: a sweep over boxes sorted by minX, with an {@code active} list of boxes still reaching the sweep line.
	 * Each box is compared only with the active ones, and every merge restarts the pass, so the work is bounded by the
	 * number of overlapping pairs instead of all pairs.
	 */
	private static java.util.List<Area> merge(java.util.List<Area> in) {
		java.util.ArrayList<Area> list = new java.util.ArrayList<>(in);
		boolean changed = true;
		while (changed && list.size() > 1) {
			changed = false;
			list.sort(java.util.Comparator.comparingInt(Area::minX));
			java.util.ArrayList<Area> active = new java.util.ArrayList<>();
			java.util.ArrayList<Area> out = new java.util.ArrayList<>(list.size());
			for (Area box : list) {
				Area current = box;
				// drop boxes that end before this one starts: they cannot overlap it or any later box
				for (int i = active.size() - 1; i >= 0; i--) {
					Area other = active.get(i);
					if (other.maxX <= current.minX) {
						out.add(other);
						active.remove(i);
					} else if (other.minZ < current.maxZ && current.minZ < other.maxZ) {
						current = new Area(Math.min(current.minX, other.minX), Math.min(current.minZ, other.minZ),
							Math.max(current.maxX, other.maxX), Math.max(current.maxZ, other.maxZ), current.cells + other.cells);
						active.remove(i);
						changed = true;
					}
				}
				active.add(current);
			}
			out.addAll(active);
			list = out;
		}
		return list;
	}

	/** Test helper: builds a grid from text rows ('#' = built column). */
	public static boolean[] gridOf(String... rows) {
		int w = rows[0].length();
		boolean[] g = new boolean[w * rows.length];
		for (int z = 0; z < rows.length; z++) {
			for (int x = 0; x < w; x++) {
				g[z * w + x] = rows[z].charAt(x) == '#';
			}
		}
		return g;
	}
}
