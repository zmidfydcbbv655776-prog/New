package net.x1ur.client.base;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Decides which blocks count as "built" (player-style) for Base ESP: blocks that essentially do not generate as
 * terrain and are typical of constructions - planks, wool, beds, doors, fences, stairs, slabs, walls, trapdoors, glass,
 * concrete, bricks, polished/smooth stone variants, and utility blocks such as crafting tables, furnaces, chests,
 * barrels and shulker boxes.
 *
 * <p>This is a heuristic, not proof: villages, mineshafts, strongholds, ancient cities and other generated structures
 * are made of many of the same blocks, and a base built only from natural-looking blocks (dirt, cobblestone, netherrack)
 * is invisible to it. Results are therefore only ever "Base Candidate".
 *
 * <p>Classification is cached per {@link BlockState} (identity map), so scanning a section costs one map lookup per
 * distinct state, not per block.
 */
public final class BuiltBlocks {
	private final Map<BlockState, Boolean> cache = new IdentityHashMap<>();

	/** True if the state is a "built" block. */
	public boolean isBuilt(BlockState state) {
		Boolean cached = cache.get(state);
		if (cached == null) {
			cached = classify(state);
			cache.put(state, cached);
		}
		return cached;
	}

	/** True if the state is any shulker box (all 17 colours share one tag). */
	public static boolean isShulker(BlockState state) {
		return state.is(BlockTags.SHULKER_BOXES);
	}

	private static boolean classify(BlockState state) {
		if (state.isAir()) {
			return false;
		}
		if (state.is(BlockTags.PLANKS) || state.is(BlockTags.WOOL) || state.is(BlockTags.BEDS)
			|| state.is(BlockTags.DOORS) || state.is(BlockTags.FENCES) || state.is(BlockTags.FENCE_GATES)
			|| state.is(BlockTags.STAIRS) || state.is(BlockTags.SLABS) || state.is(BlockTags.WALLS)
			|| state.is(BlockTags.TRAPDOORS) || state.is(BlockTags.SHULKER_BOXES) || state.is(BlockTags.CANDLES)
			|| state.is(BlockTags.WOOL_CARPETS) || state.is(BlockTags.BANNERS) || state.is(BlockTags.CONCRETE_POWDER)) {
			return true;
		}
		Block block = state.getBlock();
		if (block == Blocks.CRAFTING_TABLE || block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE
			|| block == Blocks.SMOKER || block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST
			|| block == Blocks.BARREL || block == Blocks.ENDER_CHEST || block == Blocks.ENCHANTING_TABLE
			|| block == Blocks.ANVIL || block == Blocks.BREWING_STAND || block == Blocks.HOPPER
			|| block == Blocks.DISPENSER || block == Blocks.DROPPER || block == Blocks.OBSERVER
			|| block == Blocks.PISTON || block == Blocks.STICKY_PISTON || block == Blocks.GLASS
			|| block == Blocks.TINTED_GLASS || block == Blocks.GLASS_PANE || block == Blocks.BOOKSHELF
			|| block == Blocks.BRICKS || block == Blocks.STONE_BRICKS || block == Blocks.SMOOTH_STONE
			|| block == Blocks.BEACON || block == Blocks.LANTERN || block == Blocks.SOUL_LANTERN
			|| block == Blocks.TORCH || block == Blocks.WALL_TORCH) {
			return true;
		}
		// registry-name families without a convenient tag: concrete, stained glass (+ panes), terracotta (glazed)
		String path = BuiltInRegistries.BLOCK.getKey(block).getPath();
		return path.endsWith("_concrete") || path.endsWith("_stained_glass") || path.endsWith("_stained_glass_pane")
			|| path.endsWith("_glazed_terracotta") || path.startsWith("polished_") || path.startsWith("smooth_")
			|| path.startsWith("cut_") || path.startsWith("chiseled_");
	}
}
