package net.x1ur.client.base;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Base ESP: scanning half. Finds <i>Base Candidates</i> (areas of built blocks at least minWidth x minLength, default
 * 2x2, no maximum) and shulker boxes in chunks the client already has, and publishes them in {@link BaseResults}.
 *
 * <h2>Algorithm</h2>
 * <ol>
 *   <li><b>Per-chunk cache</b> ({@link ChunkData}): for every 8-block-high band of the world a 16x16 bitmap of "built
 *       columns" (a column is one x,z position with at least one {@link BuiltBlocks built block} in that band), plus
 *       the list of shulker box positions. A section whose palette contains no built block is skipped without reading
 *       a single block ({@code maybeHas}), so empty sky/stone costs almost nothing. Chunks are scanned nearest-first,
 *       within a per-tick time and section budget; a cached chunk is rescanned only after {@link #RESCAN_TICKS}
 *       (block changes have no client event, so this is how edits are noticed), or immediately when the chunk is
 *       (re)loaded.</li>
 *   <li><b>Analysis</b> ({@link FootprintAnalyzer}): for each band, the bitmaps of all cached chunks inside the radius
 *       are stitched into one grid, so structures crossing chunk borders are seen whole. A column qualifies if it lies
 *       in an all-built window of minWidth x minLength (or minLength x minWidth). Qualifying columns form connected
 *       areas, overlapping boxes are merged. Bands whose boxes overlap in x/z and touch vertically are merged, so a
 *       multi-storey base is one candidate. The analysis reruns only when a chunk's cached data actually changed (and at most every
 *       {@link #ANALYSIS_MIN_TICKS} ticks), never per frame.</li>
 *   <li><b>Results</b> are labelled "Base Candidate" - never "base" - because the data cannot prove ownership.</li>
 * </ol>
 *
 * <p>The scan never loads chunks ({@code getChunk(..., false)} returns null for unknown chunks), only reads data the
 * server already sent, and cannot see blocks the server hides (Anti-Xray). Master switch off: no scanning, no events
 * handled, caches released, settings untouched; Shulker ESP is inactive while the master is off.
 */
public final class BaseEsp {
	/** Height of one analysis band in blocks (a multiple of 16 would skip floors; 8 keeps floors separate). */
	static final int BAND = 8;
	static final int RESCAN_TICKS = 300;
	static final int ANALYSIS_MIN_TICKS = 10;
	/** Per-tick scanning budget: at most this many nanoseconds, and at most this many sections. */
	private static final long TICK_BUDGET_NANOS = 1_500_000L;
	private static final int MAX_SECTIONS_PER_TICK = 24;
	private static final int MAX_RESULTS = 256;

	/** Cached scan result of one chunk. */
	private static final class ChunkData {
		/** bands[b][row] = bitmask of built columns in that row of the chunk (bit x), b = band index from world bottom. */
		short[][] bands;
		/** Real lowest / highest world Y of built blocks per band (Integer.MAX/MIN when the band has none). */
		int[] minY;
		int[] maxY;
		/** shulker box positions, packed {@link BlockPos#asLong}. */
		long[] shulkers = new long[0];
		long scannedAtTick;
		boolean dirty = true;
	}

	private final X1urConfig config;
	private final BuiltBlocks builtBlocks = new BuiltBlocks();
	private final BaseResults results = new BaseResults();
	private final Map<Long, ChunkData> chunks = new HashMap<>();
	private final ArrayList<ChunkPos> queue = new ArrayList<>();

	private ResourceKey<Level> dimension;
	private ClientLevel level;
	private boolean active;
	private boolean analysisDirty;
	/** Set by {@link #scanChunk}: did the chunk just scanned differ from its previous cache entry? */
	private boolean scanChanged;
	private long tickCounter;
	private long lastAnalysisTick;
	private int minBuildY;
	private int bandCount;

	public BaseEsp(X1urConfig config) {
		this.config = config;
	}

	/** Results for the renderer. Empty whenever the module is off or the world changed. */
	public BaseResults results() {
		return results;
	}

	/** Master state as seen by the rest of the module: Shulker ESP is only ever active under the master. */
	public boolean isActive() {
		return config.baseEspEnabled;
	}

	public boolean shulkerActive() {
		return config.baseEspEnabled && config.baseShulkerEspEnabled;
	}

	/** Registers the Fabric chunk events. Called exactly once from the client initialiser. */
	public void register() {
		ClientChunkEvents.CHUNK_LOAD.register(this::onChunkLoad);
		ClientChunkEvents.CHUNK_UNLOAD.register(this::onChunkUnload);
	}

	/** Forget everything (join / disconnect). Settings are not touched. */
	public void clear() {
		chunks.clear();
		queue.clear();
		results.clear();
		level = null;
		dimension = null;
		analysisDirty = false;
	}

	private void onChunkLoad(ClientLevel world, LevelChunk chunk) {
		if (!config.baseEspEnabled || world != level) {
			return;
		}
		ChunkData data = chunks.get(chunk.getPos().toLong());
		if (data != null) {
			data.dirty = true; // reloaded with new data
		}
	}

	private void onChunkUnload(ClientLevel world, LevelChunk chunk) {
		if (chunks.remove(chunk.getPos().toLong()) != null) {
			analysisDirty = true;
		}
	}

	/** Called at the end of every client tick. */
	public void tick(Minecraft mc) {
		tickCounter++;
		ClientLevel current = mc.level;
		boolean usable = config.baseEspEnabled && current != null && mc.player != null;

		if (!usable) {
			if (active || !chunks.isEmpty() || results.count() > 0) {
				clear(); // master off / no world: stop all work and release memory
			}
			active = false;
			return;
		}
		active = true;

		ResourceKey<Level> dim = current.dimension();
		if (current != level || dim != dimension) { // new world or dimension change: nothing may carry over
			clear();
			level = current;
			dimension = dim;
			minBuildY = current.getMinY();
			bandCount = (current.getHeight() + BAND - 1) / BAND;
		}

		int radius = Math.min(config.baseScanRadius, mc.options.getEffectiveRenderDistance());
		BlockPos playerPos = mc.player.blockPosition();
		int centerX = playerPos.getX() >> 4;
		int centerZ = playerPos.getZ() >> 4;

		dropFarChunks(centerX, centerZ, radius);
		scanWithinBudget(current, centerX, centerZ, radius);

		boolean wantStructures = config.baseStructureOutline || config.baseLabels;
		if (analysisDirty && tickCounter - lastAnalysisTick >= ANALYSIS_MIN_TICKS) {
			analyse(centerX, centerZ, radius, wantStructures);
			lastAnalysisTick = tickCounter;
			analysisDirty = false;
		}
	}

	/** Chunks that left the radius are forgotten, so memory stays proportional to the radius. */
	private void dropFarChunks(int centerX, int centerZ, int radius) {
		boolean removed = false;
		for (Iterator<Long> it = chunks.keySet().iterator(); it.hasNext(); ) {
			long key = it.next();
			if (Math.abs(ChunkPos.getX(key) - centerX) > radius || Math.abs(ChunkPos.getZ(key) - centerZ) > radius) {
				it.remove();
				removed = true;
			}
		}
		analysisDirty |= removed;
	}

	private void scanWithinBudget(ClientLevel world, int centerX, int centerZ, int radius) {
		// (re)build the nearest-first work list of chunks that are missing, dirty or stale
		queue.clear();
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				ChunkPos pos = new ChunkPos(centerX + dx, centerZ + dz);
				ChunkData data = chunks.get(pos.toLong());
				if (data == null || data.dirty || tickCounter - data.scannedAtTick >= RESCAN_TICKS) {
					queue.add(pos);
				}
			}
		}
		if (queue.isEmpty()) {
			return;
		}
		queue.sort((a, b) -> Integer.compare(dist2(a, centerX, centerZ), dist2(b, centerX, centerZ)));

		long deadline = System.nanoTime() + TICK_BUDGET_NANOS;
		int sectionsLeft = MAX_SECTIONS_PER_TICK;
		for (ChunkPos pos : queue) {
			if (sectionsLeft <= 0 || System.nanoTime() > deadline) {
				break;
			}
			ChunkAccess chunk = world.getChunk(pos.x, pos.z, ChunkStatus.FULL, false); // never force-loads
			if (chunk == null) {
				continue;
			}
			ChunkData data = chunks.computeIfAbsent(pos.toLong(), k -> new ChunkData());
			sectionsLeft -= scanChunk(chunk, data);
			data.scannedAtTick = tickCounter;
			data.dirty = false;
			analysisDirty |= scanChanged;
		}
	}

	private static int dist2(ChunkPos p, int cx, int cz) {
		int dx = p.x - cx;
		int dz = p.z - cz;
		return dx * dx + dz * dz;
	}

	/** Scans one chunk into its cache entry. Returns the number of sections that had to be read block by block. */
	private int scanChunk(ChunkAccess chunk, ChunkData data) {
		short[][] bands = new short[bandCount][];
		int[] minYs = new int[bandCount];
		int[] maxYs = new int[bandCount];
		java.util.Arrays.fill(minYs, Integer.MAX_VALUE);
		java.util.Arrays.fill(maxYs, Integer.MIN_VALUE);
		ArrayList<Long> shulkers = null;
		LevelChunkSection[] sections = chunk.getSections();
		int minSection = chunk.getMinSectionY();
		int minX = chunk.getPos().getMinBlockX();
		int minZ = chunk.getPos().getMinBlockZ();
		int read = 0;

		for (int s = 0; s < sections.length; s++) {
			LevelChunkSection section = sections[s];
			if (section == null || section.hasOnlyAir()) {
				continue;
			}
			boolean hasBuilt = section.maybeHas(builtBlocks::isBuilt);
			boolean hasShulker = section.maybeHas(BuiltBlocks::isShulker);
			if (!hasBuilt && !hasShulker) {
				continue; // nothing of interest in this palette: skip without touching blocks
			}
			read++;
			int baseY = (minSection + s) << 4;
			for (int y = 0; y < 16; y++) {
				int band = (baseY + y - minBuildY) / BAND;
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						var state = section.getBlockState(x, y, z);
						if (hasBuilt && builtBlocks.isBuilt(state)) {
							if (band >= 0 && band < bandCount) {
								if (bands[band] == null) {
									bands[band] = new short[16];
								}
								bands[band][z] |= (short) (1 << x);
								int worldY = baseY + y;
								if (worldY < minYs[band]) {
									minYs[band] = worldY;
								}
								if (worldY > maxYs[band]) {
									maxYs[band] = worldY;
								}
							}
						}
						if (hasShulker && BuiltBlocks.isShulker(state)) {
							if (shulkers == null) {
								shulkers = new ArrayList<>();
							}
							shulkers.add(BlockPos.asLong(minX + x, baseY + y, minZ + z));
						}
					}
				}
			}
		}
		long[] newShulkers = new long[shulkers == null ? 0 : shulkers.size()];
		for (int i = 0; i < newShulkers.length; i++) {
			newShulkers[i] = shulkers.get(i);
		}
		// Re-analysis is only needed if this chunk's cached content really changed (unchanged rescans are free).
		scanChanged = data.bands == null || !sameBands(data.bands, bands)
			|| !java.util.Arrays.equals(data.shulkers, newShulkers)
			|| !java.util.Arrays.equals(data.minY, minYs) || !java.util.Arrays.equals(data.maxY, maxYs);
		data.bands = bands;
		data.minY = minYs;
		data.maxY = maxYs;
		data.shulkers = newShulkers;
		return Math.max(1, read);
	}

	// ------------------------------------------------------------------ analysis

	private void analyse(int centerX, int centerZ, int radius, boolean wantStructures) {
		results.clear();
		int side = (radius * 2 + 1) * 16;
		int originX = (centerX - radius) * 16;
		int originZ = (centerZ - radius) * 16;
		int minW = Math.max(X1urConfig.BASE_SIZE_MIN, config.baseMinWidth);
		int minL = Math.max(X1urConfig.BASE_SIZE_MIN, config.baseMinLength);

		if (wantStructures) {
			findStructures(side, originX, originZ, centerX, centerZ, radius, minW, minL);
		}
		if (config.baseShulkerEspEnabled) {
			for (ChunkData data : chunks.values()) {
				for (long packed : data.shulkers) {
					if (results.count() >= MAX_RESULTS * 2) {
						return;
					}
					double x = BlockPos.getX(packed);
					double y = BlockPos.getY(packed);
					double z = BlockPos.getZ(packed);
					results.add(BaseResults.SHULKER, x, y, z, x + 1, y + 1, z + 1);
				}
			}
		}
	}

	private void findStructures(int side, int originX, int originZ, int centerX, int centerZ, int radius, int minW, int minL) {
		boolean[] grid = new boolean[side * side];
		List<int[]> boxes = new ArrayList<>(); // {minX, minZ, maxX, maxZ, band, minY, maxY}

		for (int band = 0; band < bandCount; band++) {
			boolean any = false;
			java.util.Arrays.fill(grid, false);
			for (Map.Entry<Long, ChunkData> e : chunks.entrySet()) {
				short[][] bands = e.getValue().bands;
				if (bands == null || bands[band] == null) {
					continue;
				}
				int gx = (ChunkPos.getX(e.getKey()) - (centerX - radius)) * 16;
				int gz = (ChunkPos.getZ(e.getKey()) - (centerZ - radius)) * 16;
				for (int z = 0; z < 16; z++) {
					int row = bands[band][z] & 0xFFFF;
					if (row == 0) {
						continue;
					}
					any = true;
					for (int x = 0; x < 16; x++) {
						if ((row & (1 << x)) != 0) {
							grid[(gz + z) * side + gx + x] = true;
						}
					}
				}
			}
			if (!any) {
				continue;
			}
			for (FootprintAnalyzer.Area area : FootprintAnalyzer.analyze(grid, side, side, minW, minL)) {
				int[] y = verticalExtent(area, band, centerX - radius, centerZ - radius);
				boxes.add(new int[] {area.minX(), area.minZ(), area.maxX(), area.maxZ(), band, y[0], y[1]});
			}
		}

		// merge boxes of vertically adjacent bands that overlap in x/z: one multi-storey base = one candidate
		List<double[]> merged = new ArrayList<>(); // {minX, minZ, maxX, maxZ, minBand, maxBand, minY, maxY}
		boolean[] used = new boolean[boxes.size()];
		for (int i = 0; i < boxes.size(); i++) {
			if (used[i]) {
				continue;
			}
			int[] b = boxes.get(i);
			double[] m = {b[0], b[1], b[2], b[3], b[4], b[4], b[5], b[6]};
			used[i] = true;
			boolean grew = true;
			while (grew) {
				grew = false;
				for (int j = 0; j < boxes.size(); j++) {
					if (used[j]) {
						continue;
					}
					int[] o = boxes.get(j);
					boolean adjacentBand = o[4] >= m[4] - 1 && o[4] <= m[5] + 1;
					boolean overlap = o[0] < m[2] && m[0] < o[2] && o[1] < m[3] && m[1] < o[3];
					if (adjacentBand && overlap) {
						m[0] = Math.min(m[0], o[0]);
						m[1] = Math.min(m[1], o[1]);
						m[2] = Math.max(m[2], o[2]);
						m[3] = Math.max(m[3], o[3]);
						m[4] = Math.min(m[4], o[4]);
						m[5] = Math.max(m[5], o[4]);
						m[6] = Math.min(m[6], o[5]);
						m[7] = Math.max(m[7], o[6]);
						used[j] = true;
						grew = true;
					}
				}
			}
			merged.add(m);
		}

		int count = 0;
		for (double[] m : merged) {
			if (count++ >= MAX_RESULTS) {
				break;
			}
			results.add(BaseResults.STRUCTURE,
				originX + m[0], m[6], originZ + m[1],
				originX + m[2], m[7] + 1, originZ + m[3]);
		}
	}

	/**
	 * Real vertical extent (lowest built block Y, highest built block Y) of an area in one band, taken from the
	 * cached per-chunk values of every chunk the area touches. Within a chunk the extent is per band, so a second
	 * structure in the same chunk and band can make a box up to one band (8 blocks) taller than strictly needed.
	 */
	private int[] verticalExtent(FootprintAnalyzer.Area area, int band, int originChunkX, int originChunkZ) {
		int lo = Integer.MAX_VALUE;
		int hi = Integer.MIN_VALUE;
		for (int cx = originChunkX + Math.floorDiv(area.minX(), 16); cx <= originChunkX + Math.floorDiv(area.maxX() - 1, 16); cx++) {
			for (int cz = originChunkZ + Math.floorDiv(area.minZ(), 16); cz <= originChunkZ + Math.floorDiv(area.maxZ() - 1, 16); cz++) {
				ChunkData data = chunks.get(ChunkPos.asLong(cx, cz));
				if (data == null || data.minY == null) {
					continue;
				}
				lo = Math.min(lo, data.minY[band]);
				hi = Math.max(hi, data.maxY[band]);
			}
		}
		if (lo > hi) { // should not happen; fall back to the whole band
			lo = minBuildY + band * BAND;
			hi = lo + BAND - 1;
		}
		return new int[] {lo, hi};
	}

	private static boolean sameBands(short[][] a, short[][] b) {
		if (a.length != b.length) {
			return false;
		}
		for (int i = 0; i < a.length; i++) {
			if (!java.util.Arrays.equals(a[i], b[i])) {
				return false;
			}
		}
		return true;
	}
}
