package net.x1ur.client.base;

import java.util.Arrays;

/**
 * Flat, reusable result list shared between the scanner (client tick) and the renderer (every frame).
 * Struct-of-arrays, written by the tick thread and read by the render thread, which is the same thread in the
 * single-threaded client, so no synchronisation is needed. Boxes are absolute world coordinates.
 */
public final class BaseResults {
	/** Kinds of results. */
	public static final byte STRUCTURE = 0;
	public static final byte SHULKER = 1;

	private double[] box = new double[6 * 32];
	private byte[] kind = new byte[32];
	private int count;

	public int count() {
		return count;
	}

	public void clear() {
		count = 0;
	}

	public void add(byte type, double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
		if (count == kind.length) {
			kind = Arrays.copyOf(kind, count * 2);
			box = Arrays.copyOf(box, count * 2 * 6);
		}
		int o = count * 6;
		box[o] = minX;
		box[o + 1] = minY;
		box[o + 2] = minZ;
		box[o + 3] = maxX;
		box[o + 4] = maxY;
		box[o + 5] = maxZ;
		kind[count] = type;
		count++;
	}

	/** Component {@code axis} (0..5 = minX, minY, minZ, maxX, maxY, maxZ) of result {@code i}. */
	public double bound(int i, int axis) {
		return box[i * 6 + axis];
	}

	public byte kind(int i) {
		return kind[i];
	}
}
