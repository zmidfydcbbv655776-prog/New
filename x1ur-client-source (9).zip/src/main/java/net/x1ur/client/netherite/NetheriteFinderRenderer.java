package net.x1ur.client.netherite;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;
import org.joml.Vector3f;

import java.util.List;

/**
 * Render half of the Netherite Finder port (HookBeta: {@code onRender3D}). Same rules as the original:
 * <ul>
 *   <li>colors: fill rgb(190,90,255) with alpha pulsing 255 -> 100 -> 255 every 2 s; outlines/tracers solid
 *       rgb(190,90,255); line width 1.5;</li>
 *   <li>exact blocks: fill + outline + tracer (always); section boxes: outline, and a tracer only if "Tracers" is on;</li>
 *   <li>dropped ancient debris items: fill + outline + tracer to the entity's position, every frame, using the
 *       entity's current (not interpolated) bounding box.</li>
 * </ul>
 * HookBeta's {@code RenderUtils} is not part of the supplied source, so drawing uses vanilla 1.21.11's own line and
 * filled-box shaders with the depth test disabled, drawn at Fabric's {@code WorldRenderEvents.END_MAIN}. The tracer
 * start point (HookBeta's {@code getTracerStart}) is a point 0.4 blocks in front of the camera.
 */
public final class NetheriteFinderRenderer {
	private static final float LINE_WIDTH = 1.5f;
	private static final int OUTLINE_ARGB = 0xFFBE5AFF;
	private static final int FILL_RGB = 0xBE5AFF;
	private static final float TRACER_START_DISTANCE = 0.4f;

	private static final RenderPipeline LINES_PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/netherite_finder_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withDepthWrite(false)
			.build()
	);
	private static final RenderPipeline FILL_PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/netherite_finder_fill"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withCull(false)
			.build()
	);
	private static final RenderType LINES_TYPE = RenderType.create(
		"x1ur_netherite_lines", RenderSetup.builder(LINES_PIPELINE).createRenderSetup());
	private static final RenderType FILL_TYPE = RenderType.create(
		"x1ur_netherite_fill", RenderSetup.builder(FILL_PIPELINE).createRenderSetup());

	private static final Vector3f FORWARD = new Vector3f();

	private final NetheriteFinder finder;
	private final X1urConfig config;
	private ByteBufferBuilder allocator;
	private MultiBufferSource.BufferSource bufferSource;
	private boolean failed;

	public NetheriteFinderRenderer(NetheriteFinder finder, X1urConfig config) {
		this.finder = finder;
		this.config = config;
	}

	/** Registered for {@code WorldRenderEvents.END_MAIN}. */
	public void render(WorldRenderContext context) {
		if (!config.netheriteFinderEnabled || failed) {
			return;
		}
		try {
			draw(context);
		} catch (RuntimeException e) {
			failed = true; // never take the game down because of an overlay
			X1urClient.LOGGER.error("Netherite Finder rendering failed and was disabled for this session", e);
		}
	}

	private void draw(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null) {
			return;
		}
		CameraRenderState camera = context.worldState().cameraRenderState;
		Vec3 cam = camera.pos;
		camera.orientation.transform(0f, 0f, -1f, FORWARD);
		float sx = FORWARD.x * TRACER_START_DISTANCE;
		float sy = FORWARD.y * TRACER_START_DISTANCE;
		float sz = FORWARD.z * TRACER_START_DISTANCE;
		boolean tracers = config.netheriteTracers;

		long phase = System.currentTimeMillis() % 2000L;
		double wave = phase < 1000L ? phase / 1000.0 : (2000L - phase) / 1000.0;
		int fillArgb = ((int) (255.0 - 155.0 * wave) << 24) | FILL_RGB;

		List<NetheriteFinder.BoundingBox> hits = finder.hits();
		Iterable<Entity> entities = mc.level.entitiesForRendering();

		if (allocator == null) {
			allocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			bufferSource = MultiBufferSource.immediate(allocator);
		}

		// ---- pass 1: fills (exact blocks and dropped items) ----
		VertexConsumer fill = null;
		for (int i = 0, n = hits.size(); i < n; i++) {
			NetheriteFinder.BoundingBox hit = hits.get(i);
			if (!hit.exact()) {
				continue;
			}
			if (fill == null) {
				fill = bufferSource.getBuffer(FILL_TYPE);
			}
			filledBox(fill,
				(float) (hit.x1() - cam.x), (float) (hit.y1() - cam.y), (float) (hit.z1() - cam.z),
				(float) (hit.x2() - cam.x), (float) (hit.y2() - cam.y), (float) (hit.z2() - cam.z), fillArgb);
		}
		for (Entity entity : entities) {
			if (entity instanceof ItemEntity item && item.getItem().is(Items.ANCIENT_DEBRIS)) {
				AABB b = item.getBoundingBox();
				if (fill == null) {
					fill = bufferSource.getBuffer(FILL_TYPE);
				}
				filledBox(fill,
					(float) (b.minX - cam.x), (float) (b.minY - cam.y), (float) (b.minZ - cam.z),
					(float) (b.maxX - cam.x), (float) (b.maxY - cam.y), (float) (b.maxZ - cam.z), fillArgb);
			}
		}
		if (fill != null) {
			bufferSource.endBatch(FILL_TYPE);
		}

		// ---- pass 2: outlines and tracers ----
		VertexConsumer lines = null;
		boolean debrisMode = config.netheriteDebrisMode; // Ancient Debris Mode: skip whole-section boxes, keep exact blocks
		for (int i = 0, n = hits.size(); i < n; i++) {
			NetheriteFinder.BoundingBox hit = hits.get(i);
			if (debrisMode && !hit.exact()) {
				continue;
			}
			if (lines == null) {
				lines = bufferSource.getBuffer(LINES_TYPE);
			}
			outline(lines,
				(float) (hit.x1() - cam.x), (float) (hit.y1() - cam.y), (float) (hit.z1() - cam.z),
				(float) (hit.x2() - cam.x), (float) (hit.y2() - cam.y), (float) (hit.z2() - cam.z));
			if (hit.exact() || tracers) {
				tracer(lines, sx, sy, sz,
					(float) (hit.centerX() - cam.x), (float) (hit.centerY() - cam.y), (float) (hit.centerZ() - cam.z));
			}
		}
		for (Entity entity : entities) {
			if (entity instanceof ItemEntity item && item.getItem().is(Items.ANCIENT_DEBRIS)) {
				AABB b = item.getBoundingBox();
				if (lines == null) {
					lines = bufferSource.getBuffer(LINES_TYPE);
				}
				outline(lines,
					(float) (b.minX - cam.x), (float) (b.minY - cam.y), (float) (b.minZ - cam.z),
					(float) (b.maxX - cam.x), (float) (b.maxY - cam.y), (float) (b.maxZ - cam.z));
				tracer(lines, sx, sy, sz,
					(float) (item.getX() - cam.x), (float) (item.getY() - cam.y), (float) (item.getZ() - cam.z));
			}
		}
		if (lines != null) {
			bufferSource.endBatch(LINES_TYPE);
		}
	}

	/** Six faces of a camera-relative box, as quads. Culling is disabled in the pipeline, so winding is irrelevant. */
	private static void filledBox(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
		quad(c, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, argb); // +Z
		quad(c, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, argb); // -Z
		quad(c, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, argb); // -X
		quad(c, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, argb); // +X
		quad(c, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, argb); // +Y
		quad(c, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, argb); // -Y
	}

	private static void quad(VertexConsumer c,
							 float ax, float ay, float az, float bx, float by, float bz,
							 float cx, float cy, float cz, float dx, float dy, float dz, int argb) {
		c.addVertex(ax, ay, az).setColor(argb);
		c.addVertex(bx, by, bz).setColor(argb);
		c.addVertex(cx, cy, cz).setColor(argb);
		c.addVertex(dx, dy, dz).setColor(argb);
	}

	/** 12 edges. The vertex normal carries the line direction, as vanilla's shape renderer does. */
	private static void outline(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1) {
		line(c, x0, y0, z0, x1, y0, z0, 1, 0, 0);
		line(c, x0, y1, z0, x1, y1, z0, 1, 0, 0);
		line(c, x0, y0, z1, x1, y0, z1, 1, 0, 0);
		line(c, x0, y1, z1, x1, y1, z1, 1, 0, 0);
		line(c, x0, y0, z0, x0, y1, z0, 0, 1, 0);
		line(c, x1, y0, z0, x1, y1, z0, 0, 1, 0);
		line(c, x0, y0, z1, x0, y1, z1, 0, 1, 0);
		line(c, x1, y0, z1, x1, y1, z1, 0, 1, 0);
		line(c, x0, y0, z0, x0, y0, z1, 0, 0, 1);
		line(c, x1, y0, z0, x1, y0, z1, 0, 0, 1);
		line(c, x0, y1, z0, x0, y1, z1, 0, 0, 1);
		line(c, x1, y1, z0, x1, y1, z1, 0, 0, 1);
	}

	private static void tracer(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1) {
		float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
		float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
		if (len < 1.0e-4f) {
			return;
		}
		// A target behind the camera would need near-plane clipping of the line; skip those tracers.
		if (dx * FORWARD.x + dy * FORWARD.y + dz * FORWARD.z < 0f) {
			return;
		}
		line(c, x0, y0, z0, x1, y1, z1, dx / len, dy / len, dz / len);
	}

	private static void line(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
							 float nx, float ny, float nz) {
		c.addVertex(x0, y0, z0).setColor(OUTLINE_ARGB).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
		c.addVertex(x1, y1, z1).setColor(OUTLINE_ARGB).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
	}
}
