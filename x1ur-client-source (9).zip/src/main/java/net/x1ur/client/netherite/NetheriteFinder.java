package net.x1ur.client.netherite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Netherite Finder - a line-by-line port of HookBeta's {@code NetheriteFinderModule} scan logic to X1UR
 * (Mojang mappings instead of Yarn, X1UR's tick event and config instead of HookBeta's module framework).
 *
 * <p>Behaviour kept from the original:
 * <ul>
 *   <li>Rescan every 20 ticks on a single low-priority daemon worker thread ("Hook-NetheriteFinder" there,
 *       "X1UR-NetheriteFinder" here); only one scan runs at a time.</li>
 *   <li>A chunk section is examined only if its block-state palette reports ancient debris ({@code maybeHas}); then
 *       every block of that section is checked and each match becomes an <i>exact</i> 1x1x1 box.</li>
 *   <li>If the palette reports debris but no block matches, the whole 16x16x16 section becomes a <i>non-exact</i>
 *       box. (A palette can keep an entry after the block was replaced, so this does happen.)</li>
 *   <li>Exact boxes sort before section boxes, then by distance to the player; the list is capped at "Max Shown".</li>
 * </ul>
 *
 * <p>Information source: only the block states of chunks the server already sent to this client. It does nothing
 * about, and cannot see through, server-side Anti-Xray: whatever the server hid is not in this data.
 *
 * <p>Changes that were unavoidable: the loaded-chunk list ({@code BlockUtil.getLoadedChunksList}, not part of the
 * supplied source) is rebuilt from the client's own chunk cache inside the effective render distance; a scan result
 * is dropped if the world changed while it ran; the module state (HookBeta's onEnable/onDisable) is driven from the
 * enabled flag in {@link X1urConfig}.
 */
public final class NetheriteFinder {
	private static final int RESCAN_TICKS = 20;

	/** Same shape as the original private record; {@code exact} is true for a single debris block. */
	record BoundingBox(double x1, double y1, double z1, double x2, double y2, double z2, boolean exact) {
		double centerX() {
			return (x1 + x2) * 0.5;
		}

		double centerY() {
			return (y1 + y2) * 0.5;
		}

		double centerZ() {
			return (z1 + z2) * 0.5;
		}
	}

	private final X1urConfig config;
	private volatile List<BoundingBox> hits = List.of();
	private final AtomicBoolean scanning = new AtomicBoolean();
	private ExecutorService worker;
	private volatile ClientLevel level;
	private boolean active;
	private int timer;

	public NetheriteFinder(X1urConfig config) {
		this.config = config;
	}

	/** Latest scan result (immutable list, safe to read from the render thread). */
	List<BoundingBox> hits() {
		return hits;
	}

	/** Forget everything (joining/leaving a world). */
	public void clear() {
		hits = List.of();
		timer = 0;
		level = null;
	}

	private void onEnable() {
		hits = List.of();
		timer = 0;
		scanning.set(false);
		worker = Executors.newSingleThreadExecutor(runnable -> {
			Thread thread = new Thread(runnable, "X1UR-NetheriteFinder");
			thread.setDaemon(true);
			thread.setPriority(1);
			return thread;
		});
	}

	private void onDisable() {
		ExecutorService old = worker;
		worker = null;
		if (old != null) {
			old.shutdownNow();
		}
		hits = List.of();
		scanning.set(false);
	}

	/** Called at the end of every client tick (HookBeta: TickEvent). */
	public void tick(Minecraft mc) {
		ClientLevel current = mc.level;
		if (current != level) { // new world or dimension: nothing from the old level may stay visible
			hits = List.of();
			timer = 0;
			level = current;
		}
		boolean enabled = config.netheriteFinderEnabled;
		if (enabled != active) {
			active = enabled;
			if (enabled) {
				onEnable();
			} else {
				onDisable();
			}
		}
		if (!enabled || current == null || mc.player == null || ++timer < RESCAN_TICKS) {
			return;
		}
		timer = 0;
		ExecutorService activeWorker = worker;
		if (activeWorker == null || activeWorker.isShutdown() || !scanning.compareAndSet(false, true)) {
			return;
		}

		double playerX = mc.player.getX();
		double playerY = mc.player.getY();
		double playerZ = mc.player.getZ();
		List<ChunkAccess> loaded = loadedChunks(mc, current);
		int cap = config.netheriteMaxShown;
		activeWorker.submit(() -> {
			try {
				List<BoundingBox> found = scan(loaded, cap, playerX, playerY, playerZ);
				if (config.netheriteFinderEnabled && worker == activeWorker && level == current) {
					hits = found;
				}
			} catch (Throwable t) {
				X1urClient.LOGGER.debug("Netherite Finder scan failed", t);
			} finally {
				scanning.set(false);
			}
		});
	}

	/** Stand-in for HookBeta's {@code BlockUtil.getLoadedChunksList()}: client-loaded chunks near the player. */
	private static List<ChunkAccess> loadedChunks(Minecraft mc, ClientLevel world) {
		List<ChunkAccess> chunks = new ArrayList<>();
		BlockPos pos = mc.player.blockPosition();
		int radius = mc.options.getEffectiveRenderDistance();
		int centerX = pos.getX() >> 4;
		int centerZ = pos.getZ() >> 4;
		for (int cx = centerX - radius; cx <= centerX + radius; cx++) {
			for (int cz = centerZ - radius; cz <= centerZ + radius; cz++) {
				ChunkAccess chunk = world.getChunk(cx, cz, ChunkStatus.FULL, false); // null if not loaded
				if (chunk != null) {
					chunks.add(chunk);
				}
			}
		}
		return chunks;
	}

	private static List<BoundingBox> scan(List<ChunkAccess> loaded, int cap, double playerX, double playerY, double playerZ) {
		ArrayList<BoundingBox> hits = new ArrayList<>();

		for (ChunkAccess chunk : loaded) {
			LevelChunkSection[] sections = chunk.getSections();
			int bottomSection = chunk.getMinSectionY();
			ChunkPos chunkPos = chunk.getPos();

			for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
				LevelChunkSection section = sections[sectionIndex];
				if (section != null && section.maybeHas(state -> state.is(Blocks.ANCIENT_DEBRIS))) {
					int sectionY = bottomSection + sectionIndex << 4;
					int priorHits = hits.size();

					for (int y = 0; y < 16; y++) {
						for (int z = 0; z < 16; z++) {
							for (int x = 0; x < 16; x++) {
								if (section.getBlockState(x, y, z).is(Blocks.ANCIENT_DEBRIS)) {
									int worldX = chunkPos.getMinBlockX() + x;
									int worldY = sectionY + y;
									int worldZ = chunkPos.getMinBlockZ() + z;
									hits.add(new BoundingBox(
										worldX, worldY, worldZ, worldX + 1, worldY + 1, worldZ + 1, true));
								}
							}
						}
					}

					if (hits.size() == priorHits) {
						int xx = chunkPos.getMinBlockX();
						int z = chunkPos.getMinBlockZ();
						hits.add(new BoundingBox(xx, sectionY, z, xx + 16, sectionY + 16, z + 16, false));
					}
				}
			}
		}

		hits.sort(Comparator.<BoundingBox>comparingInt(hit -> hit.exact() ? 0 : 1).thenComparingDouble(hit -> {
			double dx = hit.centerX() - playerX;
			double dy = hit.centerY() - playerY;
			double dz = hit.centerZ() - playerZ;
			return dx * dx + dy * dy + dz * dz;
		}));
		if (hits.size() > cap) {
			hits = new ArrayList<>(hits.subList(0, cap));
		}

		return List.copyOf(hits);
	}
}
