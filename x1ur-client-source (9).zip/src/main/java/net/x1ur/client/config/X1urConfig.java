package net.x1ur.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Mth;
import net.x1ur.client.X1urClient;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The only persisted state of X1UR CLIENT: the settings of every module (Aim Assist, Storage ESP, Netherite Finder,
 * Auto Mace, Trigger Bot, Player ESP, Base ESP, Amethyst ESP, Fly).
 * Stored as a tiny JSON file in the Fabric config directory.
 */
public final class X1urConfig {
	public static final int SMOOTHING_MIN = 0;
	public static final int SMOOTHING_MAX = 100;
	public static final float SPEED_MIN = 1.0f;
	public static final float SPEED_MAX = 20.0f;
	public static final int REACTION_DELAY_MIN = 0;
	public static final int REACTION_DELAY_MAX = 500;
	public static final int ACTIVATION_HOLD_ATTACK = 0;
	public static final int ACTIVATION_ALWAYS = 1;
	public static final int PLAYER_ESP_DISTANCE_MIN = 16;
	public static final int PLAYER_ESP_DISTANCE_MAX = 256;
	public static final int BASE_RADIUS_MIN = 2;
	public static final int BASE_RADIUS_MAX = 12;
	/** The detector starts at 2x2 blocks; this is a hard floor, never raised. */
	public static final int BASE_SIZE_MIN = 2;
	public static final int BASE_SIZE_MAX = 64;
	public static final int BASE_OPACITY_MIN = 10;
	public static final int BASE_OPACITY_MAX = 100;
	public static final int AMETHYST_RADIUS_MIN = 2;
	public static final int AMETHYST_RADIUS_MAX = 12;
	public static final int AMETHYST_OPACITY_MIN = 10;
	public static final int AMETHYST_OPACITY_MAX = 100;
	/** Fly speed multipliers; 1.0 = the speed the server/vanilla gives the player. */
	public static final float FLY_SPEED_MIN = 0.5f;
	public static final float FLY_SPEED_MAX = 4.0f;
	public static final int NETHERITE_SHOWN_MIN = 1;
	public static final int NETHERITE_SHOWN_MAX = 1000;
	public static final int STORAGE_VISIBILITY_MIN = 10;
	public static final int STORAGE_VISIBILITY_MAX = 100;
	public static final int STORAGE_DISTANCE_MIN = 16;
	public static final int STORAGE_DISTANCE_MAX = 128;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("x1ur_client.json");
	private static X1urConfig instance;

	/** Master toggle of the Aim Assist module. */
	public boolean aimAssistEnabled = false;
	/** 0..100. Higher = softer, slower approach to the target. */
	public int smoothing = 60;
	/** Maximum rotation per game tick, in degrees. */
	public float rotationSpeed = 6.0f;
	/** true = only assists while the attack key is held; false = assists whenever a target is in range. */
	public boolean onlyWhileAttacking = true;

	/** Master toggle of the Base ESP module. While false nothing scans or renders (including Shulker ESP). */
	public boolean baseEspEnabled = false;
	/** Independent Shulker ESP setting; only takes effect while {@link #baseEspEnabled} is true. */
	public boolean baseShulkerEspEnabled = false;
	/** Outline structure candidates. */
	public boolean baseStructureOutline = true;
	/** Show a text label on every result. */
	public boolean baseLabels = true;
	/** Append the distance to the label. */
	public boolean baseDistance = true;
	/** Minimum width (blocks, >= 2) of the built area. Default 2: detection starts at 2x2. */
	public int baseMinWidth = 2;
	/** Minimum length (blocks, >= 2) of the built area. Default 2. */
	public int baseMinLength = 2;
	/** Scan radius in chunks (2..12); never exceeds the client's render distance. */
	public int baseScanRadius = 6;
	/** Outline opacity in percent (10..100). */
	public int baseOpacity = 100;
	/** Outline color as 0xRRGGBB. Red by default. */
	public int baseEspColor = 0xFF0000;

	/** Master toggle of the Amethyst ESP module. While false nothing scans or renders. */
	public boolean amethystEspEnabled = false;
	/** Target category: fully grown Amethyst Clusters (Blocks.AMETHYST_CLUSTER) - the primary target. */
	public boolean amethystClusters = true;
	/** Target categories: the three growth stages below a full cluster. Off by default. */
	public boolean amethystLargeBuds = false;
	public boolean amethystMediumBuds = false;
	public boolean amethystSmallBuds = false;
	/** Draw the outline boxes. */
	public boolean amethystOutline = true;
	/** Draw a text label on the nearest targets. */
	public boolean amethystLabels = true;
	/** Append the distance to the labels. */
	public boolean amethystDistance = true;
	/** Scan radius in chunks (2..12); never exceeds the client's render distance. */
	public int amethystScanRadius = 5;
	/** Outline opacity in percent (10..100). */
	public int amethystOpacity = 100;
	/** Outline color as 0xRRGGBB. Bright magenta by default. */
	public int amethystEspColor = 0xD946EF;

	/**
	 * Master toggle of the Fly module. Only has an effect while the server has granted the player flight
	 * (abilities.mayfly, e.g. creative mode or a server permission); the client never grants it to itself.
	 */
	public boolean flyEnabled = false;
	/** Horizontal flight speed as a multiplier of the current flying speed (0.5..4.0, default 1.0 = vanilla). */
	public float flyHorizontalSpeed = 1.0f;
	/** Vertical (jump / sneak) flight speed as a multiplier of the vanilla vertical speed (0.5..4.0, default 1.0). */
	public float flyVerticalSpeed = 1.0f;

	/** Master toggle of the Auto Mace module. */
	public boolean autoMaceEnabled = false;
	/** ACTIVATION_HOLD_ATTACK: only while the attack key is held; ACTIVATION_ALWAYS: whenever armed. */
	public int autoMaceMode = ACTIVATION_HOLD_ATTACK;
	/** How long the opportunity must persist before attacking, in milliseconds (0..500). */
	public int autoMaceDelayMs = 100;

	/** Master toggle of the Trigger Bot module. */
	public boolean triggerBotEnabled = false;
	/** How long a target must stay under the crosshair before attacking, in milliseconds (0..500). */
	public int triggerBotDelayMs = 100;

	/** Master toggle of the Player ESP module. */
	public boolean playerEspEnabled = false;
	/** Maximum distance in blocks (16..256) at which player outlines are drawn. */
	public int playerEspMaxDistance = 64;
	/** Outline color as 0xRRGGBB. */
	public int playerEspColor = 0x22D3EE;
	/** Also outline the local player (only visible in third person). Off by default. */
	public boolean playerEspIncludeSelf = false;

	/** Master toggle of the Netherite Finder module. */
	public boolean netheriteFinderEnabled = false;
	/** Maximum number of ancient debris blocks highlighted (nearest first), 1..1000. */
	public int netheriteMaxShown = 100;
	/** Draw tracer lines from the crosshair to highlighted blocks and dropped items. */
	public boolean netheriteTracers = false;
	/**
	 * Ancient Debris Mode. false (default) = the display as before (exact debris blocks plus whole-section boxes);
	 * true = only exact ancient debris blocks, the section-sized boxes are not drawn.
	 */
	public boolean netheriteDebrisMode = false;

	/** Master toggle of the Storage ESP module. */
	public boolean storageEspEnabled = false;
	/** Outline opacity in percent (10..100). */
	public int storageOutlineVisibility = 100;
	/** Maximum distance in blocks (16..128) at which outlines are drawn. */
	public int storageMaxDistance = 64;
	/** Outline colors as 0xRRGGBB, one per storage type. Hex values can also be edited in the JSON file. */
	public int chestColor = 0xFB923C;
	public int trappedChestColor = 0xF87171;
	public int enderChestColor = 0xA78BFA;
	public int barrelColor = 0xFACC15;
	public int shulkerBoxColor = 0xF472B6;
	/** Tracer lines from the crosshair to each outlined storage block. Off by default. */
	public boolean storageTracers = false;
	/** Text label (type name) on the nearest storage blocks. Off by default. */
	public boolean storageLabels = false;
	/** Append the distance to the label. */
	public boolean storageDistance = true;
	/** Tracer colors as 0xRRGGBB, one per storage type; they default to the matching outline colors. */
	public int chestTracerColor = 0xFB923C;
	public int trappedChestTracerColor = 0xF87171;
	public int enderChestTracerColor = 0xA78BFA;
	public int barrelTracerColor = 0xFACC15;
	public int shulkerBoxTracerColor = 0xF472B6;
	/** Per-type filters: which storage types are shown at all. All on by default (the previous behavior). */
	public boolean showChests = true;
	public boolean showTrappedChests = true;
	public boolean showEnderChests = true;
	public boolean showBarrels = true;
	public boolean showShulkerBoxes = true;

	private X1urConfig() {
	}

	public static X1urConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static X1urConfig load() {
		if (!Files.isRegularFile(FILE)) {
			return new X1urConfig();
		}
		String text;
		try {
			text = Files.readString(FILE);
		} catch (IOException e) {
			X1urClient.LOGGER.warn("Could not read {}, using defaults", FILE, e);
			return new X1urConfig();
		}
		try { // fast path: a well-formed file
			X1urConfig loaded = GSON.fromJson(text, X1urConfig.class);
			if (loaded != null) {
				loaded.sanitize();
				return loaded;
			}
		} catch (RuntimeException e) {
			X1urClient.LOGGER.warn("{} has an invalid value ({}); recovering it field by field", FILE, e.getMessage());
			backUpBrokenFile();
		}
		return recover(text);
	}

	/**
	 * Field-by-field recovery: every field that parses is kept, every field that does not keeps its default, so one
	 * bad value (or a truncated file) does not reset the settings of unrelated modules.
	 */
	private static X1urConfig recover(String text) {
		X1urConfig result = new X1urConfig();
		com.google.gson.JsonObject root;
		try {
			com.google.gson.JsonElement parsed = com.google.gson.JsonParser.parseString(text);
			if (!parsed.isJsonObject()) {
				return result;
			}
			root = parsed.getAsJsonObject();
		} catch (RuntimeException e) {
			return result; // not JSON at all
		}
		for (java.lang.reflect.Field field : X1urConfig.class.getDeclaredFields()) {
			int mods = field.getModifiers();
			if (java.lang.reflect.Modifier.isStatic(mods) || !java.lang.reflect.Modifier.isPublic(mods)
				|| !root.has(field.getName())) {
				continue;
			}
			try {
				Object value = GSON.fromJson(root.get(field.getName()), field.getType());
				if (value != null) {
					field.set(result, value);
				}
			} catch (RuntimeException | IllegalAccessException e) {
				X1urClient.LOGGER.warn("Ignoring invalid config value for '{}'", field.getName());
			}
		}
		result.sanitize();
		return result;
	}

	private static void backUpBrokenFile() {
		try {
			Files.copy(FILE, FILE.resolveSibling("x1ur_client.json.broken"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			X1urClient.LOGGER.warn("Could not back up the invalid config file", e);
		}
	}

	/** Restores every Base ESP setting to its default (other modules are untouched) and saves. */
	public void resetBaseEsp() {
		X1urConfig d = new X1urConfig();
		baseEspEnabled = d.baseEspEnabled;
		baseShulkerEspEnabled = d.baseShulkerEspEnabled;
		baseStructureOutline = d.baseStructureOutline;
		baseLabels = d.baseLabels;
		baseDistance = d.baseDistance;
		baseMinWidth = d.baseMinWidth;
		baseMinLength = d.baseMinLength;
		baseScanRadius = d.baseScanRadius;
		baseOpacity = d.baseOpacity;
		baseEspColor = d.baseEspColor;
		save();
	}

	public void save() {
		sanitize();
		try (Writer writer = Files.newBufferedWriter(FILE)) {
			GSON.toJson(this, writer);
		} catch (IOException e) {
			X1urClient.LOGGER.warn("Could not write {}", FILE, e);
		}
	}

	private void sanitize() {
		smoothing = Mth.clamp(smoothing, SMOOTHING_MIN, SMOOTHING_MAX);
		rotationSpeed = Mth.clamp(rotationSpeed, SPEED_MIN, SPEED_MAX);
		baseMinWidth = Mth.clamp(baseMinWidth, BASE_SIZE_MIN, BASE_SIZE_MAX);
		baseMinLength = Mth.clamp(baseMinLength, BASE_SIZE_MIN, BASE_SIZE_MAX);
		baseScanRadius = Mth.clamp(baseScanRadius, BASE_RADIUS_MIN, BASE_RADIUS_MAX);
		baseOpacity = Mth.clamp(baseOpacity, BASE_OPACITY_MIN, BASE_OPACITY_MAX);
		baseEspColor &= 0xFFFFFF;
		amethystScanRadius = Mth.clamp(amethystScanRadius, AMETHYST_RADIUS_MIN, AMETHYST_RADIUS_MAX);
		amethystOpacity = Mth.clamp(amethystOpacity, AMETHYST_OPACITY_MIN, AMETHYST_OPACITY_MAX);
		amethystEspColor &= 0xFFFFFF;
		flyHorizontalSpeed = Float.isFinite(flyHorizontalSpeed) ? Mth.clamp(flyHorizontalSpeed, FLY_SPEED_MIN, FLY_SPEED_MAX) : 1.0f;
		flyVerticalSpeed = Float.isFinite(flyVerticalSpeed) ? Mth.clamp(flyVerticalSpeed, FLY_SPEED_MIN, FLY_SPEED_MAX) : 1.0f;
		autoMaceMode = Mth.clamp(autoMaceMode, ACTIVATION_HOLD_ATTACK, ACTIVATION_ALWAYS);
		autoMaceDelayMs = Mth.clamp(autoMaceDelayMs, REACTION_DELAY_MIN, REACTION_DELAY_MAX);
		triggerBotDelayMs = Mth.clamp(triggerBotDelayMs, REACTION_DELAY_MIN, REACTION_DELAY_MAX);
		playerEspMaxDistance = Mth.clamp(playerEspMaxDistance, PLAYER_ESP_DISTANCE_MIN, PLAYER_ESP_DISTANCE_MAX);
		playerEspColor &= 0xFFFFFF;
		netheriteMaxShown = Mth.clamp(netheriteMaxShown, NETHERITE_SHOWN_MIN, NETHERITE_SHOWN_MAX);
		storageOutlineVisibility = Mth.clamp(storageOutlineVisibility, STORAGE_VISIBILITY_MIN, STORAGE_VISIBILITY_MAX);
		storageMaxDistance = Mth.clamp(storageMaxDistance, STORAGE_DISTANCE_MIN, STORAGE_DISTANCE_MAX);
		chestColor &= 0xFFFFFF;
		trappedChestColor &= 0xFFFFFF;
		enderChestColor &= 0xFFFFFF;
		barrelColor &= 0xFFFFFF;
		shulkerBoxColor &= 0xFFFFFF;
		chestTracerColor &= 0xFFFFFF;
		trappedChestTracerColor &= 0xFFFFFF;
		enderChestTracerColor &= 0xFFFFFF;
		barrelTracerColor &= 0xFFFFFF;
		shulkerBoxTracerColor &= 0xFFFFFF;
	}
}
