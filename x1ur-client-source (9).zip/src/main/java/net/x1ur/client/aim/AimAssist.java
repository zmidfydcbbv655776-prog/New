package net.x1ur.client.aim;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.x1ur.client.config.X1urConfig;

/**
 * Aim Assist module.
 *
 * <p>Runs once per client tick (after the game tick) while enabled, in-world, no screen is open and the
 * attack key is held. It nudges the player's rotation toward the best nearby target:
 * each tick the remaining angle is multiplied by a factor derived from the <b>smoothing</b> setting and the
 * resulting step is capped by the <b>rotation speed</b> setting (degrees per tick). The renderer interpolates
 * between the previous and the new rotation, so motion stays smooth at high frame rates.
 */
public final class AimAssist {
	/** Fraction of the remaining angle applied per tick at smoothing = 100 %. */
	private static final float MIN_FRACTION = 0.05f;
	/** Below this remaining angle (degrees) no further correction is applied. */
	private static final float DEAD_ZONE = 0.15f;

	private final X1urConfig config;

	public AimAssist(X1urConfig config) {
		this.config = config;
	}

	public boolean isEnabled() {
		return config.aimAssistEnabled;
	}

	public void setEnabled(boolean enabled) {
		config.aimAssistEnabled = enabled;
	}

	public void tick(Minecraft mc) {
		if (!config.aimAssistEnabled) {
			return;
		}
		LocalPlayer player = mc.player;
		if (player == null || mc.level == null || mc.screen != null) {
			return;
		}
		if (config.onlyWhileAttacking && !mc.options.keyAttack.isDown()) {
			return;
		}
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}

		TargetSelector.Target target = TargetSelector.select(mc, player);
		if (target == null) {
			return;
		}

		float distance = Rotations.angularDistance(target.deltaYaw(), target.deltaPitch());
		if (distance < DEAD_ZONE) {
			return;
		}

		// smoothing 0 -> full correction, smoothing 100 -> MIN_FRACTION of the remaining angle per tick
		float smoothing = config.smoothing / (float) X1urConfig.SMOOTHING_MAX;
		float fraction = Mth.lerp(smoothing, 1.0f, MIN_FRACTION);

		float stepYaw = target.deltaYaw() * fraction;
		float stepPitch = target.deltaPitch() * fraction;

		// cap the combined step by the rotation speed, keeping its direction
		float step = Rotations.angularDistance(stepYaw, stepPitch);
		if (step > config.rotationSpeed) {
			float scale = config.rotationSpeed / step;
			stepYaw *= scale;
			stepPitch *= scale;
		}

		player.setYRot(player.getYRot() + stepYaw);
		player.setXRot(Mth.clamp(player.getXRot() + stepPitch, -90.0f, 90.0f));
	}
}
