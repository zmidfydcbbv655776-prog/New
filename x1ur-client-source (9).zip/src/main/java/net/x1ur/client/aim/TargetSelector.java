package net.x1ur.client.aim;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Picks the living entity closest to the crosshair (smallest angular distance)
 * that is within range, inside the field-of-view cone and in line of sight.
 */
final class TargetSelector {
	/** Maximum distance to the target's eye-level aim point, in blocks. */
	static final double MAX_RANGE = 4.5;
	/** Maximum angular distance between the crosshair and the target, in degrees. */
	static final float MAX_ANGLE = 60.0f;

	record Target(LivingEntity entity, Vec3 aimPoint, float deltaYaw, float deltaPitch) {
	}

	private TargetSelector() {
	}

	static Target select(Minecraft mc, LocalPlayer self) {
		if (mc.level == null) {
			return null;
		}

		Vec3 eye = self.getEyePosition();
		float yaw = self.getYRot();
		float pitch = self.getXRot();

		AABB search = self.getBoundingBox().inflate(MAX_RANGE + 1.0);
		Target best = null;
		float bestAngle = MAX_ANGLE;

		for (Entity entity : mc.level.getEntities(self, search)) {
			if (!isValid(self, entity)) {
				continue;
			}
			LivingEntity living = (LivingEntity) entity;
			Vec3 aim = aimPoint(living);
			if (aim.distanceToSqr(eye) > MAX_RANGE * MAX_RANGE) {
				continue;
			}

			float dYaw = Rotations.yawDelta(yaw, Rotations.yawTo(eye, aim));
			float dPitch = Rotations.pitchTo(eye, aim) - pitch;
			float angle = Rotations.angularDistance(dYaw, dPitch);
			if (angle >= bestAngle || !self.hasLineOfSight(living)) {
				continue;
			}
			bestAngle = angle;
			best = new Target(living, aim, dYaw, dPitch);
		}
		return best;
	}

	private static boolean isValid(LocalPlayer self, Entity entity) {
		if (entity == self || !(entity instanceof Player || entity instanceof Mob)) {
			return false;
		}
		LivingEntity living = (LivingEntity) entity;
		return living.isAlive()
			&& !living.isDeadOrDying()
			&& !living.isSpectator()
			&& !living.isInvisible()
			&& !self.isAlliedTo(living);
	}

	/** Upper-chest height of the target's hitbox, horizontally centred. */
	private static Vec3 aimPoint(LivingEntity target) {
		AABB box = target.getBoundingBox();
		return new Vec3(
			(box.minX + box.maxX) * 0.5,
			box.minY + (box.maxY - box.minY) * 0.7,
			(box.minZ + box.maxZ) * 0.5
		);
	}
}
