package net.x1ur.client.aim;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Pure rotation math (no game state) used by Aim Assist. Angles are in degrees, Minecraft convention. */
public final class Rotations {
	private static final double RAD_TO_DEG = 180.0 / Math.PI;

	private Rotations() {
	}

	/** Yaw (0 = +Z / south, increasing clockwise seen from above) needed to look from {@code from} to {@code to}. */
	public static float yawTo(Vec3 from, Vec3 to) {
		double dx = to.x - from.x;
		double dz = to.z - from.z;
		return (float) (Mth.atan2(dz, dx) * RAD_TO_DEG) - 90.0f;
	}

	/** Pitch (negative = up) needed to look from {@code from} to {@code to}. */
	public static float pitchTo(Vec3 from, Vec3 to) {
		double dx = to.x - from.x;
		double dy = to.y - from.y;
		double dz = to.z - from.z;
		double horizontal = Math.sqrt(dx * dx + dz * dz);
		return (float) -(Mth.atan2(dy, horizontal) * RAD_TO_DEG);
	}

	/** Shortest signed yaw difference {@code target - current}, in (-180, 180]. */
	public static float yawDelta(float current, float target) {
		return Mth.wrapDegrees(target - current);
	}

	/** Combined angular distance of a (yaw, pitch) delta. */
	public static float angularDistance(float deltaYaw, float deltaPitch) {
		return (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
	}
}
