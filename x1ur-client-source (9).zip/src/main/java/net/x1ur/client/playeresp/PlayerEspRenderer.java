package net.x1ur.client.playeresp;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.state.LevelRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
import net.x1ur.client.X1urClient;
import net.x1ur.client.config.X1urConfig;

import java.util.List;

/**
 * Player ESP: a 3D outline around every player the client is currently rendering.
 *
 * <p><b>Data source.</b> It reads vanilla's own extracted entity render states
 * ({@code LevelRenderState.entityRenderStates}) at Fabric's {@code WorldRenderEvents.END_MAIN}. Those states only
 * exist for entities the client already knows about and is drawing this frame (inside the frustum and the entity
 * render distance), and their positions are already interpolated for the current frame, so the outline stays glued to
 * the player model as it moves. Nothing is queried from the server and players the client has not been told about
 * cannot appear. Invisible players and spectators are skipped, as vanilla does not show them either, and so is
 * anything that is not an actual player (e.g. mannequins).
 *
 * <p>Because the states are rebuilt by the game every frame, removals, unloaded entities, world changes and
 * disconnects need no bookkeeping here: this class keeps no references to entities or levels.
 *
 * <p>Drawn through walls with vanilla's line shader and the depth test disabled, in one draw call with a reused
 * buffer; there is no per-frame allocation.
 */
public final class PlayerEspRenderer {
	private static final float LINE_WIDTH = 2.0f;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(X1urClient.MOD_ID, "pipeline/player_esp_lines"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.withDepthWrite(false)
			.build()
	);
	private static final RenderType RENDER_TYPE = RenderType.create(
		"x1ur_player_esp", RenderSetup.builder(PIPELINE).createRenderSetup());

	private final X1urConfig config;
	private ByteBufferBuilder allocator;
	private MultiBufferSource.BufferSource bufferSource;
	private boolean failed;

	public PlayerEspRenderer(X1urConfig config) {
		this.config = config;
	}

	/** Registered for {@code WorldRenderEvents.END_MAIN}. */
	public void render(WorldRenderContext context) {
		if (!config.playerEspEnabled || failed) {
			return;
		}
		try {
			draw(context);
		} catch (RuntimeException e) {
			failed = true; // never take the game down because of an overlay
			X1urClient.LOGGER.error("Player ESP rendering failed and was disabled for this session", e);
		}
	}

	private void draw(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			return;
		}
		LevelRenderState worldState = context.worldState();
		List<EntityRenderState> states = worldState.entityRenderStates;
		if (states.isEmpty()) {
			return;
		}

		Vec3 cam = worldState.cameraRenderState.pos;
		int selfId = mc.player.getId();
		boolean includeSelf = config.playerEspIncludeSelf;
		double maxDistanceSq = (double) config.playerEspMaxDistance * config.playerEspMaxDistance;
		int argb = 0xFF000000 | config.playerEspColor;

		VertexConsumer consumer = null;
		for (int i = 0, n = states.size(); i < n; i++) {
			EntityRenderState state = states.get(i);
			if (state.entityType != EntityType.PLAYER || !(state instanceof AvatarRenderState avatar)) {
				continue;
			}
			if (state.isInvisible || avatar.isSpectator) {
				continue;
			}
			if (!includeSelf && avatar.id == selfId) {
				continue;
			}
			if (state.distanceToCameraSq > maxDistanceSq) {
				continue;
			}

			double half = state.boundingBoxWidth * 0.5;
			float x0 = (float) (state.x - half - cam.x);
			float y0 = (float) (state.y - cam.y);
			float z0 = (float) (state.z - half - cam.z);
			float x1 = (float) (state.x + half - cam.x);
			float y1 = (float) (state.y + state.boundingBoxHeight - cam.y);
			float z1 = (float) (state.z + half - cam.z);

			if (consumer == null) {
				consumer = beginBatch();
			}
			box(consumer, x0, y0, z0, x1, y1, z1, argb);
		}

		if (consumer != null) {
			bufferSource.endBatch(RENDER_TYPE);
		}
	}

	private VertexConsumer beginBatch() {
		if (allocator == null) {
			allocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
			bufferSource = MultiBufferSource.immediate(allocator);
		}
		return bufferSource.getBuffer(RENDER_TYPE);
	}

	/** 12 edges of a camera-relative box. Normals carry the line direction, as vanilla's shape renderer does. */
	private static void box(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
		line(c, x0, y0, z0, x1, y0, z0, 1, 0, 0, argb);
		line(c, x0, y1, z0, x1, y1, z0, 1, 0, 0, argb);
		line(c, x0, y0, z1, x1, y0, z1, 1, 0, 0, argb);
		line(c, x0, y1, z1, x1, y1, z1, 1, 0, 0, argb);
		line(c, x0, y0, z0, x0, y1, z0, 0, 1, 0, argb);
		line(c, x1, y0, z0, x1, y1, z0, 0, 1, 0, argb);
		line(c, x0, y0, z1, x0, y1, z1, 0, 1, 0, argb);
		line(c, x1, y0, z1, x1, y1, z1, 0, 1, 0, argb);
		line(c, x0, y0, z0, x0, y0, z1, 0, 0, 1, argb);
		line(c, x1, y0, z0, x1, y0, z1, 0, 0, 1, argb);
		line(c, x0, y1, z0, x0, y1, z1, 0, 0, 1, argb);
		line(c, x1, y1, z0, x1, y1, z1, 0, 0, 1, argb);
	}

	private static void line(VertexConsumer c, float x0, float y0, float z0, float x1, float y1, float z1,
							 float nx, float ny, float nz, int argb) {
		c.addVertex(x0, y0, z0).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
		c.addVertex(x1, y1, z1).setColor(argb).setNormal(nx, ny, nz).setLineWidth(LINE_WIDTH);
	}
}
