# X1UR CLIENT

A minimal Fabric **client-side** mod for **Minecraft Java Edition 1.21.11** with a ClickGUI and exactly nine modules:

1. **Premium ClickGUI** – dark black/charcoal panel, cyan accents, rounded corners, light animations.
   Works with mouse, keyboard and touch. Contains only the controls of the two modules below.
2. **Aim Assist** – on/off toggle, *Aim Smoothing* and *Rotation Speed* sliders, *Only While Attacking* switch.
3. **Storage ESP** – on/off toggle, *Outline Visibility*, *Max Render Distance* and a color per storage type.
4. **Netherite Finder** – on/off toggle, *Max Shown* (1-1000, default 100) and *Tracers* switch.
5. **Auto Mace** – on/off toggle, *Activation Mode* (Hold Attack / Always), *Reaction Delay* (0-500 ms).
6. **Trigger Bot** – on/off toggle, *Reaction Delay* (0-500 ms).
7. **Player ESP** – on/off toggle, *Max Render Distance* (16-256), outline color, *Include Self* (off by default).
8. **Base ESP** – on/off toggle, *Shulker ESP*, *Structure Outline*, *Labels*, *Distance*, *Min Width/Length* (default 2x2), *Scan Radius*, *Opacity*, *Reset*, optional hotkey.
9. **Amethyst ESP** – on/off toggle, switches for *Amethyst Cluster* (fully grown) and the *Large / Medium / Small Amethyst Bud*, *Outline*, *Labels*, *Distance*, *Scan Radius*, *Opacity*, optional hotkey.
10. **Fly** – on/off toggle, *Horizontal Speed* and *Vertical Speed* (0.5x-4.0x, default 1.0x), optional hotkey.

Nothing else is included (no HUD, no other modules, no profiles, no search).

## Versions

| Component      | Version                                  |
|----------------|------------------------------------------|
| Minecraft      | 1.21.11 (exact)                          |
| Fabric Loader  | >= 0.18.1 (built against 0.18.4)         |
| Fabric API     | 0.141.6+1.21.11 (required at runtime)    |
| Java           | 21                                       |
| Fabric Loom    | 1.14.10 (`net.fabricmc.fabric-loom-remap`) |
| Gradle         | 9.2.1 (wrapper included)                 |
| Mappings       | Mojang official                          |

## Usage

* Press **Right Shift** in a world to open the ClickGUI (rebindable under *Controls -> X1UR CLIENT*).
* Press **G** (rebindable) to switch Aim Assist on/off without opening the GUI; a short "Aim Assist: ON/OFF" message appears above the hotbar.
* Click the **Aim Assist** card's switch to enable/disable; click the rest of the card to collapse/expand settings.
* **Aim Smoothing** (0-100 %): higher = softer, slower approach. 0 % = full correction every tick.
* **Rotation Speed** (1-20 deg/tick): hard cap on how far the view may turn per tick.
* **Only While Attacking** (on by default): on = Aim Assist moves your view only while the attack button is held; off = it works whenever a valid target is in range, without clicking.
* The two module cards form an accordion: click a card (not its switch) to open it and close the other one.
* **Storage ESP** (off by default) card: switch on/off, then
  * **Outline Visibility** (10-100 %): opacity of the outlines.
  * **Max Render Distance** (16-128 blocks, default 64): outlines farther away are not drawn.
  * **Outline Colors**: click a swatch for Chest, Trapped Chest, Ender Chest, Barrel, Shulker Box.
    (Any `0xRRGGBB` value can also be typed into `config/x1ur_client.json`.)
* Keyboard: `Up/Down/Tab` move focus, `Left/Right` adjust (on a card header: close/open it), `Enter/Space` toggle, `Esc` or Right Shift close.
* Touch: tap and drag; tapping outside the panel closes it.

Settings are saved to `config/x1ur_client.json`.

### Aim Assist behaviour (fixed, not configurable)

While enabled, in a world, with no screen open **and (by default) the attack key held** – turn off *Only While Attacking* in the GUI to remove that condition, the view is nudged toward the
target closest to the crosshair that is a player or mob, within 4.5 blocks, within 60 deg of the crosshair,
in line of sight, visible, alive and not on your team. Each tick the remaining angle is scaled by the smoothing
factor, then capped by the rotation speed.

### Base ESP

Off by default. Draws **red** boxes (through walls) around **Base Candidates** - areas of player-style blocks that are at
least *Min Width* x *Min Length* blocks (default and minimum **2 x 2**, no maximum) - and, separately, around shulker boxes.
It never claims a confirmed base: every structure is labelled "Base Candidate".

**Use it.** Open the GUI (Right Shift), open the *Base ESP* card and switch it on. Settings:
*Shulker ESP* (own switch, only active while the master switch is on), *Structure Outline*, *Labels*, *Distance* (appended to
labels), *Min Width* / *Min Length* (2-64), *Scan Radius* (2-12 chunks, never beyond your render distance), *Opacity*
(10-100 %), *Reset to Defaults* (Base ESP settings only; it also switches Base ESP off). Optional hotkey: *Toggle Base ESP*
under Options > Controls > X1UR CLIENT, **unbound by default** (on PojavLauncher bind it to an on-screen button). The color is
`baseEspColor` in `config/x1ur_client.json` (default `16711680` = red); there is no GUI swatch for it.
Master OFF: nothing is scanned or drawn (including shulkers), caches are freed, all saved settings are kept.

**Detection algorithm.**
1. *Built blocks* (`BuiltBlocks`): planks, wool, carpets, beds, doors, fences, gates, stairs, slabs, walls, trapdoors, glass,
   stained glass, concrete, bricks, polished/smooth/cut/chiseled blocks, candles, banners and utility blocks (crafting
   table, furnaces, chests, barrels, shulker boxes, hoppers, pistons, ...). Natural blocks (dirt, stone, cobblestone,
   netherrack, ...) are deliberately not counted.
2. *Per-chunk cache*: for each 8-block-high band of the world, a 16x16 bitmap of "built columns" (x,z positions with a built
   block in that band) plus the real lowest/highest built Y and the shulker positions. Sections whose block palette holds no
   built block are skipped without reading a block. Chunks are scanned nearest-first under a per-tick budget
   (1.5 ms and 24 sections), never force-loaded, rescanned every 15 s, and re-analysed only if their cache really changed.
3. *Analysis* (`FootprintAnalyzer`, no Minecraft dependency): per band, the bitmaps of all cached chunks are stitched into one
   grid (so structures crossing chunk borders are seen whole). A column qualifies if it lies in an all-built window of
   minWidth x minLength or minLength x minWidth. Qualifying columns are grouped (8-neighbourhood), overlapping boxes are
   merged (no duplicates), and boxes of vertically adjacent bands that overlap are merged into one multi-storey candidate.
   Cost is linear in the grid size (2-D prefix sums), independent of structure size.

**Limits, honestly.** The rule is "a solid 2x2 (or larger) patch of built columns inside one 8-block band", so a floor, roof,
thick wall or pillar qualifies, but a house with 1-block walls, dirt floor and no roof does not. Villages, mineshafts,
strongholds, ancient cities and other generated structures are made of the same blocks and **will** appear as candidates;
bases built only from natural blocks will not. Only chunks the server has sent are scanned; whatever the server hides
(Anti-Xray, unloaded or far chunks) cannot be seen and nothing is done to get around that. Boxes are bounding boxes, so an
L-shaped base gets a rectangle; the box height comes from the chunk's built blocks in that band, so a second structure in the
same chunk and band can make it up to 8 blocks taller than needed. Block edits are noticed by the periodic rescan (up to ~15 s
later; there is no client block-update event). Labels are not de-cluttered: nearby results overlap their text.
Analysis allocates temporary arrays proportional to the scan area (at radius 12 several MB per run); it only runs when a chunk
changed, but this has not been measured on a low-end device.

### Amethyst ESP

Off by default. Draws **magenta** boxes (through walls) around amethyst crystals the client can see in its loaded chunks, with
optional labels ("Amethyst Cluster", "Large Amethyst Bud", ...) and distances.

**Use it.** Open the GUI (Right Shift), open the *Amethyst ESP* card and switch it on. Settings: *Amethyst Cluster* (fully
grown crystal, **on** by default - the primary target), *Large / Medium / Small Amethyst Bud* (separate switches, **off** by
default), *Outline*, *Labels*, *Distance* (appended to labels), *Scan Radius* (2-12 chunks, never beyond your render distance,
default 5) and *Opacity* (10-100 %). Optional hotkey: *Toggle Amethyst ESP* under Options > Controls > X1UR CLIENT, **unbound
by default**. The color is `amethystEspColor` in `config/x1ur_client.json` (default `14039535` = #D946EF magenta); there is no
GUI swatch for it. Master OFF (or no category selected, or outline and labels both off): nothing is scanned or drawn, caches
are freed, all saved settings are kept.

**What it targets.** Blocks are matched by identity: `Blocks.AMETHYST_CLUSTER` and the three `*_AMETHYST_BUD` blocks. An
`instanceof` check would be wrong because in 1.21.11 all four are the same class (`AmethystClusterBlock`). **Budding amethyst
and the plain amethyst block are never highlighted.**

**How it works.** Per-chunk cache of every crystal with its real hit-box (from the block state's shape). A chunk section is read
block by block only if its palette contains a crystal. Chunks inside the radius are scanned nearest-first under a per-tick
budget (1.5 ms and 24 sections), never force-loaded, and rescanned every 15 s (the client has no block-change event), so a
newly grown bud shows up within about 15 s. Unchanged rescans do not republish. The result list (max 1024, nearest first) is
rebuilt when data or settings change and otherwise once per second; switching a category never rescans chunks. Unloaded chunks,
chunks beyond the radius, dimension changes and disconnects drop their entries immediately. Everything runs on the client thread.
Labels are limited to the 24 nearest visible crystals (a geode holds dozens).

**Limits, honestly.** It only shows crystals present in chunks the server has sent; crystals the server hides (Anti-Xray),
undiscovered or unloaded areas cannot be found and nothing is done to get around that. Labels of crystals that sit about a
block apart overlap and become hard to read (no de-cluttering). Outlines are drawn through walls by design.

### Fly

Off by default. Uses **vanilla's own flight mechanics** and nothing else; it works only where the **server has granted you
flight** (`abilities.mayfly`: creative mode, or a server/plugin permission such as an `/fly` command). The module never sets
`mayfly` itself - a client cannot give itself permission. If flight is not granted, nothing is changed and the action bar says
"Fly: the server has not granted flight"; if the server grants it later (or takes it away) the module follows without a restart.

**Use it.** Open the GUI (Right Shift), open the *Fly* card and switch it on. In the air (or after jumping) you start flying, like a
double-tap on jump: **jump = up, sneak = down** (the normal Minecraft keys, so they follow your key bindings). *Horizontal
Speed* multiplies the flying speed in effect when the module engaged (1.0x = normal flight on that server); *Vertical Speed* is
the multiplier for up/down. Optional hotkey: *Toggle Fly* under Options > Controls > X1UR CLIENT, **unbound by default**
(on PojavLauncher bind it to an on-screen button).

**How it works.** While engaged, every tick it (1) switches `abilities.flying` on when you are airborne (never on the ground, where
vanilla would cancel it again every tick), telling the server through vanilla's own `onUpdateAbilities()`; (2) sets the flying
speed to base x horizontal multiplier; (3) while exactly one of jump/sneak is held, adds the difference between your vertical
and horizontal multiplier to the vertical velocity (vanilla itself adds `flyingSpeed x 3`). No packet is built by this mod.
When switched off, or on losing permission, dying, riding or gliding with an elytra, it restores the flying speed it changed
and ends a flight it started. A respawn, dimension change, rejoin or disconnect drops its state (the new player already has
fresh abilities). Server-side speed changes while engaged are noticed and used as the new base.

**Server notes.** A vanilla server accepts this when it granted flight. Anti-cheat plugins may still react to speeds above 1.0x;
the default is ordinary flight speed. No bypass of any kind is attempted. For your end goal (searching for Ender Chests) the
existing *Storage ESP* card can outline and trace Ender Chests; it can only show blocks the server has sent to your client and
cannot show what is inside them.

### Auto Mace, Trigger Bot and Player ESP

All three are off by default. The GUI list now scrolls (mouse wheel, drag the scroll bar on the panel's right edge, or
keyboard focus) because six cards do not fit on small screens.

**Auto Mace.** Armed only while: the module is on, the main hand holds a mace, vanilla's own `MaceItem.canSmashAttack`
is true (fall distance above 1.5 blocks, not gliding), no screen is open and you are alive. When armed and a valid target
is under the crosshair for the reaction delay, it performs one vanilla attack and then stays disarmed until the fall ends
(at most one attack per fall). *Hold Attack* mode acts only while you hold the attack key; *Always* acts whenever armed.
**Trigger Bot.** Attacks the valid target under the crosshair once it has stayed there for the reaction delay and your
attack cooldown is fully charged; losing the target restarts the delay; after a hit the delay restarts. It does nothing
while a screen is open or while you are using an item.
**Shared rules.** Targets come from vanilla's crosshair pick (`Minecraft.hitResult`), which only yields an entity that is
within reach and not behind a block - nothing here loosens that. Valid targets are other players and hostile mobs
(`Enemy`); passive animals, villagers, pets, armor stands, invisible/spectating/creative/invulnerable entities and
teammates are never attacked. Attacks go through `VanillaAttack`, which mirrors vanilla's `Minecraft.startAttack`
guards and then calls `MultiPlayerGameMode.attack` + `swing` - vanilla builds and sends the packet; this mod creates no
packets of its own and changes no server state. Both modules share a limit of one attack per game tick.
The reaction delay has a resolution of one client tick (50 ms). **Auto Mace note:** at fast fall speeds the target is
inside reach for only a tick or two (and the crosshair pick is updated per rendered frame), so a long reaction delay or a
low frame rate can stop it from ever firing; use a small delay.
Neither module is undetectable or guaranteed not to get you kicked; servers can and do ban automated combat.

**Player ESP.** A 3D box outline (through walls) around players the client is currently rendering. It reads vanilla's
extracted entity render states, so only players your client already knows about and is drawing can appear; their
positions are interpolated per frame so the box follows the model. Invisible players, spectators and non-player avatars
(mannequins) are skipped. It keeps no entity references, so removal, world changes and disconnects need no handling.
Your own outline is only drawn if *Include Self* is on (and only shows in third person).

**Disconnect log.** Whenever vanilla shows its "Disconnected" screen (kick message, timeout, failed connection) the
reason text is written to the game log as a `WARN` line starting with `Disconnected from server -`.

### Netherite Finder behaviour

A line-by-line port of HookBeta's `NetheriteFinderModule` (Mojang mappings instead of Yarn, X1UR's tick event, config and
GUI instead of HookBeta's module framework). Off by default. Behaviour kept from the original:

* Rescan every 20 ticks on one low-priority daemon worker thread; only one scan at a time.
* A 16x16x16 chunk section is examined only if its block palette reports ancient debris; every block of it is then
  checked and each match becomes an **exact** box (pulsing purple fill + outline + tracer, tracer always drawn).
* If the palette reports debris but no block matches (palettes can keep stale entries after a block was removed), the
  whole section becomes a **section box**: outline only, plus a tracer only if *Tracers* is on.
* Exact boxes sort first, then by distance; capped by *Max Shown* (1-1000, default 100).
* Dropped ancient debris items are outlined, filled and traced every frame (current, non-interpolated bounding box).
* Colors: fill rgb(190,90,255) with alpha pulsing 255 -> 100 -> 255 every 2 s; outlines/tracers solid; line width 1.5.

Unavoidable differences (those classes were not in the supplied source): the loaded-chunk list is rebuilt from the
client's chunk cache inside the effective render distance; drawing uses vanilla 1.21.11's line/filled-box shaders at
`WorldRenderEvents.END_MAIN` with the depth test off (so it shows through walls); the tracer start is 0.4 blocks in front
of the camera and tracers to targets behind the camera are skipped; a scan result is dropped if the world changed while it
ran; the original's silent `catch (Throwable)` now logs at debug level.

**It cannot defeat server Anti-Xray, and does not try to.** It only reads block states of chunks the server already sent
to your client. Blocks a server hides are not in that data; decoy blocks some Anti-Xray modes send look real and are
highlighted like real ones. The original's description ("even with anti-xray") is not accurate and is not used here.

### Netherite Finder: Ancient Debris Mode

One extra switch in the Netherite Finder card, **off by default** (saved as `netheriteDebrisMode`). Off = the display exactly as
before. On = only **exact ancient debris blocks** are drawn; the section-sized (16x16x16) boxes are not. Dropped debris items are
unaffected. The setting is read every frame, so switching it back off restores the previous display immediately; no other
setting is touched and the module's own on/off switch works independently.
Note what this does and does not do: exact debris blocks were already outlined before this switch. The section boxes only appear
when a chunk section's block palette reports debris but no matching block is found (a stale palette entry, or a server that
conceals blocks). The mode can hide those boxes; it cannot show debris the server did not send. The scan itself, its cap and
its sorting (exact blocks first) are unchanged.

### Storage ESP behaviour

Outlines normal chests, trapped chests, ender chests, barrels and shulker boxes in chunks your client has loaded, drawn
as 3D wireframe boxes **through walls**. The two halves of a double chest get one combined box (never two).

How it works (and why it is cheap):

* **Detection** (`storage/StorageTracker`) never scans chunks. It listens to Fabric's `ClientBlockEntityEvents`
  load/unload events, so only block entities the game already loaded are tracked. A bounded revalidation over those
  cached entries runs ~4x per second (or ~5 ticks after a change) to drop replaced/unloaded blocks and merge double chests.
  Joining/leaving a world and dimension changes clear the cache. While the module is off, no revalidation runs.
* **Rendering** (`storage/StorageEspRenderer`) draws once per frame at `WorldRenderEvents.END_MAIN` with vanilla's line
  pipeline plus a depth-test-disabled variant, in one draw call. Per frame it only walks the cached list (distance and
  behind-camera culling, at most 1024 boxes, nearest first) - no world access and no per-frame allocation in the loop.
* Everything is client-side and read-only: no blocks, inventories or server data are touched and nothing is sent.
* Uses Fabric API's transitive access wideners for `RenderPipelines.register`, `RenderPipelines.LINES_SNIPPET` and
  `RenderType.create`, so Fabric API must be installed (it is already required).

## Adding your own module (offline guide)

See [`docs/ADDING_A_MODULE.md`](docs/ADDING_A_MODULE.md) (Persian): the 4 files every module touches, a complete tested
example, the Yarn -> Mojang name table, how to look up APIs offline with `javap`, and how to build with `--offline`.
Run `./gradlew build` once while online first; afterwards `./gradlew build --offline` works without internet.

## Building


### Storage ESP: tracers, labels and type filters

Added to the existing Storage ESP card (nothing was removed; the outlines, colors, visibility and distance behave as before).
**There was no tracer line in Storage ESP before this upgrade** - the renderer drew boxes only - so tracers are new and **off by
default**, which keeps the previous look.
* **Tracers** (switch, `storageTracers`): one line from the crosshair (a point 0.4 blocks in front of the camera) to the centre
  of each outlined storage block, in that type's tracer color. The draw list has one entry per block and a double chest is a
  single entry, so a double chest gets exactly one box and one tracer. Targets behind the camera get no tracer.
* **Tracer Colors**: one swatch row per type (Chest, Trapped Chest, Ender Chest, Barrel, Shulker Box), independent of the outline
  colors; the defaults equal the outline colors. Tracers use the *Outline Visibility* percentage as their opacity.
* **Labels** (`storageLabels`, off by default) and **Distance** (`storageDistance`, on; only matters while labels are on): the type
  name, e.g. "Chest 13m", on the 24 nearest blocks within 64 blocks.
* **Show Types**: one switch per type (all on by default). A hidden type has no outline, tracer or label.
* **Max Render Distance** (existing slider, 16-128) applies to outlines, tracers and labels.
Only the five types the module already supported exist; there are no "other" storage types (no furnaces or hoppers).
The scan and caching (`StorageTracker`) were not changed: it is still event-driven, never force-loads chunks and only knows blocks
the client already has.

### Desktop (Windows / macOS / Linux)

Requires JDK 21.

```bash
cd x1ur-client
./gradlew build          # Windows: gradlew.bat build
```

Output: `build/libs/x1ur-client-1.0.0.jar` (the `-sources.jar` is not needed for playing).
The first build downloads Minecraft and mappings and can take a few minutes.

### Android (Termux)

Building on the phone is possible but slow and needs ~3 GB free RAM. Easier option: build on a PC and copy the JAR.

```bash
pkg update && pkg install openjdk-21 git
cd x1ur-client
chmod +x gradlew
./gradlew build --no-daemon -Dorg.gradle.jvmargs=-Xmx1536m
```

Output is the same `build/libs/x1ur-client-1.0.0.jar`.

### Installing in PojavLauncher

1. Create a **Fabric 1.21.11** profile (Fabric Loader >= 0.18.1, Java 21 runtime).
2. Put `x1ur-client-1.0.0.jar` **and** Fabric API `0.141.6+1.21.11` into that profile's `mods` folder.
3. Pojav maps touches to mouse clicks, so the GUI is usable by touch. To open it, add custom on-screen
   buttons bound to **Right Shift** (GUI) and **G** (Aim Assist on/off) in Pojav's control layout editor (or rebind the key in Minecraft's controls).

## Limitations / honesty notes

* The mod **compiles and packages** successfully (Gradle `build`), and the pure rotation math was checked against
  Minecraft's yaw/pitch conventions in a standalone test.
* It has **not been launched in-game** by the author of this build (the build environment had no display/GPU).
  Rendering, input handling and Aim Assist behaviour have therefore **not been tested in a running client**.
  Please test in a single-player world first and report problems.
* PojavLauncher compatibility is by design (no native code, no unusual rendering, no mixins) but untested.
* **Netherite Finder port (final version):** in a real 1.21.11 dev client it drew 3 exact debris blocks behind a stone wall (fill + outline + tracers with Tracers off), a dropped debris item, and a section box after placing and removing debris in an empty section (outline only). Not tested: Max Shown capping, worker-thread behaviour under load, world/dimension changes, Anti-Xray servers, PojavLauncher.
* **Earlier runs, real 1.21.11 client** (Fabric dev environment, Mojang mappings, Mesa software OpenGL on a virtual display,
  single-player flat world, no Anti-Xray): Netherite Finder drew purple fill + outline + tracers for ancient debris both
  in plain view and hidden behind a stone wall, drew the dropped debris item, and drew nothing after being switched off
  in the GUI; Storage ESP outlines (barrel, chest) were drawn correctly at the same time; the GUI showed all three cards.
  NOT verified: the remapped release JAR in a normal launcher, real GPUs, PojavLauncher/Android, frame-time impact,
  Storage ESP double chests / block changes / dimension changes at runtime (only checked headlessly earlier), behaviour on
  servers with Anti-Xray, touch input, and the in-game look of the sliders/switches of the new card beyond one screenshot.
* **Auto Mace / Trigger Bot / Player ESP test results** (Fabric dev client, 1.21.11, software OpenGL, single-player flat
  world with AI-less zombies, cheats enabled for the test only):
  * Auto Mace, *Always* mode, 7-block drop with a mace and no mouse input: the zombie was killed (`[Monster Hunter]`).
  * Auto Mace, *Hold Attack* mode, identical drop without holding attack: the zombie stayed at 20.0 HP (gate works).
  * Auto Mace, *Hold Attack* mode **with** the attack key held: **not verified.** My attempts clicked right after the
    teleport, which resets the vanilla cooldown, so the module (correctly) refused to attack; chat also releases held
    keys. Drops of 40+ and 12 blocks did not trigger it either (very short in-reach window at low frame rate, plus the
    cooldown issue). Treat Hold Attack's positive path as untested.
  * Trigger Bot: valid zombie in reach 20.0 -> 14.1 HP; cow in the crosshair untouched (10.0); zombie behind a stone wall
    untouched (20.0). The reaction delay was not measured and the number of hits was not counted.
  * Player ESP: verified only on the local player (Include Self, third person): a cyan box matched the player model.
    Other players, distance culling, invisible/spectator skipping and multiplayer were **not** tested.
  * Disconnect log: verified with a refused connection (`Connection refused` was logged); a real server kick message was
    not tested.
  * GUI: keyboard navigation to the 4th card, the Activation Mode chip and delay slider, and the scroll bar rendering were
    seen; mouse-wheel scrolling, scroll-bar dragging and touch were not tested.
  * Not tested anywhere: PojavLauncher/Android, real GPUs, frame-time impact, a remapped release JAR in a normal
    launcher, any multiplayer server.
* **Base ESP test results** (Fabric dev client, 1.21.11, software OpenGL, single-player flat world; plus a plain-Java test):
  * Seen on screen: 2x2, 2x3 and 3x2 plank structures each got one tight box + readable label at close range; a 20x20
    stone-brick platform got one box; a wool L-shape crossing the x=16 chunk border got one box; a 1-wide, 12-long plank line
    and a 4x4 cobblestone patch got **no** box; shulker boxes were outlined with Shulker ESP on and not with it off; master OFF
    showed no outlines or labels at all; switching to the End showed no leftover boxes and they returned after coming back.
  * Not confirmed on screen: the single glass block (hidden behind the chat bar in my screenshot; the rule excludes it by design),
    multi-storey merging, chunks unloading while walking, disconnecting, the hotkey (unbound by default, never pressed).
  * GUI: the card rendered and the master switch and Shulker switch were operated by keyboard and changed the saved config.
    The sliders, the other three switches and the Reset button were displayed but **not exercised**; mouse and touch were not tested.
  * Config: values are written after GUI actions and were read at start-up; a file with an invalid value ("abc" for a number)
    was recovered field by field (other modules' settings kept, out-of-range values clamped, a `.broken` copy saved).
  * `docs/tests/FootprintAnalyzerCheck.java` (24 checks, plain Java; run: `javac -d /tmp/fa-out
    src/main/java/net/x1ur/client/base/FootprintAnalyzer.java docs/tests/FootprintAnalyzerCheck.java && java -cp /tmp/fa-out
    FootprintAnalyzerCheck`): 2x2 detected, 1x1 and 1-wide lines rejected, 2x3/3x2/3x3/4x4/8x8/16x16/100x100/500x500 accepted
    as one exact box each (no maximum), asymmetric minimums in both orientations, L-shape = one box, a 1-wide spur does not
    inflate the box, separate structures stay separate, a ring is one box, degenerate input is safe, a 1000x1000 grid takes
    tens of milliseconds. All passed.
  * Not tested anywhere: PojavLauncher/Android, real GPUs, frame/tick time of the scan in the client (the budget is in the code,
    not measured), large radii, servers with Anti-Xray, natural structures such as villages appearing as candidates.
* **Amethyst ESP test results** (Fabric dev client, 1.21.11, software OpenGL, single-player flat world; the number of published
  targets was read from a temporary INFO log of the scanner, switched back to debug afterwards):
  * Target identification: with only *Amethyst Cluster* on, exactly the 3 clusters were found (near, behind a stone wall, and one
    100 blocks away); the 3 buds, a budding amethyst block and an amethyst block were not. The near cluster was outlined and
    labelled "Amethyst Cluster 9m" (zoomed in; the expected distance from the teleport spot is about 8.7 m); the one behind the wall
    showed "Amethyst Cluster 22m" through the stone.
  * Category switches: turning on Large, Medium and Small Bud one at a time through the GUI (keyboard) took the count 3 -> 4 -> 5 -> 6
    and each bud got a magenta outline; the budding and plain amethyst blocks stayed un-outlined. Config file updated.
  * Master switch: OFF through the GUI logged "cleared 6 targets and 285 cached chunks" and saved `false`; ON again republished 6.
  * Unload: teleporting 150 blocks away took the published count to 0; coming back restored it (5, then 6).
  * Dimension change: going to the End cleared everything (6 targets / 285 chunks, then 0 published). My first attempt to come back
    ended with the client process being **SIGKILLed (exit 137, no Java exception or crash report) while the End was generating** on
    this 2 GB machine; the retry with a render distance of 4 completed the round trip and restored the targets. The first crash
    is most likely the out-of-memory killer, but I did not prove that.
  * Persistence: after a full restart the module started enabled with the buds on, with no manual toggling (5 targets with the
    render distance at 4, 2 would have been expected had the bud switches been lost).
  * One extra target (6 instead of 5) appeared after the End trip: a small bud was labelled above the budding amethyst block, most
    likely grown by that block's random tick and picked up by the periodic rescan. I did not confirm that with a command.
  * Not tested: the hotkey (never pressed), the Opacity slider, the Scan Radius slider (the radius was changed only in the config
    file), the Outline / Labels / Distance switches being turned off, the Amethyst Cluster switch turned off, touch input,
    a real disconnect, real amethyst geodes, PojavLauncher/Android, real GPUs, scan cost on a low-end device.
* **Storage ESP upgrade and Ancient Debris Mode test results** (Fabric dev client, 1.21.11, software OpenGL, single-player flat
  world with one block of each storage type, a double chest, two ancient debris blocks and a stale-palette section):
  * Storage ESP with tracers and labels on: every type got its outline, a tracer in its own color from the crosshair, and a label
    with distance (e.g. "Chest 12m", "Shulker Box 11m"); the double chest was one box with one tracer and one label.
  * GUI by keyboard: changing the Chest tracer color (orange to red) left the outline orange; switching the Barrel type off removed
    its outline, tracer and label. Both values were written to the config file.
  * Persistence: after a full restart (config left exactly as the GUI saved it) the barrel stayed hidden, the chest tracer stayed
    red, and tracers and labels stayed on. The new fields were also read correctly from a hand-written config at the first start.
  * Ancient Debris Mode: with a stale section box present, the default display showed the section box plus the exact debris;
    switching the mode on through the GUI removed the section box and kept the exact debris; switching it off brought the section
    box back. The config value went false, true, false in step.
  * No rendering failure was logged in any run.
  * Not tested: Tracers/Labels/Distance switched off, the other four filters and the other four tracer colors, the Outline
    Visibility slider's effect on tracers, tracers for targets behind the camera, the long Storage ESP card on a small screen
    (I did not view the GUI screenshot of it), mouse and touch, dimension change and disconnect for the upgraded renderer (the tracker
    code for those was not changed), Netherite Max Shown interplay, servers with Anti-Xray, PojavLauncher/Android, real GPUs, frame
    cost of many tracers and labels.
  * Known limits: labels of blocks standing close together overlap and are hard to read (no de-cluttering); the card has about 25
    rows and relies on the scrolling panel.
* **Fly test results** (Fabric dev client, 1.21.11, software OpenGL, single-player flat world, integrated server). Speeds were
  measured from a temporary per-tick position log that was removed afterwards (best 8-tick window):
  * No permission: switching to survival with Fly enabled changed nothing (module disengaged, nothing forced) and the action bar
    showed the "not granted" message.
  * 1.0x / 1.0x (the module adds nothing, i.e. vanilla): ascend 8.57 b/s, descend 8.55 b/s, forward 10.8-12.3 b/s.
  * Vertical 3.0x, horizontal 1.0x: ascend 24.2 b/s (2.8x), descend 22.5 b/s (2.6x), forward unchanged. The ideal is 3x
    (25.7 b/s, which is what vanilla itself gives at 3.0x/3.0x); the vertical multiplier lands about 6% (up) and 12% (down) short of it.
  * Horizontal 3.0x: flying speed 0.150, forward 32.5 b/s (about 3x).
  * Death: dying while flying logged "dropped (player dead)" with nothing sent; after clicking Respawn the new player engaged again
    with the fresh base speed 0.05 (the old 0.15 did not carry over) and flew at the configured speeds.
  * Switching Fly off in the GUI: log showed "disengaged (speed restored to 0.05, flying false)", the module stopped touching the
    player, and the server-side ability readout showed flying false and mayfly still 1 (creative). Note: the abilities packet only
    carries the flying flag, so that readout does not by itself prove the client speed restore; the log line does.
  * Persistence: the GUI saved clean values (3.0 and 2.0) and after a full restart the Fly card showed Horizontal 3.0x and
    Vertical 2.0x with the module off.
  * No "moved too quickly" / "moved wrongly" messages appeared (single-player owner; a dedicated server may differ).
  * Not tested: a dedicated server or any anti-cheat plugin, a server that grants flight by permission in survival, the hotkey (never
    pressed), disconnect, dimension change (the same state-drop path as respawn, but not exercised), elytra/vehicle interaction,
    lowering a multiplier below 1.0x, touch input, PojavLauncher/Android, real GPUs.
* Auto Mace and Trigger Bot automate attacks, and Netherite Finder, Storage ESP, Player ESP, Base ESP and Amethyst ESP reveal where things are, including behind walls; many servers forbid that. Storage ESP reveals where containers are, including behind walls. Many servers forbid this; use it only where allowed.
* Aim Assist is a gameplay advantage. Most multiplayer servers forbid it. **Only use it where the server or
  environment rules explicitly allow it** (e.g. single-player, your own server, or with the owner's consent).
* Aim Assist does not randomise or disguise its movement and makes no attempt to evade anti-cheat.
