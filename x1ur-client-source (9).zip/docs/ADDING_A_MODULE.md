# راهنمای ساخت ماژول جدید برای X1UR CLIENT (آفلاین)

این راهنما کامل است و بدون اینترنت هم می‌شود خواندش. کدهای مثال همه واقعاً روی همین پروژه
(Minecraft 1.21.11، Fabric، Java 21) کامپایل و بیلد شده‌اند، ولی **ماژول نمونه جزو پروژه نیست**؛
فقط برای آموزش است.

---

## 0. قبل از قطع شدن اینترنت (یک‌بار، آنلاین)

Gradle و فایل‌های ماینکرفت را اولین بار از اینترنت می‌گیرد و بعد در `~/.gradle` نگه می‌دارد.
پس **یک‌بار** وقتی نت داری این را بزن:

```bash
cd x1ur-client
./gradlew build            # ویندوز: gradlew.bat build ، ترموکس: sh gradlew build
```

از آن به بعد بدون نت:

```bash
./gradlew build --offline
```

نتیجه‌ی تست من: بعد از همان یک بیلد آنلاین، `./gradlew build --offline` بدون مشکل بیلد شد.
اگر پوشه‌ی `~/.gradle` را پاک کنی (یا روی گوشی دیگری بیلد کنی)، دوباره به نت نیاز داری.

نکته‌ها:
* اگر `./gradlew` خطای Permission denied داد: `chmod +x gradlew` یا `sh gradlew build --offline`.
* خروجی: `build/libs/x1ur-client-1.0.0.jar` (فایل `-sources.jar` را در `mods` نگذار).
* بیلد روی گوشی (Termux) کند است و رم زیاد می‌خواهد؛ راحت‌تر روی کامپیوتر بیلد کن و JAR را کپی کن.

---

## 1. معماری: یک ماژول از چه بخش‌هایی ساخته می‌شود

هر ماژول دقیقاً **۴ جا** را لمس می‌کند:

| # | فایل | کار |
|---|------|-----|
| 1 | `config/X1urConfig.java` | فیلدهای تنظیمات (روشن/خاموش، اسلایدرها) + محدود کردن مقدارها در `sanitize()` |
| 2 | `net/x1ur/client/<اسم‌ماژول>/…java` | خود منطق ماژول (یک کلاس، یا چند کلاس) |
| 3 | `X1urClient.java` | ثبت رویدادها (tick، رندر، ورود/خروج از بازی) |
| 4 | `gui/ClickGuiScreen.java` | یک کارت در GUI: یک متد `buildXxx()` + یک خط `modules.add(...)` |

اصل مهم: **منطق، تنظیمات و رندر را جدا نگه دار.** ماژول فقط `X1urConfig` را می‌خواند و GUI فقط
`X1urConfig` را تغییر می‌دهد؛ ماژول و GUI همدیگر را نمی‌شناسند.

نمونه‌های واقعی داخل پروژه که می‌توانی کپی‌شان کنی:

| ماژول | الگوی چیست |
|-------|------------|
| `aim/AimAssist.java` | ماژول ساده‌ی tick-محور |
| `combat/TriggerBot.java` | tick-محور + تأخیر + ریست هنگام عوض شدن دنیا |
| `storage/StorageTracker.java` + `StorageEspRenderer.java` | تشخیص (رویداد) جدا از رندر |
| `playeresp/PlayerEspRenderer.java` | ماژول فقط-رندر، بدون حالت |
| `netherite/NetheriteFinder.java` | اسکن دوره‌ای چانک‌های لود شده |

---

## 2. مثال کامل: ماژول «Coords Reminder»

هر چند ثانیه مختصات بلوک تو را بالای هات‌بار نشان می‌دهد. (فقط برای آموزش است.)

### مرحله 1 — تنظیمات: `config/X1urConfig.java`

فیلدها را کنار بقیه بگذار (فیلد `public` مستقیم در JSON ذخیره می‌شود؛ نام فیلد = کلید JSON):

```java
	/** Master toggle of the example Coords Reminder module. */
	public boolean coordsEnabled = false;
	/** Seconds between messages (1..60). */
	public int coordsIntervalSeconds = 5;
```

و داخل متد `sanitize()` مقدار را محدود کن (کاربر ممکن است فایل JSON را دستی خراب کند):

```java
		coordsIntervalSeconds = Mth.clamp(coordsIntervalSeconds, 1, 60);
```

فایل‌های JSON قدیمی بدون این کلیدها هم کار می‌کنند؛ مقدار پیش‌فرض فیلد استفاده می‌شود.

### مرحله 2 — منطق: `net/x1ur/client/example/CoordsReminder.java`

```java
package net.x1ur.client.example;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.x1ur.client.config.X1urConfig;

/** Example module: every N seconds shows your block coordinates above the hotbar. */
public final class CoordsReminder {
	private final X1urConfig config;
	private int ticks;

	public CoordsReminder(X1urConfig config) {
		this.config = config;
	}

	/** Forget state (join / disconnect). */
	public void reset() {
		ticks = 0;
	}

	/** Called at the end of every client tick (20 per second). */
	public void tick(Minecraft mc) {
		if (!config.coordsEnabled || mc.player == null || mc.level == null) {
			ticks = 0;
			return;
		}
		if (++ticks < config.coordsIntervalSeconds * 20) {
			return;
		}
		ticks = 0;
		mc.player.displayClientMessage(Component.literal("XYZ: " + mc.player.blockPosition().toShortString()), true);
	}
}
```

الگو: هر ماژول tick-محور یک متد `tick(Minecraft mc)` دارد، اول چک می‌کند روشن است و `mc.player` و
`mc.level` نال نیستند (در منوی اصلی یا هنگام لود شدن هر دو نال‌اند)، و یک `reset()` دارد.

### مرحله 3 — ثبت در `X1urClient.java`

بالای فایل import کن:

```java
import net.x1ur.client.example.CoordsReminder;
```

و داخل `onInitializeClient()` قبل از خط `LOGGER.info(...)`:

```java
		// ---- Coords Reminder (example module) ----
		CoordsReminder coords = new CoordsReminder(config);
		ClientPlayConnectionEvents.JOIN.register((handler, sender, mc) -> coords.reset());
		ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> coords.reset());
		ClientTickEvents.END_CLIENT_TICK.register(coords::tick);
```

* `JOIN` / `DISCONNECT`: وقتی وارد دنیا می‌شوی یا قطع می‌شوی حالت داخلی ماژول را پاک کن.
* `END_CLIENT_TICK`: آخر هر تیک کلاینت (۲۰ بار در ثانیه).
* برای رندر سه‌بعدی به جای آن `WorldRenderEvents.END_MAIN.register(renderer::render)` را ثبت کن
  (نمونه: `PlayerEspRenderer`).

### مرحله 4 — کارت GUI: `gui/ClickGuiScreen.java`

در سازنده، کنار بقیه‌ی `modules.add(...)`:

```java
		modules.add(buildCoordsReminder());
```

و یک متد جدید (کنار `buildPlayerEsp()` بگذار):

```java
	private Module buildCoordsReminder() {
		Module m = new Module("Coords Reminder", "Shows your position", () -> config.coordsEnabled, () -> {
			config.coordsEnabled = !config.coordsEnabled;
			config.save();
		});
		m.rows.add(new SliderRow("Interval", 1, 60, 1, 1,
			() -> config.coordsIntervalSeconds,
			v -> config.coordsIntervalSeconds = (int) Math.round(v),
			v -> Math.round(v) + " s"));
		return m;
	}
```

بقیه‌ی GUI (اسکرول، انیمیشن، کیبورد، لمس، فوکوس) خودکار کار می‌کند.

### ردیف‌های آماده‌ی GUI

| کلاس | کاربرد | سازنده |
|------|--------|--------|
| `SliderRow` | عدد در یک بازه | `(برچسب, min, max, گام_ماوس, گام_کیبورد, get, set, فرمت_نمایش)` |
| `SwitchRow` | کلید روشن/خاموش فرعی | `(برچسب, توضیح(Supplier), get, toggle)` |
| `ChoiceRow` | انتخاب بین چند گزینه | `(برچسب, String[] گزینه‌ها, getIndex, setIndex, توضیح)` |
| `SwatchRow` | انتخاب رنگ از پالت | `(برچسب, getRgb, setRgb)` |
| `LabelRow` | فقط یک عنوان جداکننده | `(متن)` |

---

## 3. بیلد

```bash
./gradlew build --offline
```

اگر تمام شد `BUILD SUCCESSFUL` می‌بینی. اگر خطا داد، **فقط اولین خطا را بخوان** (بقیه معمولاً از
همان اول ناشی می‌شوند). خطای رایج: `cannot find symbol` یعنی اسم متد/کلاس اشتباه است (بخش بعد).

---

## 4. مهم‌ترین دردسر: نام‌ها «Mojang mappings» هستند، نه Yarn

این پروژه از نام‌های رسمی Mojang استفاده می‌کند. بیشتر آموزش‌های اینترنتی، و کدهای کلاینت‌های دیگر
(مثل HookBeta)، از Yarn استفاده می‌کنند و **کپی‌کردنشان مستقیم کامپایل نمی‌شود.** معادل‌ها
(همگی در این پروژه واقعاً استفاده شده‌اند):

| Yarn (کد دیگران) | Mojang (این پروژه) |
|---|---|
| `MinecraftClient` | `Minecraft` |
| `mc.world` | `mc.level` (نوع: `ClientLevel`) |
| `mc.player` / `ClientPlayerEntity` | `mc.player` / `LocalPlayer` |
| `Text` | `Component` |
| `MatrixStack` | `PoseStack` |
| `Box` | `AABB` |
| `Vec3d` | `Vec3` |
| `WorldChunk` | `LevelChunk` |
| `ChunkSection` | `LevelChunkSection` |
| `state.isOf(Blocks.X)` | `state.is(Blocks.X)` |
| `itemEntity.getStack()` | `itemEntity.getItem()` |
| `getBlockPos()` (روی entity) | `blockPosition()` |
| `world.getEntities()` | `level.entitiesForRendering()` |

### چطور آفلاین اسم درست را پیدا کنم؟

بعد از اولین بیلد، جار ماینکرفت با نام‌های Mojang روی دیسک است. با `javap` (همراه JDK) می‌شود
متدها را لیست کرد:

```bash
# Linux/macOS (مسیر را با tab کامل کن):
MC=$(ls ~/.gradle/caches/fabric-loom/minecraftMaven/net/minecraft/minecraft-merged/*/*.jar | head -1)
javap -cp "$MC" -public net.minecraft.world.entity.player.Player | grep -i attack
javap -cp "$MC" -public net.minecraft.world.item.Items | grep MACE
```

ویندوز: همان مسیر زیر `%USERPROFILE%\.gradle\caches\fabric-loom\minecraftMaven\...`.
این همان روشی است که من برای تأیید همه‌ی APIهای این پروژه استفاده کردم، پس حدس نزن، جستجو کن.

برای API فبریک (رویدادها): جارهای ریمپ‌شده زیر `x1ur-client/.gradle/loom-cache/remapped_mods/`
هستند و با همان `javap` خوانده می‌شوند.

---

## 5. قواعد کیفیت (از تجربه‌ی همین پروژه)

* **همیشه null چک کن:** `mc.player`, `mc.level`, `mc.gameMode` در منوی اصلی و هنگام لود نال‌اند.
* **دنیا عوض می‌شود:** وقتی `mc.level` یا `mc.player` با آخرین مقدار فرق دارد (ورود، مرگ، دیمنشن)، حالت
  داخلی را ریست کن. نمونه: `AutoMace.tick` و `TriggerBot.tick`. ماژولی که اشیاء (entity/بلوک) نگه
  می‌دارد حتماً هنگام `JOIN`/`DISCONNECT` پاکشان کند.
* **هر فریم چیزی نساز:** در رندر (اجرا در هر فریم) `new` نزن و دنیا را اسکن نکن؛ اسکن را در tick یا
  رویداد انجام بده و نتیجه را در آرایه‌ی آماده بگذار (نمونه: `StorageTracker` → `StorageEspRenderer`).
* **رندر را در try/catch بگذار** که خطا بازی را کرش نکند (نمونه: `PlayerEspRenderer.render`).
* **حمله فقط از مسیر vanilla:** برای هر ماژول جنگی از `combat/VanillaAttack` استفاده کن؛ پکت خودت
  نساز و حالت سرور را دستکاری نکن.
* **فقط داده‌ی کلاینت:** چیزی که سرور نفرستاده را نمی‌شود دید و من هم برای دور زدن آن کد نمی‌نویسم.
* **پیش‌فرض خاموش:** `enabled = false` که کاربر خودش روشن کند.
* **حجم کم:** برای موبایل/PojavLauncher کارهای سنگین را کم بار و دوره‌ای (مثلاً ثانیه‌ای) انجام بده.

---

## 6. تست

* **کامپیوتر:** `./gradlew runClient` (نیاز به صفحه‌نمایش دارد) و یک دنیای تک‌نفره‌ی سوپرفلت.
* **گوشی (Pojav):** JAR را همراه Fabric API (`0.141.6+1.21.11`) در پوشه‌ی `mods` پروفایل Fabric 1.21.11 بگذار.
* باز کردن GUI: `Right Shift` (در تنظیمات کنترل قابل تغییر است؛ در Pojav یک دکمه‌ی روی صفحه به آن وصل کن).
* تنظیمات در `config/x1ur_client.json` ذخیره می‌شود؛ اگر چیزی خراب شد، فایل را پاک کن تا پیش‌فرض‌ها برگردند.

---

## 7. چک‌لیست قبل از تحویل

- [ ] فیلد در `X1urConfig` + `sanitize()`
- [ ] کلاس ماژول با `tick`/`render` + `reset()`
- [ ] ثبت در `X1urClient` (رویداد + JOIN/DISCONNECT)
- [ ] کارت در `ClickGuiScreen` (`buildXxx` + `modules.add`)
- [ ] `./gradlew build --offline` → `BUILD SUCCESSFUL`
- [ ] در بازی تک‌نفره تست شد: روشن، خاموش، عوض کردن تنظیم، رفتن به منوی اصلی و برگشتن
- [ ] از کار نمی‌افتد وقتی `mc.player == null`

---

یادآوری: هر ماژولی که خودکار حمله کند یا چیزی را پشت دیوار نشان بدهد روی بیشتر سرورها ممنوع است.
فقط در تک‌نفره یا جایی که قوانین اجازه می‌دهد استفاده کن.
