import net.x1ur.client.base.FootprintAnalyzer;
import net.x1ur.client.base.FootprintAnalyzer.Area;
import java.util.*;

public class FootprintAnalyzerCheck {
  static int fails = 0;
  static void check(boolean ok, String name) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (!ok) fails++; }
  static List<Area> run(boolean[] g, int w, int d, int mw, int ml) { return FootprintAnalyzer.analyze(g, w, d, mw, ml); }
  static boolean[] filled(int w, int d, int x0, int z0, int rw, int rl) {
    boolean[] g = new boolean[w * d];
    for (int z = z0; z < z0 + rl; z++) for (int x = x0; x < x0 + rw; x++) g[z * w + x] = true;
    return g;
  }
  public static void main(String[] a) {
    int W = 64, D = 64;
    // --- minimum is exactly 2x2 ---
    check(run(filled(W, D, 10, 10, 2, 2), W, D, 2, 2).size() == 1, "2x2 detected with min 2x2");
    check(run(filled(W, D, 10, 10, 1, 1), W, D, 2, 2).isEmpty(), "1x1 NOT detected");
    check(run(filled(W, D, 10, 10, 1, 30), W, D, 2, 2).isEmpty(), "1x30 line NOT detected (width 1)");
    check(run(filled(W, D, 10, 10, 30, 1), W, D, 2, 2).isEmpty(), "30x1 line NOT detected");
    // --- rectangles, both orientations, with min 2x2 ---
    for (int[] r : new int[][]{{2,3},{3,2},{3,3},{4,4},{8,8},{16,16}}) {
      List<Area> res = run(filled(W, D, 5, 5, r[0], r[1]), W, D, 2, 2);
      Area ar = res.size() == 1 ? res.get(0) : null;
      check(ar != null && ar.width() == r[0] && ar.length() == r[1], r[0] + "x" + r[1] + " detected as one exact box");
    }
    // --- no maximum: large platforms ---
    for (int n : new int[]{100, 500}) {
      int WW = n + 20;
      List<Area> res = run(filled(WW, WW, 5, 5, n, n), WW, WW, 2, 2);
      check(res.size() == 1 && res.get(0).width() == n && res.get(0).length() == n, n + "x" + n + " accepted (no max size)");
    }
    // --- configurable minimum, asymmetric: 3(x) by 5(z) ---
    check(run(filled(W, D, 5, 5, 3, 5), W, D, 3, 5).size() == 1, "3x5 passes min 3x5");
    check(run(filled(W, D, 5, 5, 5, 3), W, D, 3, 5).size() == 1, "5x3 passes min 3x5 (either orientation)");
    check(run(filled(W, D, 5, 5, 3, 4), W, D, 3, 5).isEmpty(), "3x4 fails min 3x5");
    check(run(filled(W, D, 5, 5, 2, 2), W, D, 3, 3).isEmpty(), "2x2 fails when min raised to 3x3");
    // --- irregular shapes ---
    boolean[] L = FootprintAnalyzer.gridOf(
        "..........",
        ".####.....",
        ".####.....",
        ".##.......",
        ".##.......",
        "..........");
    List<Area> l = run(L, 10, 6, 2, 2);
    check(l.size() == 1 && l.get(0).minX() == 1 && l.get(0).maxX() == 5 && l.get(0).minZ() == 1 && l.get(0).maxZ() == 5, "L-shape = ONE candidate with bounding box");
    boolean[] spur = FootprintAnalyzer.gridOf(
        "..........",
        ".##.......",
        ".##.......",
        ".##.......",
        ".#####....",   // 1-wide arm sticking out is NOT part of a 2x2 window
        "..........");
    List<Area> sp = run(spur, 10, 6, 2, 2);
    check(sp.size() == 1 && sp.get(0).maxX() == 3, "1-wide spur does not inflate the box");
    // --- separate structures stay separate; overlapping boxes merge ---
    boolean[] two = new boolean[W * D];
    for (int z = 5; z < 8; z++) for (int x = 5; x < 8; x++) two[z * W + x] = true;
    for (int z = 30; z < 33; z++) for (int x = 40; x < 43; x++) two[z * W + x] = true;
    check(run(two, W, D, 2, 2).size() == 2, "two far-apart structures -> 2 boxes");
    boolean[] ring = FootprintAnalyzer.gridOf(
        "#######",
        "#######",
        "##...##",
        "##...##",
        "#######",
        "#######");
    List<Area> rg = run(ring, 7, 6, 2, 2);
    check(rg.size() == 1 && rg.get(0).width() == 7 && rg.get(0).length() == 6, "ring/courtyard -> one box, no duplicate");
    // --- degenerate input never throws ---
    check(run(new boolean[0], 0, 0, 2, 2).isEmpty(), "empty grid ok");
    check(run(new boolean[4], 2, 2, 5, 5).isEmpty(), "window larger than grid ok");
    check(run(new boolean[4], 2, 2, 0, -3).size() <= 1, "bad minimums are clamped, no exception");
    // --- bounded work: 1000x1000 completes quickly ---
    int N = 1000; boolean[] big = new boolean[N * N]; Random r = new Random(1);
    for (int i = 0; i < big.length; i++) big[i] = r.nextInt(100) < 55;
    long t0 = System.nanoTime(); run(big, N, N, 2, 2); long ms = (System.nanoTime() - t0) / 1_000_000;
    System.out.println("INFO 1000x1000 random grid analysed in " + ms + " ms");
    check(ms < 3000, "1000x1000 grid under 3 s (linear cost)");
    System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
    System.exit(fails == 0 ? 0 : 1);
  }
}
