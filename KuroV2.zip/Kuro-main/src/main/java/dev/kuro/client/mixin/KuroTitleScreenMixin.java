package dev.kuro.client.mixin;

import dev.kuro.client.gui.KuroTitleScreen;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class KuroTitleScreenMixin {
   @Shadow public ClientLevel level;
   @Shadow public abstract void setScreen(Screen screen);

   @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
   private void kuro$replaceTitleScreen(Screen screen, CallbackInfo ci) {
      if (!(screen instanceof KuroTitleScreen)) {
         if (screen instanceof TitleScreen || (screen == null && this.level == null)) {
            ci.cancel();
            this.setScreen(new KuroTitleScreen());
         }
      }
   }

   @Inject(method = "createTitle", at = @At("HEAD"), cancellable = true)
   private void kuro$windowTitle(CallbackInfoReturnable<String> cir) {
      cir.setReturnValue("Minecraft " + SharedConstants.getCurrentVersion().name() + " - Kuro Client");
   }
}
